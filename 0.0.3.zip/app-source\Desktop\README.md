# ElectionCord Civitas: desktop app (Windows)

This folder turns `ElectionCordCivitas.html` and the `data` folder into a Windows installer
(`ElectionCord Civitas Setup 1.0.0.exe`). The installed app opens in its own window and works from files
on the computer, so there are no website limits to hit. It still needs an internet connection for the
background map (street and place names) and the page font; everything else works offline.

## One-time setup

1. Install **Node.js LTS** from https://nodejs.org (accept the defaults, then reopen PowerShell).
2. In PowerShell:

```powershell
cd "C:\Users\danny\Desktop\100K Project\Civitas\Desktop"
npm install
```

## Try it without installing

```powershell
npm start
```

This opens the app straight from the Civitas folder (uses the current `ElectionCordCivitas.html` and `data`).

## Build the installer

```powershell
npm run dist
```

This makes one file in `Desktop\dist\`: `ElectionCord-Civitas-1.0.0-win.zip`. People unzip it anywhere and
double-click `ElectionCord Civitas.exe`; there is nothing to install. (An installer was tried first but did not
start reliably, so the app is shipped as a zip.) Upload the zip for people to download (GitHub Releases, Google Drive, your site's Media Library, etc.). One large download is a
single request, so the website's request limit is not a problem.

## Releasing an update

1. Rebuild the map as usual (`build_all.py`) so `ElectionCordCivitas.html` and `data` are current.
2. Raise `"version"` in `package.json` (for example `1.0.1`).
3. Run `npm run dist` again and share the new installer. People install over the old version and keep
   their saved maps.

## Notes

- **"Windows protected your PC" warning.** The installer is not code-signed, so Windows SmartScreen shows an
  "Unknown publisher" screen the first time. Users click **More info, then Run anyway**. Removing the warning
  needs a code-signing certificate (paid, roughly $100-400 a year).
- **Saved maps** stay in the app's own storage on each person's computer (not in the Civitas folder).
  Use the **Export** button on a map to save it as a file, and **Open map file** on the main menu to load one,
  which is how maps are shared in the desktop app.
- **App icon.** To use your own, save a 256x256 `icon.ico` as `Desktop\build\icon.ico` before `npm run dist`.
- **Size.** The installer is large because it contains all the map data (about 240 MB before compression).
- The website accounts and share links do not appear in the desktop app. They only exist on electioncord.com.
