import csv
import hashlib
import inspect
import io
import json
import math
import os
import re
import sys
import time
import zipfile

import numpy as np
import geopandas as gpd
import shapely
from shapely import STRtree, set_precision

from shapely.geometry import mapping, shape

CIVITAS_DIR = r"C:\Users\danny\Desktop\100K Project\Civitas"
DEMO_DIR = os.path.join(CIVITAS_DIR, "Demographic Info", "California")
ELECTION_DIR = os.path.join(CIVITAS_DIR, "Election Info", "California")
ZIP_PATH = os.path.join(ELECTION_DIR, "ca_2024_gen_prec.zip")
STATE_KEY = "CA"
STATE_KEY_BG = "CA-BG"
BUILD_BLOCK_GROUPS = True
BG_ZIP_PATH = os.path.join(DEMO_DIR, "tl_2025_06_bg.zip")
EQUAL_AREA_CRS = "EPSG:3310"
POP_STATE_FIPS = "06"
POP_SOURCES = {
    "acs": {"csv": "ca_bg_pop_acs2024.csv", "url": "https://api.census.gov/data/2024/acs/acs5", "var": "B01003_001E"},
    "2020": {"csv": "ca_bg_pop_2020.csv", "block_csv": "ca_block_pop_2020.csv",
             "url": "https://api.census.gov/data/2020/dec/pl", "var": "P1_001N"},
    "vap2020": {"csv": "ca_bg_vap_2020.csv", "block_csv": "ca_block_vap_2020.csv",
                "url": "https://api.census.gov/data/2020/dec/pl", "var": "P3_001N"},
    "2010": {"csv": "ca_bg_pop_2010.csv", "block_csv": "ca_block_pop_2010.csv",
             "url": "https://api.census.gov/data/2010/dec/sf1", "var": "P001001"},
    "2000": {"csv": "ca_bg_pop_2000.csv", "block_csv": "ca_block_pop_2000.csv",
             "url": "https://api.census.gov/data/2000/dec/sf1", "var": "P001001"},
}
POP_FIELDS = {"acs": "pop", "2020": "pop20", "2010": "pop10", "2000": "pop00",
              "vap_acs": "vap", "vap_2020": "vap20", "vap_acs22": "vap22", "cvap_acs": "cvap"}
# 2022 inputs (Statewide Database): results by SR precinct, the master-precinct (MPREC) map, and the table
# saying which MPRECs make up each SR precinct. 2022 votes are allocated onto 2024 precincts and block groups.
SR22_ZIP = os.path.join(ELECTION_DIR, "state_g22_sov_data_by_g22_srprec.zip")
SR22_CSV_NAME = "state_g22_sov_data_by_g22_srprec.csv"
MPREC22_ZIP = os.path.join(ELECTION_DIR, "mprec_state_g22_v01_shp.zip")
MPREC22_XWALK = os.path.join(ELECTION_DIR, "state_g22_mprec_srprec.csv")
# 2020 inputs, same three pieces (file names and key columns differ slightly from the 2022 release).
SR20_ZIP = os.path.join(ELECTION_DIR, "state_g20_sov_data_by_g20_srprec.zip")
SR20_CSV_NAME = "state_g20_sov_data_by_g20_srprec.csv"
MPREC20_ZIP = os.path.join(ELECTION_DIR, "mprec_state_g20_v01_shp.zip")
MPREC20_XWALK = os.path.join(ELECTION_DIR, "mprec_srprec_state_g20_v01.csv")
# 2018 inputs. Its MPREC->SRPREC table is an older headerless two-column file with no county column, so
# the county is inferred from which counties have both the map precinct and the SR precinct.
SR18_ZIP = os.path.join(ELECTION_DIR, "state_g18_sov_data_by_g18_srprec.zip")
SR18_CSV_NAME = "state_g18_sov_data_by_g18_srprec.csv"
MPREC18_ZIP = os.path.join(ELECTION_DIR, "mprec_state_g18_v01_shp.zip")
MPREC18_XWALK = os.path.join(ELECTION_DIR, "mprec_srprec_state_g18_v01.csv")
# 2016 inputs. Its map is labelled with an odd "unknown GRS80" coordinate system; the coordinates are plain
# NAD83 latitude/longitude, so "crs" overrides the label.
SR16_ZIP = os.path.join(ELECTION_DIR, "state_g16_sov_data_by_g16_srprec.zip")
SR16_CSV_NAME = "state_g16_sov_data_by_g16_srprec.csv"
MPREC16_ZIP = os.path.join(ELECTION_DIR, "mprec_state_g16_v01_shp.zip")
MPREC16_XWALK = os.path.join(ELECTION_DIR, "mprec_srprec_state_g16.csv")
SR16_BLK_MAP = os.path.join(ELECTION_DIR, "state_g16_sr_blk_map.zip")
# Each Statewide Database vintage: where its three inputs are and which columns build the join keys.
SWDB_SETS = {
    "2016": {"sr_zip": SR16_ZIP, "sr_csv": SR16_CSV_NAME, "mprec_zip": MPREC16_ZIP, "xwalk": MPREC16_XWALK,
             "shape_key": ["PREC_KEY"], "xw_mkey": ["MPREC_KEY"], "xw_skey": ["SRPREC_KEY"], "crs": "EPSG:4269",
             "sr_blk": SR16_BLK_MAP},
    "2018": {"sr_zip": SR18_ZIP, "sr_csv": SR18_CSV_NAME, "mprec_zip": MPREC18_ZIP, "xwalk": MPREC18_XWALK,
             "shape_key": ["PRECINCT_K"], "xw_headerless": True},
    "2022": {"sr_zip": SR22_ZIP, "sr_csv": SR22_CSV_NAME, "mprec_zip": MPREC22_ZIP, "xwalk": MPREC22_XWALK,
             "shape_key": ["FIPS_CODE", "PRECINCT"], "xw_mkey": ["FIPS", "MPREC"], "xw_skey": ["FIPS", "SRPREC"]},
    "2020": {"sr_zip": SR20_ZIP, "sr_csv": SR20_CSV_NAME, "mprec_zip": MPREC20_ZIP, "xwalk": MPREC20_XWALK,
             "shape_key": ["PRECINCT_K"], "xw_mkey": ["MPREC_KEY"], "xw_skey": ["SRPREC_KEY"]},
}
VAP22_CSV = "ca_bg_vap_acs2022.csv"
VAP22_URL = "https://api.census.gov/data/2022/acs/acs5"
VAP20_CSV = "ca_bg_vap_2020.csv"
VAP20_URL = "https://api.census.gov/data/2020/dec/pl"
VAP20_VAR = "P3_001N"
VAP_ACS_CSV = "ca_bg_vap_acs2024.csv"
VAP_ACS_URL = "https://api.census.gov/data/2024/acs/acs5"
CVAP_SOURCES = {
    "2024": {"csv": "ca_bg_cvap_2024.csv", "zip": "CVAP_2020-2024_ACS_csv_files.zip",
             "url": "https://www2.census.gov/programs-surveys/decennial/rdo/datasets/2024/2024-cvap/CVAP_2020-2024_ACS_csv_files.zip"},
}
ETH_CSV = "ca_bg_eth_acs2024.csv"
ETH_URL = "https://api.census.gov/data/2024/acs/acs5"
ETH_VARS = {
    "eth_white": "B03002_003E",
    "eth_black": "B03002_004E",
    "eth_hisp": "B03002_012E",
    "eth_asian": "B03002_006E",
    "eth_native": "B03002_005E",
    "eth_pacific": "B03002_007E",
}
EDU_CSV = "ca_bg_edu_acs2024.csv"
EDU_URL = "https://api.census.gov/data/2024/acs/acs5"
EDU_TOTAL_VAR = "B15003_001E"
EDU_GROUPS = {
    "edu_lths": list(range(2, 17)),
    "edu_hs": [17, 18],
    "edu_somecol": [19, 20, 21],
    "edu_bach": [22],
    "edu_grad": [23, 24, 25],
}
EDU_FIELDS = ["edu_total", "edu_coll", "edu_noncoll"] + list(EDU_GROUPS)
AGE_CSV = "ca_bg_age_acs2024.csv"
AGE_URL = "https://api.census.gov/data/2024/acs/acs5"
AGE_TOTAL_VAR = "B01001_001E"
AGE_GROUPS = {
    "age_u18": [n + o for o in (0, 24) for n in (3, 4, 5, 6)],
    "age_18_29": [n + o for o in (0, 24) for n in (7, 8, 9, 10, 11)],
    "age_30_44": [n + o for o in (0, 24) for n in (12, 13, 14)],
    "age_45_64": [n + o for o in (0, 24) for n in (15, 16, 17, 18, 19)],
    "age_65": [n + o for o in (0, 24) for n in (20, 21, 22, 23, 24, 25)],
}
AGE_MIDPOINTS = {3: 2.5, 4: 7.5, 5: 12.5, 6: 16, 7: 19, 8: 20.5, 9: 21.5, 10: 23.5, 11: 27.5, 12: 32.5, 13: 37.5, 14: 42.5,
                 15: 47.5, 16: 52.5, 17: 57.5, 18: 61, 19: 63.5, 20: 66, 21: 68.5, 22: 72.5, 23: 77.5, 24: 82.5, 25: 90}
AGE_FIELDS = ["age_total", "age_sum"] + list(AGE_GROUPS)
ORIGIN_CSV = "ca_tract_origin_acs2024.csv"
ORIGIN_URL = "https://api.census.gov/data/2024/acs/acs5"
ORIGIN_VARS = {
    "orig_total": ["B05002_001E"],
    "orig_instate": ["B05002_003E"],
    "orig_outstate": ["B05002_004E"],
    "orig_foreign": ["B05002_013E"],
    "cit_total": ["B05001_001E"],
    "cit_yes": ["B05001_002E", "B05001_003E", "B05001_004E", "B05001_005E"],
}
ORIGIN_FIELDS = list(ORIGIN_VARS)
LANG_CSV = "ca_bg_lang_acs2024.csv"
LANG_URL = "https://api.census.gov/data/2024/acs/acs5"
LANG_TOTAL_VAR = "B16004_001E"
LANG_GROUPS = {
    "eng_vw": [f"B16004_{n:03d}E" for n in (3, 5, 10, 15, 20, 25, 27, 32, 37, 42, 47, 49, 54, 59, 64)],
    "eng_lvw": [f"B16004_{n:03d}E" for n in (6, 7, 8, 11, 12, 13, 16, 17, 18, 21, 22, 23, 28, 29, 30, 33, 34, 35,
                                              38, 39, 40, 43, 44, 45, 50, 51, 52, 55, 56, 57, 60, 61, 62, 65, 66, 67)],
    "lang_english": [f"B16004_{n:03d}E" for n in (3, 25, 47)],
    "lang_spanish": [f"B16004_{n:03d}E" for n in (4, 26, 48)],
    "lang_indo": [f"B16004_{n:03d}E" for n in (9, 31, 53)],
    "lang_asian": [f"B16004_{n:03d}E" for n in (14, 36, 58)],
    "lang_other": [f"B16004_{n:03d}E" for n in (19, 41, 63)],
}
LANG_FIELDS = ["lang_total"] + list(LANG_GROUPS)
INC_CSV = "ca_bg_inc_acs2024.csv"
INC_URL = "https://api.census.gov/data/2024/acs/acs5"
INC_TOTAL_VAR = "B19001_001E"
INC_GROUPS = {
    "inc_lt30k": [2, 3, 4, 5, 6],
    "inc_30_50k": [7, 8, 9, 10],
    "inc_50_75k": [11, 12],
    "inc_75_100k": [13],
    "inc_100_200k": [14, 15, 16],
    "inc_gt200k": [17],
}
INC_TOP_GROUPS = {
    "inc_lt50k": ["inc_lt30k", "inc_30_50k"],
    "inc_50_100k": ["inc_50_75k", "inc_75_100k"],
    "inc_gt100k": ["inc_100_200k", "inc_gt200k"],
}
INC_MED_VAR = "B19013_001E"
INC_FIELDS = ["inc_total", "inc_med"] + list(INC_TOP_GROUPS) + list(INC_GROUPS)
OLD_BLOCK_SHAPES = {
    "2010": ("tl_2010_06_tabblock10.zip", "https://www2.census.gov/geo/tiger/TIGER2010/TABBLOCK/2010/tl_2010_06_tabblock10.zip"),
    "2000": ("tl_2010_06_tabblock00.zip", "https://www2.census.gov/geo/tiger/TIGER2010/TABBLOCK/2000/tl_2010_06_tabblock00.zip"),
    "2020": ("tl_2020_06_tabblock20.zip", "https://www2.census.gov/geo/tiger/TIGER2020/TABBLOCK20/tl_2020_06_tabblock20.zip"),
}
KEEP_WATER_BGS = ("060179900000", "060619900000")
POP_TOTALS = {}
FORCE_REBUILD = False
DATA_DIR = os.path.join(CIVITAS_DIR, "data", STATE_KEY)
HTML_OUT_PATH = os.path.join(CIVITAS_DIR, "ElectionCordCivitas.html")
COUNTY_GEOJSON_PATH = os.path.join(DEMO_DIR, "CACounty.geojson")
COUNTY_CSV_PATH = os.path.join(DEMO_DIR, "CACounty.csv")
COUNTY_TOLERANCE = 0.0005
PROJECTION = {}

COUNTY_FILTER = None
TARGET_W = 1600
TOLERANCE = 0.000001
GRID_UNIT = 0.01
COVERAGE_TOLERANCE = 0.02
STATE_PROJECTION = {"lat1": 34.0, "lat2": 40.5, "lat0": 37.0, "lon0": -120.0}

RACES = {
    "president-2024": {
        "dem": "G24PREDHAR",
        "rep": "G24PRERTRU",
        "other": ["G24PREAKEN", "G24PREGSTE", "G24PRELOLI", "G24PREPCRU", "G24PRENSON"],
    },
    "senate-2024-full": {
        "dem": "G24USSDSCH",
        "rep": "G24USSRGAR",
        "other": [],
    },
    "senate-2024-special": {
        "dem": "S24USSDSCH",
        "rep": "S24USSRGAR",
        "other": [],
    },
    "house-2024": {
        "house": True,
    },
    # 2022 columns of the Statewide Database SR-precinct file (summed per side). House columns are the
    # precinct's own district's candidates (CNGDEM01/02 = Democrats, CNGREP01 = Republican, CNGGRN01 = Green).
    "governor-2022": {"swdb": {"set": "2022", "dem": ["GOVDEM01"], "rep": ["GOVREP01"], "other": []}},
    "senate-2022": {"swdb": {"set": "2022", "dem": ["USSDEM01"], "rep": ["USSREP01"], "other": []}},
    "house-2022": {"swdb": {"set": "2022", "dem": ["CNGDEM01", "CNGDEM02"], "rep": ["CNGREP01"], "other": ["CNGGRN01"]}},
    # 2020: President (Biden/Trump; the other four tickets are "Other") and House (no third-party columns).
    "president-2020": {"swdb": {"set": "2020", "dem": ["PRSDEM01"], "rep": ["PRSREP01"],
                                "other": ["PRSAIP01", "PRSGRN01", "PRSLIB01", "PRSPAF01"]}},
    "house-2020": {"swdb": {"set": "2020", "dem": ["CNGDEM01", "CNGDEM02"], "rep": ["CNGREP01"], "other": []}},
    # 2018: the Senate race was Democrat vs. Democrat. Its two sides are Feinstein (USSDEM02, 6,019,422 votes)
    # and de Leon (USSDEM01, 5,093,942); they sit in the dem/rep slots and are colored by demColor/repColor.
    "governor-2018": {"swdb": {"set": "2018", "dem": ["GOVDEM01"], "rep": ["GOVREP01"], "other": []}},
    "senate-2018": {"swdb": {"set": "2018", "dem": ["USSDEM02"], "rep": ["USSDEM01"], "other": []}},
    "house-2018": {"swdb": {"set": "2018", "dem": ["CNGDEM01", "CNGDEM02"], "rep": ["CNGREP01", "CNGREP02"],
                            "other": ["CNGGRN01", "CNGIND01"]}},
    # 2016: the Senate was again Democrat vs. Democrat: Harris (USSDEM01, 7,542,759) and Sanchez (USSDEM02, 4,701,417).
    "president-2016": {"swdb": {"set": "2016", "dem": ["PRSDEM01"], "rep": ["PRSREP01"],
                                "other": ["PRSGRN01", "PRSLIB01", "PRSPAF01"]}},
    "senate-2016": {"swdb": {"set": "2016", "dem": ["USSDEM01"], "rep": ["USSDEM02"], "other": []}},
    "house-2016": {"swdb": {"set": "2016", "dem": ["CNGDEM01", "CNGDEM02"], "rep": ["CNGREP01"], "other": ["CNGIND01"]}},
}

RACE_META = {
    "president-2024": {
        "year": "2024",
        "label": "President",
        "legend": "President 2024 \u00b7 margin",
        "demName": "Harris (D)",
        "repName": "Trump (R)",
        "demShort": "Harris",
        "repShort": "Trump",
        "hasOther": True,
        "blurb": (
            "<strong>President of the United States</strong>, Nov. 5, 2024 general election. "
            "Harris/Walz (D) and Trump/Vance (R) are shown directly; Kennedy (American), Stein (Green), "
            "Oliver (Libertarian), de la Cruz (Peace and Freedom), and write-ins are combined into \u201COther.\u201D"
        ),
    },
    "senate-2024-full": {
        "year": "2024",
        "label": "Senate (Full Term)",
        "legend": "Senate 2024 (Full Term) \u00b7 margin",
        "demName": "Schiff (D)",
        "repName": "Garvey (R)",
        "demShort": "Schiff",
        "repShort": "Garvey",
        "hasOther": False,
        "blurb": (
            "<strong>U.S. Senate, full six-year term</strong>, Nov. 5, 2024 general election. California's "
            "top-two primary sends only two candidates to the general, so this race has no \u201COther\u201D "
            "category \u2014 Adam Schiff (D) and Steve Garvey (R) were the only candidates on the ballot."
        ),
    },
    "senate-2024-special": {
        "year": "2024",
        "label": "Senate (Special)",
        "legend": "Senate 2024 (Special) \u00b7 margin",
        "demName": "Schiff (D)",
        "repName": "Garvey (R)",
        "demShort": "Schiff",
        "repShort": "Garvey",
        "hasOther": False,
        "blurb": (
            "<strong>U.S. Senate special election</strong>, filling the remainder of the term through "
            "January 2025. Decided on the same Nov. 5, 2024 ballot as the full-term race, with the same "
            "two candidates: Adam Schiff (D) and Steve Garvey (R)."
        ),
    },
    "house-2024": {
        "year": "2024",
        "label": "U.S. House",
        "legend": "U.S. House 2024 · margin",
        "demName": "Democratic",
        "repName": "Republican",
        "demShort": "Dem",
        "repShort": "Rep",
        "hasOther": True,
        "blurb": (
            "<strong>U.S. House of Representatives</strong>, all 52 districts, Nov. 5, 2024 general election. "
            "Votes are summed across districts by party: Democratic vs. Republican, with all other "
            "candidates combined into “Other.” In the few districts where both top-two "
            "candidates were from the same party, both are counted toward that party."
        ),
    },
    "governor-2022": {
        "year": "2022",
        "label": "Governor",
        "legend": "Governor 2022 · margin",
        "demName": "Newsom (D)",
        "repName": "Dahle (R)",
        "demShort": "Newsom",
        "repShort": "Dahle",
        "hasOther": False,
        "blurb": (
            "<strong>Governor of California</strong>, Nov. 8, 2022 general election. California's top-two "
            "primary sends only two candidates to the general, so this race has no “Other” category "
            "— Gavin Newsom (D) and Brian Dahle (R) were the only candidates on the ballot. Results were "
            "reported by 2022 precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "senate-2022": {
        "year": "2022",
        "label": "Senate",
        "legend": "Senate 2022 · margin",
        "demName": "Padilla (D)",
        "repName": "Meuser (R)",
        "demShort": "Padilla",
        "repShort": "Meuser",
        "hasOther": False,
        "blurb": (
            "<strong>U.S. Senate</strong>, Nov. 8, 2022 general election. Alex Padilla (D) and Mark Meuser (R) "
            "were the only candidates on the ballot, so this race has no “Other” category. Results were "
            "reported by 2022 precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "house-2022": {
        "year": "2022",
        "label": "U.S. House",
        "legend": "U.S. House 2022 · margin",
        "demName": "Democratic",
        "repName": "Republican",
        "demShort": "Dem",
        "repShort": "Rep",
        "hasOther": True,
        "blurb": (
            "<strong>U.S. House of Representatives</strong>, all 52 districts, Nov. 8, 2022 general election. "
            "Votes are summed across districts by party: Democratic vs. Republican, with the few other "
            "candidates combined into “Other.” In districts where both top-two candidates were from the "
            "same party, both are counted toward that party. Results were reported by 2022 precinct and are "
            "allocated to the current map, so individual units are estimates."
        ),
    },
    "president-2020": {
        "year": "2020",
        "label": "President",
        "legend": "President 2020 · margin",
        "demName": "Biden (D)",
        "repName": "Trump (R)",
        "demShort": "Biden",
        "repShort": "Trump",
        "hasOther": True,
        "blurb": (
            "<strong>President of the United States</strong>, Nov. 3, 2020 general election. Biden/Harris (D) and "
            "Trump/Pence (R) are shown directly; Jorgensen (Libertarian), Hawkins (Green), La Riva (Peace and "
            "Freedom), and De La Fuente (American Independent) are combined into “Other.” Results were "
            "reported by 2020 precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "house-2020": {
        "year": "2020",
        "label": "U.S. House",
        "legend": "U.S. House 2020 · margin",
        "demName": "Democratic",
        "repName": "Republican",
        "demShort": "Dem",
        "repShort": "Rep",
        "hasOther": False,
        "blurb": (
            "<strong>U.S. House of Representatives</strong>, all 53 districts, Nov. 3, 2020 general election. "
            "Votes are summed across districts by party: Democratic vs. Republican. California's top-two primary "
            "left only those two sides on the ballot in every district, so this race has no “Other” "
            "category; where both top-two candidates were from the same party, both are counted toward that "
            "party. Results were reported by 2020 precinct and are allocated to the current map, so individual "
            "units are estimates."
        ),
    },
    "governor-2018": {
        "year": "2018",
        "label": "Governor",
        "legend": "Governor 2018 · margin",
        "demName": "Newsom (D)",
        "repName": "Cox (R)",
        "demShort": "Newsom",
        "repShort": "Cox",
        "hasOther": False,
        "blurb": (
            "<strong>Governor of California</strong>, Nov. 6, 2018 general election. California's top-two "
            "primary sends only two candidates to the general, so this race has no “Other” category "
            "— Gavin Newsom (D) and John Cox (R) were the only candidates on the ballot. Results were "
            "reported by 2018 precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "senate-2018": {
        "year": "2018",
        "label": "Senate",
        "legend": "Senate 2018 · margin",
        "demName": "Feinstein (D)",
        "repName": "de León (D)",
        "demShort": "Feinstein",
        "repShort": "de León",
        "demTag": "Feinstein",
        "repTag": "de León",
        "demColor": "#1a808e",
        "repColor": "#6a428f",
        "hasOther": False,
        "blurb": (
            "<strong>U.S. Senate</strong>, Nov. 6, 2018 general election. Both candidates on the general election "
            "ballot were Democrats — Dianne Feinstein and Kevin de León — so this race is "
            "shown in teal (Feinstein) and purple (de León) instead of the usual blue and red. Results were "
            "reported by 2018 precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "house-2018": {
        "year": "2018",
        "label": "U.S. House",
        "legend": "U.S. House 2018 · margin",
        "demName": "Democratic",
        "repName": "Republican",
        "demShort": "Dem",
        "repShort": "Rep",
        "hasOther": True,
        "blurb": (
            "<strong>U.S. House of Representatives</strong>, all 53 districts, Nov. 6, 2018 general election. "
            "Votes are summed across districts by party: Democratic vs. Republican, with the few Green and "
            "independent candidates combined into “Other.” In districts where both top-two candidates "
            "were from the same party, both are counted toward that party. Results were reported by 2018 "
            "precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "president-2016": {
        "year": "2016",
        "label": "President",
        "legend": "President 2016 · margin",
        "demName": "Clinton (D)",
        "repName": "Trump (R)",
        "demShort": "Clinton",
        "repShort": "Trump",
        "hasOther": True,
        "blurb": (
            "<strong>President of the United States</strong>, Nov. 8, 2016 general election. Clinton/Kaine (D) and "
            "Trump/Pence (R) are shown directly; Johnson (Libertarian), Stein (Green), and La Riva (Peace and "
            "Freedom) are combined into “Other.” Results were reported by 2016 precinct and are "
            "allocated to the current map, so individual units are estimates."
        ),
    },
    "senate-2016": {
        "year": "2016",
        "label": "Senate",
        "legend": "Senate 2016 · margin",
        "demName": "Harris (D)",
        "repName": "Sanchez (D)",
        "demShort": "Harris",
        "repShort": "Sanchez",
        "demTag": "Harris",
        "repTag": "Sanchez",
        "demColor": "#1a808e",
        "repColor": "#6a428f",
        "hasOther": False,
        "blurb": (
            "<strong>U.S. Senate</strong>, Nov. 8, 2016 general election. Both candidates on the general election "
            "ballot were Democrats — Kamala Harris and Loretta Sanchez — so this race is shown in "
            "teal (Harris) and purple (Sanchez) instead of the usual blue and red. Results were reported by "
            "2016 precinct and are allocated to the current map, so individual units are estimates."
        ),
    },
    "house-2016": {
        "year": "2016",
        "label": "U.S. House",
        "legend": "U.S. House 2016 · margin",
        "demName": "Democratic",
        "repName": "Republican",
        "demShort": "Dem",
        "repShort": "Rep",
        "hasOther": True,
        "blurb": (
            "<strong>U.S. House of Representatives</strong>, all 53 districts, Nov. 8, 2016 general election. "
            "Votes are summed across districts by party: Democratic vs. Republican, with the few independent "
            "candidates combined into “Other.” In districts where both top-two candidates were from "
            "the same party, both are counted toward that party. Results were reported by 2016 precinct and are "
            "allocated to the current map, so individual units are estimates."
        ),
    },
}


def _ordinal(n):
    return "%d%s" % (n, "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th"))


_NAME_FIXES = {"LAMALFA": "LaMalfa", "MCCLINTOCK": "McClintock", "DESAULNIER": "DeSaulnier"}


def _house_candidates():
    out = {}
    try:
        with zipfile.ZipFile(ZIP_PATH) as z:
            text = z.read("README.txt").decode("utf-8", "replace")
    except (OSError, KeyError, zipfile.BadZipFile):
        return out
    for line in text.splitlines():
        m = re.match(r"^(GCON(\d\d)([A-Z])[A-Z]+)\s+(.+?)\s+-:-\s+\w+\s+-:-\s+CONGRESSIONAL", line)
        if m:
            words = [_NAME_FIXES.get(w, w.title()) for w in m.group(4).split()]
            out.setdefault(int(m.group(2)), []).append((m.group(1), " ".join(words), m.group(3)))
    return out


def _house_candidates_swdb(codebook_name):
    out = {}
    try:
        with open(os.path.join(ELECTION_DIR, codebook_name), newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
    except OSError:
        return out
    for row in rows:
        if row.get("DISTRICT_TYPE") != "CNG":
            continue
        field = row["FIELD"]
        letter = {"DEM": "D", "REP": "R", "GRN": "G", "IND": "I"}.get(field[3:6], field[3:4])
        out.setdefault(int(row["DISTRICT"]), []).append((field, row["NAME"].strip(), letter))
    return out


_NAME_SUFFIXES = {"JR", "SR", "II", "III", "IV", "V", "ESQ", "MD", "PHD"}


def _surname(full_name):
    if full_name.endswith("Underwood Jacobs"):
        return "Underwood Jacobs"
    words = full_name.replace(",", " ").split()
    while len(words) > 1 and words[-1].strip(".").upper() in _NAME_SUFFIXES:
        words.pop()
    return words[-1]


_OTHER_PARTY_COLORS = {"I": "#696969", "G": "#0e7f17"}
_INCUMBENTS = {("2022", 16): "Anna G. Eshoo", ("2022", 29): "Tony Cardenas", ("2022", 30): "Adam B. Schiff",
               ("2022", 34): "Jimmy Gomez", ("2024", 20): "Vince Fong", ("2024", 34): "Jimmy Gomez"}


def _assign_slots(cands, meta):
    ds = [c for c in cands if c[2] == "D"]
    rs = [c for c in cands if c[2] == "R"]
    others = [c for c in cands if c[2] not in ("D", "R")]
    same = ds if len(ds) == 2 and not rs else rs if len(rs) == 2 and not ds else None
    if same:
        both_dem = same is ds
        inc = [c for c in same if c[3]]
        if len(inc) == 1:
            other = same[1] if inc[0] is same[0] else same[0]
            dem, rep = ([inc[0]], [other]) if both_dem else ([other], [inc[0]])
            meta["repColor" if both_dem else "demColor"] = "#6a428f" if both_dem else "#ff9400"
        else:
            dem, rep = [same[0]], [same[1]]
            meta["demColor"], meta["repColor"] = ("#1a808e", "#6a428f") if both_dem else ("#ff9400", "#f5ed49")
        meta["demTag"], meta["repTag"] = _surname(dem[0][1]), _surname(rep[0][1])
    elif len(ds) == 1 and not rs and len(others) == 1:
        dem, rep, others = ds, others, []
        meta["repColor"] = _OTHER_PARTY_COLORS.get(rep[0][2], "#696969")
        meta["repTag"] = _surname(rep[0][1])
    else:
        dem, rep = ds, rs
    sides = {"dem": [c[0] for c in dem], "rep": [c[0] for c in rep], "other": [c[0] for c in others]}

    def side(group, party_label):
        if not group:
            return "No " + party_label, "None"
        sur = _surname(group[0][1])
        return "%s (%s)" % (sur, group[0][2]), sur
    meta["demName"], meta["demShort"] = side(dem, "Democrat")
    meta["repName"], meta["repShort"] = side(rep, "Republican")
    meta["hasOther"] = bool(others)
    return sides, dem, rep, others


def _house_district_race(d, cands, year="2024", election_date="Nov. 5, 2024", old_map=False):
    cands = [(f, n.rstrip("*"), p, n.endswith("*") or _INCUMBENTS.get((year, d)) == n) for f, n, p in
             [c[:3] for c in cands or []]]
    label = "%s Congressional District" % _ordinal(d)
    meta = {
        "year": year, "label": label, "legend": "%s %s · margin" % (label, year),
        "demShort": "Dem", "repShort": "Rep", "demName": "Democratic", "repName": "Republican",
        "hasOther": True, "group": "more", "sparse": True,
    }
    allocated = (" Results were reported by %s precinct and are allocated to the current map, so individual units "
                 "are estimates." % year) if old_map else ""
    if not cands:
        meta["blurb"] = ("<strong>U.S. House of Representatives, California’s %s</strong>, %s general "
                         "election. Only precincts in this district are shown.%s" % (label, election_date, allocated))
        return None, meta
    sides, dem, rep, others = _assign_slots(cands, meta)
    full = lambda c: "%s (%s)" % (c[1], c[2])
    meta["blurb"] = (
        "<strong>U.S. House of Representatives, California’s %s</strong>, %s general election: %s. "
        "Only precincts in this district are shown.%s%s" % (
            label, election_date, " vs. ".join(full(c) for c in dem + rep),
            (" %s received the remaining votes (“Other”)." % ", ".join(full(c) for c in others)) if others else "",
            allocated))
    return sides, meta


_HOUSE_CANDS = _house_candidates()
for _d in range(1, 53):
    _key = "house-2024-cd%02d" % _d
    _sides, RACE_META[_key] = _house_district_race(_d, _HOUSE_CANDS.get(_d))
    RACES[_key] = {"house": True, "district": _d}
    if _sides:
        RACES[_key]["sides"] = _sides

for _year, _book, _count, _date in (("2022", "G22_SOV_statewide_codebook.csv", 52, "Nov. 8, 2022"),
                                    ("2020", "G20_SOV_congressional_candidates.csv", 53, "Nov. 3, 2020"),
                                    ("2018", "G18_SOV_congressional_candidates.csv", 53, "Nov. 6, 2018"),
                                    ("2016", "G16_SOV_congressional_candidates.csv", 53, "Nov. 8, 2016")):
    _cands = _house_candidates_swdb(_book)
    for _d in range(1, _count + 1):
        _key = "house-%s-cd%02d" % (_year, _d)
        _sides, RACE_META[_key] = _house_district_race(_d, _cands.get(_d), _year, _date, old_map=True)
        _sides = _sides or {"dem": ["CNGDEM01", "CNGDEM02"], "rep": ["CNGREP01"], "other": []}
        RACES[_key] = {"swdb": dict(_sides, set=_year, district=_d)}

_STATEWIDE_MORE = (
    ("2018", "Nov. 6, 2018", (
        ("lieutenant-governor", "Lieutenant Governor", "LTGDEM01", "Ed Hernandez", "D", "LTGDEM02", "Eleni Kounalakis", "D"),
        ("attorney-general", "Attorney General", "ATGDEM01", "Xavier Becerra", "D", "ATGREP01", "Steven C Bailey", "R"),
        ("secretary-of-state", "Secretary of State", "SOSDEM01", "Alex Padilla", "D", "SOSREP01", "Mark P. Meuser", "R"),
        ("treasurer", "Treasurer", "TRSDEM01", "Fiona Ma", "D", "TRSREP01", "Greg Conlon", "R"),
        ("controller", "Controller", "CONDEM01", "Betty T. Yee", "D", "CONREP01", "Konstantinos Roditis", "R"),
        ("insurance-commissioner", "Insurance Commissioner", "INSDEM01", "Ricardo Lara", "D", "INSIND01", "Steve Poizner", "I"),
    )),
    ("2022", "Nov. 8, 2022", (
        ("lieutenant-governor", "Lieutenant Governor", "LTGDEM01", "Eleni Kounalakis", "D", "LTGREP01", "Angela E. Underwood Jacobs", "R"),
        ("attorney-general", "Attorney General", "ATGDEM01", "Rob Bonta", "D", "ATGREP01", "Nathan Hochman", "R"),
        ("secretary-of-state", "Secretary of State", "SOSDEM01", "Shirley N. Weber", "D", "SOSREP01", "Rob Bernosky", "R"),
        ("treasurer", "Treasurer", "TRSDEM01", "Fiona Ma", "D", "TRSREP01", "Jack M. Guerrero", "R"),
        ("controller", "Controller", "CONDEM01", "Malia M. Cohen", "D", "CONREP01", "Lanhee J. Chen", "R"),
        ("insurance-commissioner", "Insurance Commissioner", "INSDEM01", "Ricardo Lara", "D", "INSREP01", "Robert Howell", "R"),
    )),
)
for _year, _date, _rows in _STATEWIDE_MORE:
    for _slug, _label, _f1, _n1, _p1, _f2, _n2, _p2 in _rows:
        _key = "%s-%s" % (_slug, _year)
        _meta = {"year": _year, "label": _label, "legend": "%s %s · margin" % (_label, _year),
                 "demShort": "Dem", "repShort": "Rep", "demName": "Democratic", "repName": "Republican",
                 "hasOther": False, "group": "more", "moreGroup": "statewide"}
        _sides, _dem, _rep, _others = _assign_slots([(_f1, _n1, _p1, False), (_f2, _n2, _p2, False)], _meta)
        _meta["blurb"] = (
            "<strong>California %s</strong>, %s general election: %s (%s) vs. %s (%s). Results were reported by %s "
            "precinct and are allocated to the current map, so individual units are estimates."
            % (_label, _date, _n1, _p1, _n2, _p2, _year))
        RACE_META[_key] = _meta
        RACES[_key] = {"swdb": dict(_sides, set=_year)}


def slugify(name):
    return name.lower().replace(" ", "-")


def extract_records():
    t0 = time.time()
    z = zipfile.ZipFile(ZIP_PATH)
    f = z.open("ca_gen_2024_prec.geojson")
    tf = io.TextIOWrapper(f, encoding="utf-8")

    records = []
    counts = {}
    for line in tf:
        if '"type": "Feature"' not in line:
            continue
        if COUNTY_FILTER is not None and not any(
            f'"COUNTYFP": "{fips}"' in line for fips in COUNTY_FILTER
        ):
            continue
        s = line.strip()
        if s.endswith(","):
            s = s[:-1]
        feat = json.loads(s)
        p = feat["properties"]
        county = p["COUNTY"]
        geom = shape(feat["geometry"])

        race_votes = {}
        for rkey, spec in RACES.items():
            if "swdb" in spec:
                # Older elections' votes are not in this file; attach_sources_to_precincts fills them in.
                race_votes[rkey] = {"dem": 0.0, "rep": 0.0, "other": 0.0}
                continue
            if spec.get("house") and "sides" in spec:
                dem, rep, other = (sum((p.get(f) or 0.0) for f in spec["sides"][side]) for side in ("dem", "rep", "other"))
            elif spec.get("house"):
                dem = rep = other = 0.0
                for field, val in p.items():
                    if not field.startswith("GCON") or len(field) < 8 or not val:
                        continue
                    if "district" in spec and field[4:6] != "%02d" % spec["district"]:
                        continue
                    party = field[6]
                    if party == "D":
                        dem += val
                    elif party == "R":
                        rep += val
                    else:
                        other += val
            else:
                dem = p.get(spec["dem"], 0.0) or 0.0
                rep = p.get(spec["rep"], 0.0) or 0.0
                other = sum((p.get(field, 0.0) or 0.0) for field in spec["other"])
            race_votes[rkey] = {"dem": dem, "rep": rep, "other": other}

        counts[county] = counts.get(county, 0) + 1
        records.append(
            {
                "precinct": p["PRECINCT"],
                "countyfp": p["COUNTYFP"],
                "unique_id": p["UNIQUE_ID"],
                "county": county,
                "totreg": p.get("TOTREG", 0.0) or 0.0,
                "geom": geom,
                "races": race_votes,
            }
        )

    print(f"extract: {len(records)} precincts in {time.time()-t0:.1f}s, {len(counts)} counties")
    return records


def load_bg_population(source, level="block group"):
    """Return {GEOID: total population} for one of POP_SOURCES at `level` ("block group" or "block").

    Reads the cached CSV if present. Otherwise downloads the total-population variable for every
    California unit of that level from the Census API, one county at a time (a county that is too
    big for one response is retried tract by tract), and caches it as a CSV.
    Negative values (the ACS "no data" sentinels, e.g. -666666666) are treated as 0."""
    cfg = POP_SOURCES[source]
    is_block = level == "block"
    csv_path = os.path.join(DEMO_DIR, cfg["block_csv"] if is_block else cfg["csv"])
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key. Request one at "
                "https://api.census.gov/data/key_signup.html, then set the CENSUS_API_KEY "
                "environment variable and re-run. "
                f"Alternatively, put your own GEOID,pop CSV at {csv_path}."
            )

        def census_get(url, required=True):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    body = r.read().decode("utf-8", "replace")
                return json.loads(body)
            except Exception as e:
                if not required:
                    return None
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def rows_from(data):
            out = []
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                try:
                    val = int(float(d[cfg["var"]]))
                except (TypeError, ValueError):
                    val = 0
                geoid = d["state"] + d["county"] + d["tract"].ljust(6, "0") + d[level]
                out.append((geoid, max(val, 0)))
            return out

        counties = [row[-1] for row in census_get(
            f"https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        qlevel = level.replace(" ", "%20")
        rows = []
        for cfp in counties:
            url = (f"{cfg['url']}?get={cfg['var']}&for={qlevel}:*"
                   f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            data = census_get(url, required=not is_block)
            if data is None:
                tracts = [t[-1] for t in census_get(
                    f"{cfg['url']}?get=NAME&for=tract:*&in=state:{POP_STATE_FIPS}%20county:{cfp}")[1:]]
                got = []
                for t in tracts:
                    got.extend(rows_from(census_get(
                        f"{cfg['url']}?get={cfg['var']}&for={qlevel}:*"
                        f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:{t}")))
                rows.extend(got)
                print(f"population[{source}/{level}]: county {cfp} -> {len(got)} (by tract, {len(tracts)} tracts)")
            else:
                got = rows_from(data)
                rows.extend(got)
                print(f"population[{source}/{level}]: county {cfp} -> {len(got)}")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "pop"])
            w.writerows(rows)
        print(f"population[{source}/{level}]: wrote {len(rows)} rows to {csv_path}")
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        pop = {row["GEOID"]: max(int(float(row["pop"])), 0) for row in csv.DictReader(f)}
    print(f"population[{source}/{level}]: {len(pop)} rows, {sum(pop.values()):,} people")
    return pop


def load_bg_ethnicity():
    """Return {field: {block-group GEOID: count}} for every ETH_VARS field (ACS 5-year, table B03002).

    Reads ETH_CSV if present; otherwise downloads every California block group from the Census API,
    one county at a time, and caches it as a CSV (GEOID plus one column per field)."""
    csv_path = os.path.join(DEMO_DIR, ETH_CSV)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key (set CENSUS_API_KEY) or put your own CSV at " + csv_path)

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        counties = [row[-1] for row in census_get(
            f"{ETH_URL}?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        var_list = ",".join(ETH_VARS.values())
        rows = []
        for cfp in counties:
            data = census_get(f"{ETH_URL}?get={var_list}&for=block%20group:*"
                              f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                geoid = d["state"] + d["county"] + d["tract"] + d["block group"]
                vals = []
                for var in ETH_VARS.values():
                    try:
                        vals.append(max(int(float(d[var])), 0))
                    except (TypeError, ValueError):
                        vals.append(0)
                rows.append([geoid] + vals)
            print(f"ethnicity: county {cfp} -> {len(data) - 1} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID"] + list(ETH_VARS))
            w.writerows(rows)
        print(f"ethnicity: wrote {len(rows)} block groups to {csv_path}")
    out = {field: {} for field in ETH_VARS}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            for field in ETH_VARS:
                out[field][row["GEOID"]] = max(int(float(row[field])), 0)
    print(f"ethnicity: {len(out['eth_white'])} block groups, " + ", ".join(
        f"{f.replace('eth_', '')} {sum(v.values()):,}" for f, v in out.items()))
    return out


def load_bg_education():
    """Return {field: {block-group GEOID: count}} for every EDU_FIELDS field (ACS 5-year, table B15003).

    Reads EDU_CSV (GEOID, edu_total, then one column per EDU_GROUPS bucket) if present; otherwise
    downloads every California block group from the Census API, one county at a time, and caches it
    (a cached CSV that lacks the bucket columns is stale and is re-downloaded). Negative values (the
    ACS "no data" sentinels, e.g. -666666666) are treated as 0. edu_coll is bachelor's + graduate and
    edu_noncoll is edu_total minus edu_coll."""
    csv_path = os.path.join(DEMO_DIR, EDU_CSV)
    if os.path.exists(csv_path):
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            header = next(csv.reader(f), [])
        if not all(c in header for c in EDU_GROUPS):
            print(f"education: {EDU_CSV} is missing attainment columns, re-downloading")
            os.remove(csv_path)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key (set CENSUS_API_KEY) or put your own CSV at " + csv_path)

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def num(d, var):
            try:
                return max(int(float(d[var])), 0)
            except (TypeError, ValueError):
                return 0

        counties = [row[-1] for row in census_get(
            f"https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        group_vars = {g: [f"B15003_{n:03d}E" for n in nums] for g, nums in EDU_GROUPS.items()}
        var_list = ",".join([EDU_TOTAL_VAR] + [v for vs in group_vars.values() for v in vs])
        rows = []
        for cfp in counties:
            data = census_get(f"{EDU_URL}?get={var_list}&for=block%20group:*"
                              f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                geoid = d["state"] + d["county"] + d["tract"] + d["block group"]
                rows.append([geoid, num(d, EDU_TOTAL_VAR)] + [sum(num(d, v) for v in vs) for vs in group_vars.values()])
            print(f"education: county {cfp} -> {len(data) - 1} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "edu_total"] + list(EDU_GROUPS))
            w.writerows(rows)
        print(f"education: wrote {len(rows)} block groups to {csv_path}")
    out = {field: {} for field in EDU_FIELDS}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            gid = row["GEOID"]
            total = max(int(float(row["edu_total"])), 0)
            for g in EDU_GROUPS:
                out[g][gid] = max(int(float(row[g])), 0)
            coll = min(out["edu_bach"][gid] + out["edu_grad"][gid], total)
            out["edu_total"][gid] = total
            out["edu_coll"][gid] = coll
            out["edu_noncoll"][gid] = total - coll
    print(f"education: {len(out['edu_total'])} block groups, " + ", ".join(
        f"{f.replace('edu_', '')} {sum(v.values()):,}" for f, v in out.items()))
    return out


def load_bg_age():
    """Return {field: {block-group GEOID: count}} for every AGE_FIELDS field (ACS 5-year, table B01001).

    Reads AGE_CSV (GEOID, age_total, then one column per AGE_GROUPS bucket, male + female summed) if
    present; otherwise downloads every California block group from the Census API, one county at a time,
    and caches it (a cached CSV that lacks the bucket columns is stale and is re-downloaded). Negative
    values (the ACS "no data" sentinels) are treated as 0."""
    csv_path = os.path.join(DEMO_DIR, AGE_CSV)
    if os.path.exists(csv_path):
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            header = next(csv.reader(f), [])
        if "age_sum" not in header or not all(c in header for c in AGE_GROUPS):
            print(f"age: {AGE_CSV} is missing age columns, re-downloading")
            os.remove(csv_path)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key (set CENSUS_API_KEY) or put your own CSV at " + csv_path)

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def num(d, var):
            try:
                return max(int(float(d[var])), 0)
            except (TypeError, ValueError):
                return 0

        counties = [row[-1] for row in census_get(
            f"https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        group_vars = {g: [f"B01001_{n:03d}E" for n in nums] for g, nums in AGE_GROUPS.items()}
        var_list = ",".join([AGE_TOTAL_VAR] + [v for vs in group_vars.values() for v in vs])
        rows = []
        for cfp in counties:
            data = census_get(f"{AGE_URL}?get={var_list}&for=block%20group:*"
                              f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                geoid = d["state"] + d["county"] + d["tract"] + d["block group"]
                age_sum = sum(AGE_MIDPOINTS[n] * num(d, f"B01001_{n + o:03d}E") for n in AGE_MIDPOINTS for o in (0, 24))
                rows.append([geoid, num(d, AGE_TOTAL_VAR), round(age_sum, 1)] + [sum(num(d, v) for v in vs) for vs in group_vars.values()])
            print(f"age: county {cfp} -> {len(data) - 1} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "age_total", "age_sum"] + list(AGE_GROUPS))
            w.writerows(rows)
        print(f"age: wrote {len(rows)} block groups to {csv_path}")
    out = {field: {} for field in AGE_FIELDS}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            gid = row["GEOID"]
            total = max(int(float(row["age_total"])), 0)
            for g in AGE_GROUPS:
                out[g][gid] = max(int(float(row[g])), 0)
            out["age_total"][gid] = total
            out["age_sum"][gid] = max(float(row["age_sum"]), 0.0)
    print(f"age: {len(out['age_total'])} block groups, " + ", ".join(
        f"{f.replace('age_', '')} {sum(v.values()):,}" for f, v in out.items()))
    return out


def load_tract_origin():
    """Return {field: {tract GEOID: count}} for every ORIGIN_FIELDS field (ACS 5-year, tables B05002 and B05001).

    Place of birth and citizenship are only published down to Census tracts, not block groups, so this is
    tract-level; interpolate_to_block_groups spreads each tract over its block groups by population.
    Reads ORIGIN_CSV (GEOID, then one column per field) if present; otherwise downloads every California
    tract from the Census API, one county at a time, and caches it. Negative values (the ACS "no data"
    sentinels) are treated as 0."""
    csv_path = os.path.join(DEMO_DIR, ORIGIN_CSV)
    if os.path.exists(csv_path):
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            header = next(csv.reader(f), [])
        if not all(c in header for c in ORIGIN_FIELDS):
            print(f"origin: {ORIGIN_CSV} is missing columns, re-downloading")
            os.remove(csv_path)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key (set CENSUS_API_KEY) or put your own CSV at " + csv_path)

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def num(d, var):
            try:
                return max(int(float(d[var])), 0)
            except (TypeError, ValueError):
                return 0

        counties = [row[-1] for row in census_get(
            f"https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        var_list = ",".join(v for vs in ORIGIN_VARS.values() for v in vs)
        rows = []
        for cfp in counties:
            data = census_get(f"{ORIGIN_URL}?get={var_list}&for=tract:*&in=state:{POP_STATE_FIPS}%20county:{cfp}")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                rows.append([d["state"] + d["county"] + d["tract"]] + [sum(num(d, v) for v in vs) for vs in ORIGIN_VARS.values()])
            print(f"origin: county {cfp} -> {len(data) - 1} tracts")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID"] + ORIGIN_FIELDS)
            w.writerows(rows)
        print(f"origin: wrote {len(rows)} tracts to {csv_path}")
    out = {field: {} for field in ORIGIN_FIELDS}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            for field in ORIGIN_FIELDS:
                out[field][row["GEOID"]] = max(int(float(row[field])), 0)
    print(f"origin: {len(out['orig_total'])} tracts, " + ", ".join(f"{f} {sum(v.values()):,}" for f, v in out.items()))
    return out


def load_bg_language():
    """Return {field: {block-group GEOID: count}} for every LANG_FIELDS field (ACS 5-year, table B16004).

    B16004 is language spoken at home by English-speaking ability for the population 5 and over, split into
    three age brackets; LANG_GROUPS sums the matching rows of each bracket. Reads LANG_CSV (GEOID, lang_total,
    then one column per LANG_GROUPS field) if present; otherwise downloads every California block group from
    the Census API, one county at a time (the table has more variables than one API call allows, so they are
    fetched in chunks), and caches it. Negative values (the ACS "no data" sentinels) are treated as 0."""
    csv_path = os.path.join(DEMO_DIR, LANG_CSV)
    if os.path.exists(csv_path):
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            header = next(csv.reader(f), [])
        if not all(c in header for c in LANG_GROUPS):
            print(f"language: {LANG_CSV} is missing columns, re-downloading")
            os.remove(csv_path)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key (set CENSUS_API_KEY) or put your own CSV at " + csv_path)

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def num(d, var):
            try:
                return max(int(float(d[var])), 0)
            except (TypeError, ValueError):
                return 0

        counties = [row[-1] for row in census_get(
            f"https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        all_vars = sorted({LANG_TOTAL_VAR} | {v for vs in LANG_GROUPS.values() for v in vs})
        chunks = [all_vars[i:i + 40] for i in range(0, len(all_vars), 40)]
        rows = []
        for cfp in counties:
            vals = {}
            for chunk in chunks:
                data = census_get(f"{LANG_URL}?get={','.join(chunk)}&for=block%20group:*"
                                  f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
                hdr = data[0]
                for row in data[1:]:
                    d = dict(zip(hdr, row))
                    geoid = d["state"] + d["county"] + d["tract"] + d["block group"]
                    vals.setdefault(geoid, {}).update({v: num(d, v) for v in chunk})
            for geoid, d in vals.items():
                rows.append([geoid, d[LANG_TOTAL_VAR]] + [sum(d[v] for v in vs) for vs in LANG_GROUPS.values()])
            print(f"language: county {cfp} -> {len(vals)} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "lang_total"] + list(LANG_GROUPS))
            w.writerows(rows)
        print(f"language: wrote {len(rows)} block groups to {csv_path}")
    out = {field: {} for field in LANG_FIELDS}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            gid = row["GEOID"]
            for field in LANG_FIELDS:
                out[field][gid] = max(int(float(row[field])), 0)
    print(f"language: {len(out['lang_total'])} block groups, " + ", ".join(f"{f} {sum(v.values()):,}" for f, v in out.items()))
    return out


def load_bg_income():
    """Return {field: {block-group GEOID: households}} for every INC_FIELDS field (ACS 5-year, table B19001).

    Reads INC_CSV (GEOID, inc_total, then one column per INC_GROUPS bucket) if present; otherwise
    downloads every California block group from the Census API, one county at a time, and caches it.
    Negative values (the ACS "no data" sentinels) are treated as 0. The 3-bucket fields are sums of
    adjacent 6-bucket fields."""
    csv_path = os.path.join(DEMO_DIR, INC_CSV)
    if os.path.exists(csv_path):
        with open(csv_path, newline="", encoding="utf-8-sig") as f:
            header = next(csv.reader(f), [])
        if not all(c in header for c in list(INC_GROUPS) + ["inc_med"]):
            print(f"income: {INC_CSV} is missing bucket columns, re-downloading")
            os.remove(csv_path)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()
        if not key:
            raise SystemExit(
                "The Census API requires a free key (set CENSUS_API_KEY) or put your own CSV at " + csv_path)

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def num(d, var):
            try:
                return max(int(float(d[var])), 0)
            except (TypeError, ValueError):
                return 0

        counties = [row[-1] for row in census_get(
            f"https://api.census.gov/data/2020/dec/pl?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        group_vars = {g: [f"B19001_{n:03d}E" for n in nums] for g, nums in INC_GROUPS.items()}
        var_list = ",".join([INC_TOTAL_VAR, INC_MED_VAR] + [v for vs in group_vars.values() for v in vs])
        rows = []
        for cfp in counties:
            data = census_get(f"{INC_URL}?get={var_list}&for=block%20group:*"
                              f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                geoid = d["state"] + d["county"] + d["tract"] + d["block group"]
                rows.append([geoid, num(d, INC_TOTAL_VAR), num(d, INC_MED_VAR)]
                            + [sum(num(d, v) for v in vs) for vs in group_vars.values()])
            print(f"income: county {cfp} -> {len(data) - 1} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "inc_total", "inc_med"] + list(INC_GROUPS))
            w.writerows(rows)
        print(f"income: wrote {len(rows)} block groups to {csv_path}")
    out = {field: {} for field in INC_FIELDS}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            gid = row["GEOID"]
            out["inc_total"][gid] = max(int(float(row["inc_total"])), 0)
            out["inc_med"][gid] = max(int(float(row["inc_med"])), 0)
            for g in INC_GROUPS:
                out[g][gid] = max(int(float(row[g])), 0)
            for top, parts in INC_TOP_GROUPS.items():
                out[top][gid] = sum(out[p][gid] for p in parts)
    print(f"income: {len(out['inc_total'])} block groups, " + ", ".join(
        f"{f.replace('inc_', '')} {sum(v.values()):,}" for f, v in out.items() if f != "inc_med")
        + f"; {sum(1 for v in out['inc_med'].values() if v > 0):,} with a median")
    return out


def load_bg_vap_2020():
    """Return {block-group GEOID: population 18 and over} from the 2020 Census (PL 94-171 table P3).

    Cached as VAP20_CSV (GEOID,pop); otherwise downloaded from the Census API one county at a time."""
    csv_path = os.path.join(DEMO_DIR, VAP20_CSV)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        counties = [row[-1] for row in census_get(
            f"{VAP20_URL}?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        rows = []
        for cfp in counties:
            data = census_get(f"{VAP20_URL}?get={VAP20_VAR}&for=block%20group:*"
                              f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                try:
                    val = max(int(float(d[VAP20_VAR])), 0)
                except (TypeError, ValueError):
                    val = 0
                rows.append([d["state"] + d["county"] + d["tract"] + d["block group"], val])
            print(f"vap2020: county {cfp} -> {len(data) - 1} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "pop"])
            w.writerows(rows)
        print(f"vap2020: wrote {len(rows)} block groups to {csv_path}")
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        vap = {row["GEOID"]: max(int(float(row["pop"])), 0) for row in csv.DictReader(f)}
    print(f"vap2020: {len(vap)} rows, {sum(vap.values()):,} people 18+")
    return vap


def load_bg_cvap(vintage):
    """Return {GEOID: citizen voting-age population} for California block groups from the Census CVAP
    Special Tabulation of one CVAP_SOURCES vintage ("2024" = ACS 2020-2024).

    Reads the cached CSV (GEOID,cvap) if present. Otherwise downloads the vintage's zip once (about
    55 MB), streams its BlockGr.csv keeping only California's "Total" rows, and caches those. (This
    release's BlockGr.csv has citizen and CVAP columns only, no 18+ column; see load_bg_vap_acs.)"""
    cfg = CVAP_SOURCES[vintage]
    csv_path = os.path.join(DEMO_DIR, cfg["csv"])
    if not os.path.exists(csv_path):
        import urllib.request

        zip_path = os.path.join(DEMO_DIR, cfg["zip"])
        if not os.path.exists(zip_path):
            print(f"cvap[{vintage}]: downloading {cfg['url']} ...")
            req = urllib.request.Request(cfg["url"], headers={"User-Agent": "civitas-build/1.0"})
            with urllib.request.urlopen(req, timeout=600) as r, open(zip_path, "wb") as out_f:
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    out_f.write(chunk)
        rows = []
        with zipfile.ZipFile(zip_path) as z:
            name = next((n for n in z.namelist() if os.path.basename(n).lower() == "blockgr.csv"), None)
            if name is None:
                raise SystemExit(f"cvap[{vintage}]: no BlockGr.csv in {zip_path}; found {z.namelist()[:12]}")
            with z.open(name) as raw:
                reader = csv.reader(io.TextIOWrapper(raw, encoding="latin-1", newline=""))
                header = [h.strip().lower() for h in next(reader)]
                try:
                    i_geo, i_title = header.index("geoid"), header.index("lntitle")
                    i_cvap = header.index("cvap_est")
                except ValueError:
                    raise SystemExit(f"cvap[{vintage}]: unexpected BlockGr.csv columns: {header}")
                prefix = "1500000US" + POP_STATE_FIPS
                for row in reader:
                    if len(row) <= max(i_geo, i_title, i_cvap) or not row[i_geo].startswith(prefix):
                        continue
                    if row[i_title].strip().lower() != "total":
                        continue
                    try:
                        cvap = max(int(float(row[i_cvap])), 0)
                    except ValueError:
                        cvap = 0
                    rows.append([row[i_geo].split("US", 1)[1], cvap])
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "cvap"])
            w.writerows(rows)
        print(f"cvap[{vintage}]: wrote {len(rows)} block groups to {csv_path}")
    cvap = {}
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            cvap[row["GEOID"]] = max(int(float(row["cvap"])), 0)
    print(f"cvap[{vintage}]: {len(cvap)} block groups, {sum(cvap.values()):,} citizen voting age")
    return cvap


def load_bg_vap_acs(csv_name=None, api_url=None, tag="vap_acs"):
    """Return {block-group GEOID: population 18 and over} from the ACS 5-year (table B01001, sex by age):
    the total minus everyone under 18 (male variables 003-006 and female 027-030).

    Cached as VAP_ACS_CSV (GEOID,pop); otherwise downloaded from the Census API one county at a time.
    Pass csv_name/api_url for another vintage (the 2022 ACS 5-year uses the same 2020 block groups)."""
    csv_name = csv_name or VAP_ACS_CSV
    VAP_ACS_URL_ = api_url or VAP_ACS_URL
    csv_path = os.path.join(DEMO_DIR, csv_name)
    if not os.path.exists(csv_path):
        import urllib.request

        key = os.environ.get("CENSUS_API_KEY", "948d82993f762047a3e00d729a6f6a7b7f7516de").strip()

        def census_get(url):
            req = urllib.request.Request(url + f"&key={key}", headers={"User-Agent": "civitas-build/1.0"})
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    return json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                raise SystemExit(f"Census API request failed ({e!r}); check the key / network: {url[:120]}")

        def num(d, var):
            try:
                return max(int(float(d[var])), 0)
            except (TypeError, ValueError):
                return 0

        under18 = [f"B01001_{n:03d}E" for n in list(range(3, 7)) + list(range(27, 31))]
        var_list = ",".join(["B01001_001E"] + under18)
        counties = [row[-1] for row in census_get(
            f"{VAP_ACS_URL_}?get=NAME&for=county:*&in=state:{POP_STATE_FIPS}")[1:]]
        rows = []
        for cfp in counties:
            data = census_get(f"{VAP_ACS_URL_}?get={var_list}&for=block%20group:*"
                              f"&in=state:{POP_STATE_FIPS}%20county:{cfp}%20tract:*")
            hdr = data[0]
            for row in data[1:]:
                d = dict(zip(hdr, row))
                adults = max(num(d, "B01001_001E") - sum(num(d, v) for v in under18), 0)
                rows.append([d["state"] + d["county"] + d["tract"] + d["block group"], adults])
            print(f"{tag}: county {cfp} -> {len(data) - 1} block groups")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["GEOID", "pop"])
            w.writerows(rows)
        print(f"{tag}: wrote {len(rows)} block groups to {csv_path}")
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        vap = {row["GEOID"]: max(int(float(row["pop"])), 0) for row in csv.DictReader(f)}
    print(f"{tag}: {len(vap)} rows, {sum(vap.values()):,} people 18+")
    return vap


def allocate_old_bg_population(year, bg_ll):
    """Population of a past census (2010 or 2000) on the 2020 block groups, from census BLOCKS.

    Blocks nest almost entirely inside a single 2020 block group, so each block's population is
    assigned to the 2020 block group containing the block's internal point (a point-in-polygon
    lookup; no area splitting). A point on a boundary or outside every block group falls back to
    the nearest one. Statewide totals are conserved. `bg_ll` is the 2020 block-group GeoDataFrame
    in its native lat/lon CRS with a positional integer index; returns one value per row."""
    import pyogrio

    fname, url = OLD_BLOCK_SHAPES[year]
    path = os.path.join(DEMO_DIR, fname)
    if not os.path.exists(path):
        import urllib.request

        print(f"population[{year}]: downloading {url} (large, setup-only) ...")
        urllib.request.urlretrieve(url, path)
    t0 = time.time()
    attrs = pyogrio.read_dataframe("zip://" + path, read_geometry=False)
    cols = {c.upper(): c for c in attrs.columns}

    def col(prefix):
        return next(c for u, c in cols.items() if u.startswith(prefix))

    block_id = attrs[col("GEOID") if any(u.startswith("GEOID") for u in cols) else col("BLKIDFP")].astype(str)
    lat = attrs[col("INTPTLAT")].astype(float)
    lon = attrs[col("INTPTLON")].astype(float)
    pop_map = load_bg_population("vap" + year, level="block") if year == "2020" else load_bg_population(year, level="block")
    block_pop = np.array([pop_map.get(g, 0) for g in block_id], dtype=float)
    missing = int(sum(1 for g in block_id if g not in pop_map))
    keep = block_pop > 0
    pts = gpd.GeoDataFrame(
        {"pop": block_pop[keep]}, geometry=gpd.points_from_xy(lon[keep].values, lat[keep].values), crs=bg_ll.crs
    ).reset_index(drop=True)
    print(f"population[{year}]: {len(attrs):,} blocks ({int(keep.sum()):,} populated), assigning to 2020 block groups ...")

    joined = gpd.sjoin(pts, bg_ll[["geometry"]], how="left", predicate="within")
    joined = joined[~joined.index.duplicated(keep="first")].reindex(pts.index)
    bg_idx = joined["index_right"].to_numpy(dtype=float)
    unmatched = np.isnan(bg_idx)
    if unmatched.any():
        near = gpd.sjoin_nearest(
            pts[unmatched].to_crs(EQUAL_AREA_CRS), bg_ll[["geometry"]].to_crs(EQUAL_AREA_CRS), how="left"
        )
        near = near[~near.index.duplicated(keep="first")].reindex(pts.index[unmatched])
        bg_idx[unmatched] = near["index_right"].to_numpy(dtype=float)
    new_pop = np.zeros(len(bg_ll))
    np.add.at(new_pop, bg_idx.astype(int), pts["pop"].to_numpy())
    print(f"population[{year}]: {block_pop.sum():,.0f} in blocks -> {new_pop.sum():,.0f} on 2020 block groups "
          f"({int(unmatched.sum())} boundary/offshore points matched to the nearest, "
          f"{missing} blocks missing from the CSV) in {time.time()-t0:.1f}s")
    return new_pop


def overlay_areas(src_geoms, tgt_geoms, label):
    """Overlap area (equal-area CRS) between each source geometry and every target geometry it touches.

    Returns {"pid": source index, "tid": target index, "a": overlap area} as parallel arrays."""
    t0 = time.time()
    n = len(src_geoms)
    tree = STRtree(tgt_geoms)
    pid_l, tid_l, a_l = [], [], []
    n_retry = n_fail = 0
    for i, sgeom in enumerate(src_geoms):
        if sgeom is None or sgeom.is_empty:
            continue
        for j in tree.query(sgeom, predicate="intersects"):
            tgeom = tgt_geoms[j]
            try:
                area = sgeom.intersection(tgeom).area
            except Exception:
                n_retry += 1
                try:
                    area = sgeom.buffer(0).intersection(tgeom.buffer(0)).area
                except Exception:
                    try:
                        area = set_precision(sgeom, 0.01).intersection(set_precision(tgeom, 0.01)).area
                    except Exception:
                        n_fail += 1
                        continue
            if area > 0:
                pid_l.append(i)
                tid_l.append(int(j))
                a_l.append(area)
        if (i + 1) % 2000 == 0:
            print(f"  overlaid {i+1}/{n} ({label}, {time.time()-t0:.0f}s)")
    print(f"overlay[{label}]: {n_retry} pairs needed a retry, {n_fail} unrecoverable, {time.time()-t0:.1f}s")
    return {"pid": np.array(pid_l, dtype=int), "tid": np.array(tid_l, dtype=int), "a": np.array(a_l, dtype=float)}


def transfer_weights(idx, a, f, n):
    """Share of each unit (on the `idx` side of the overlay table) that goes to each row's other side.

    Uses `f`, the population living in the overlap (dasymetric), for every unit that has any; units with no
    located population (an empty precinct or one smaller than a census block) fall back to overlap area `a`.
    Sums to 1 per unit with any overlap."""
    sf = np.zeros(n)
    np.add.at(sf, idx, f)
    sa = np.zeros(n)
    np.add.at(sa, idx, a)
    use_f = sf[idx] > 0
    return np.where(use_f, f / np.where(use_f, sf[idx], 1.0), a / np.where(sa[idx] > 0, sa[idx], 1.0))


def build_dasymetric_points(year="2020"):
    """Where California's voters live: census block internal points, weighted by voting-age (18+) population.

    Uses the 2020 blocks (the geography the 2022 and 2024 precincts and today's block groups were drawn on), so
    nothing needs scaling or estimating: every block's weight is its real 2020 count of adults. This replaces plain
    area weighting, which spreads people evenly over empty land and misplaces them badly in large rural block
    groups. Returns (x, y, weight) in the equal-area CRS."""
    import pyogrio

    fname, url = OLD_BLOCK_SHAPES[year]
    path = os.path.join(DEMO_DIR, fname)
    if not os.path.exists(path):
        import urllib.request

        print(f"dasymetric: downloading {url} (large, setup-only) ...")
        urllib.request.urlretrieve(url, path)
    attrs = pyogrio.read_dataframe("zip://" + path, read_geometry=False)
    cols = {c.upper(): c for c in attrs.columns}

    def col(prefix):
        return next(c for u, c in cols.items() if u.startswith(prefix))

    block_id = attrs[col("GEOID") if any(u.startswith("GEOID") for u in cols) else col("BLKIDFP")].astype(str)
    lat = attrs[col("INTPTLAT")].astype(float).to_numpy()
    lon = attrs[col("INTPTLON")].astype(float).to_numpy()
    pop_map = load_bg_population("vap" + year, level="block") if year == "2020" else load_bg_population(year, level="block")
    pop = np.array([pop_map.get(g, 0) for g in block_id], dtype=float)
    keep = pop > 0
    pts = gpd.GeoDataFrame({"pop": pop[keep]}, geometry=gpd.points_from_xy(lon[keep], lat[keep]), crs="EPSG:4269").to_crs(EQUAL_AREA_CRS)
    x, y = pts.geometry.x.to_numpy(), pts.geometry.y.to_numpy()
    w = pts["pop"].to_numpy()
    print(f"dasymetric: {len(pts):,} populated {year} blocks of {len(attrs):,}, {w.sum():,.0f} {'adults' if year == '2020' else 'people'} "
          f"({sum(1 for g in block_id if g not in pop_map)} blocks missing from the population CSV)")
    return x, y, w


_DASY = {}


def get_dasymetric_points():
    """Population points (shapely Points array, weights), cached on disk until their inputs change."""
    if "pts" in _DASY:
        return _DASY["pts"]
    key = _hash_inputs((build_dasymetric_points,), ("EQUAL_AREA_CRS",),
                       [os.path.join(DEMO_DIR, OLD_BLOCK_SHAPES["2020"][0]),
                        os.path.join(DEMO_DIR, POP_SOURCES["vap2020"]["block_csv"])])
    path = os.path.join(CACHE_DIR, "dasymetric_%s.npz" % STATE_KEY)
    try:
        with np.load(path, allow_pickle=False) as z:
            if str(z["key"]) == key:
                x, y, w = z["x"], z["y"], z["w"]
                print(f"dasymetric: using cached population points ({len(w):,})")
                _DASY["pts"] = (shapely.points(x, y), w)
                return _DASY["pts"]
    except (OSError, ValueError, KeyError):
        pass
    x, y, w = build_dasymetric_points("2020")
    os.makedirs(CACHE_DIR, exist_ok=True)
    np.savez_compressed(path, x=x, y=y, w=w, key=np.array(key))
    _DASY["pts"] = (shapely.points(x, y), w)
    return _DASY["pts"]


def locate_points(points, geoms):
    """Index of the geometry containing each point (-1 if none). A point on a boundary, or in a gap, goes to the
    nearest geometry within 2 km; the first match wins where geometries overlap."""
    tree = STRtree(geoms)
    pi, gi = tree.query(points, predicate="within")
    out = np.full(len(points), -1, dtype=int)
    out[pi[::-1]] = gi[::-1]
    miss = np.where(out < 0)[0]
    if len(miss):
        near = tree.query_nearest(points[miss], max_distance=2000.0, all_matches=False)
        out[miss[near[0]]] = near[1]
    return out


def overlay_transfer(src_geoms, tgt_geoms, label):
    """overlay_areas plus the population living in each overlap: {"pid", "tid", "a" (area), "f" (people)}.
    Feed it to transfer_weights, which prefers `f` and falls back to `a`."""
    import pandas as pd

    inter = overlay_areas(src_geoms, tgt_geoms, label)
    points, pw = get_dasymetric_points()
    s_idx = locate_points(points, src_geoms)
    t_idx = locate_points(points, tgt_geoms)
    ok = (s_idx >= 0) & (t_idx >= 0)
    flows = pd.DataFrame({"pid": s_idx[ok], "tid": t_idx[ok], "f": pw[ok]}).groupby(["pid", "tid"], as_index=False)["f"].sum()
    area = pd.DataFrame({"pid": inter["pid"], "tid": inter["tid"], "a": inter["a"]})
    m = area.merge(flows, on=["pid", "tid"], how="outer")
    m["a"] = m["a"].fillna(0.0)
    m["f"] = m["f"].fillna(0.0)
    has_pop = np.zeros(len(src_geoms), dtype=bool)
    has_pop[m["pid"].to_numpy(dtype=int)[m["f"].to_numpy() > 0]] = True
    print(f"overlay[{label}]: {int(has_pop.sum())} of {len(src_geoms)} source units weighted by population, "
          f"{len(src_geoms) - int(has_pop.sum())} by area (no populated block inside); "
          f"{pw[~ok].sum() / pw.sum() * 100:.3f}% of population points fell outside a unit")
    return {"pid": m["pid"].to_numpy(dtype=int), "tid": m["tid"].to_numpy(dtype=int),
            "a": m["a"].to_numpy(dtype=float), "f": m["f"].to_numpy(dtype=float)}


def _concat_cols(df, cols, as_str=False):
    s = df[cols[0]].astype(str) if as_str else df[cols[0]]
    for c in cols[1:]:
        s = s + (df[c].astype(str) if as_str else df[c])
    return s


def _infer_headerless_xwalk(path, mp, sr):
    """MPREC->SRPREC pairs from a headerless two-column file with no county, as {"mkey", "skey"} (FIPS-prefixed).

    A pair is attributed to every county that has BOTH the map precinct (in the shapefile) and the SR precinct
    (in the results). Pairs that fit only one county are certain. Pairs that fit several counties are used only
    for (county, map precinct) combinations that no certain pair covers, so a pair that truly belongs to one
    county does not leak a second SR precinct onto another county's shape."""
    import pandas as pd

    x = pd.read_csv(path, header=None, names=["m", "s"], dtype=str).reset_index()
    shapes = mp[["FIPS_CODE", "PRECINCT"]].astype(str).drop_duplicates().rename(columns={"FIPS_CODE": "fips", "PRECINCT": "m"})
    srs = sr.reset_index()[["FIPS", "SRPREC"]].astype(str).drop_duplicates().rename(columns={"FIPS": "fips", "SRPREC": "s"})
    cand = x.merge(shapes, on="m").merge(srs, on=["fips", "s"])
    n_counties = cand.groupby("index")["fips"].transform("nunique")
    certain = cand[n_counties == 1]
    maybe = cand[n_counties > 1]
    covered = certain[["fips", "m"]].drop_duplicates().assign(_covered=1)
    maybe = maybe.merge(covered, on=["fips", "m"], how="left")
    maybe = maybe[maybe["_covered"].isna()]
    both = pd.concat([certain[["fips", "m", "s"]], maybe[["fips", "m", "s"]]]).drop_duplicates()
    print(f"headerless MPREC->SRPREC table: {len(x)} rows, {len(certain)} placed in one county for certain, "
          f"{len(maybe)} placed by elimination, {len(x) - cand['index'].nunique()} unplaceable")
    return pd.DataFrame({"mkey": both["fips"] + both["m"], "skey": both["fips"] + both["s"]})


def _shapes_from_blocks(blk_zip, sr, specs, have):
    """Shapes for SR precincts that have votes but no map shape, built from 2010 census blocks.

    The Statewide Database's SR-precinct-to-2010-block table lists, for each SR precinct, the blocks its
    registered voters live in and what share of each block's voters belong to it. A missing precinct's shape is
    the union of the blocks that mostly (50%+) belong to it, or its single biggest block if none do. Returns a
    GeoDataFrame in the equal-area CRS indexed by SR key, or None if nothing is missing."""
    import pandas as pd
    import pyogrio

    cols = sorted({c for spec in specs.values() for side in ("dem", "rep", "other") for c in spec[side]})
    votes = sr[cols].sum(axis=1)
    need = votes[(votes > 0) & ~votes.index.isin(have)].index
    if len(need) == 0:
        return None
    with zipfile.ZipFile(blk_zip) as z:
        blk = pd.read_csv(z.open(z.namelist()[0]), dtype={"SRPREC_KEY": str, "BLOCK_KEY": str},
                          usecols=["SRPREC_KEY", "BLOCK_KEY", "BLKREG", "PCTBLK"])
    blk = blk[blk["SRPREC_KEY"].isin(need)]
    keep = blk[blk["PCTBLK"] >= 50]
    top = blk.sort_values("BLKREG", ascending=False).drop_duplicates("SRPREC_KEY")
    keep = pd.concat([keep, top[~top["SRPREC_KEY"].isin(keep["SRPREC_KEY"])]])
    counties = sorted({k[2:5] for k in keep["BLOCK_KEY"]})
    path = os.path.join(DEMO_DIR, OLD_BLOCK_SHAPES["2010"][0])
    quoted = ",".join("'%s'" % c for c in counties)
    blocks = pyogrio.read_dataframe("zip://" + path, where=f"COUNTYFP10 IN ({quoted})")
    id_col = next(c for c in blocks.columns if c.upper().startswith("GEOID"))
    blocks = blocks[blocks[id_col].isin(set(keep["BLOCK_KEY"]))].to_crs(EQUAL_AREA_CRS)
    geom_by_block = dict(zip(blocks[id_col], blocks.geometry.make_valid()))
    keys, geoms = [], []
    for key, grp in keep.groupby("SRPREC_KEY"):
        polys = [geom_by_block[b] for b in grp["BLOCK_KEY"] if b in geom_by_block]
        if polys:
            keys.append(key)
            geoms.append(shapely.union_all(polys))
    print(f"  rebuilt shapes for {len(keys)} of {len(need)} SR precincts with votes but no map shape, from 2010 blocks")
    return gpd.GeoDataFrame(geometry=geoms, index=pd.Index(keys, name="skey"), crs=EQUAL_AREA_CRS)


def swdb_set_names(race_keys=None):
    """Names of the Statewide Database vintages used by the given races (all races by default)."""
    keys = RACES if race_keys is None else race_keys
    return sorted({RACES[k]["swdb"]["set"] for k in keys if "swdb" in RACES[k]})


def load_swdb_sources(set_name):
    """One Statewide Database vintage's results matched to its map, ready to be allocated to other geographies.

    The Statewide Database reports votes by SR precinct; its map is in smaller master precincts (MPRECs).
    The MPREC->SRPREC table says which MPRECs make up each SR precinct, so the MPREC shapes are dissolved into
    SR precinct shapes and each SR precinct's votes are attached to its shape. Returns
    {"geoms": [shape in the equal-area CRS], "races": {race_key: {"dem"/"rep"/"other": array}}}."""
    import pandas as pd

    t0 = time.time()
    cfg = SWDB_SETS[set_name]
    with zipfile.ZipFile(cfg["sr_zip"]) as z:
        sr = pd.read_csv(z.open(cfg["sr_csv"]), dtype={"SRPREC_KEY": str, "SRPREC": str, "FIPS": str})
    sr = sr.set_index("SRPREC_KEY")
    specs = {rkey: spec["swdb"] for rkey, spec in RACES.items() if "swdb" in spec and spec["swdb"]["set"] == set_name}
    for cols in specs.values():
        for side in ("dem", "rep", "other"):
            for c in cols[side]:
                sr[c] = pd.to_numeric(sr[c], errors="coerce").fillna(0.0)

    mp = gpd.read_file("zip://" + cfg["mprec_zip"])
    if cfg.get("crs"):
        mp = mp.set_crs(cfg["crs"], allow_override=True)
    elif mp.crs is None:
        mp = mp.set_crs("EPSG:4269")
    if cfg.get("xw_headerless"):
        xw = _infer_headerless_xwalk(cfg["xwalk"], mp, sr)
    else:
        xw = pd.read_csv(cfg["xwalk"], dtype=str)
        xw["mkey"] = _concat_cols(xw, cfg["xw_mkey"])
        xw["skey"] = _concat_cols(xw, cfg["xw_skey"])
    mp["mkey"] = _concat_cols(mp, cfg["shape_key"], as_str=True)
    n_mp = len(mp)
    mp = mp.merge(xw[["mkey", "skey"]], on="mkey", how="inner")
    print(f"{set_name} map: {len(mp)} of {n_mp} master precincts are in the MPREC->SRPREC table "
          f"(the rest are water/unpopulated areas)")
    mp = mp[["skey", "geometry"]].to_crs(EQUAL_AREA_CRS)
    mp["geometry"] = mp.geometry.make_valid()
    sr_geo = mp.dissolve(by="skey")
    sr_geo["geometry"] = sr_geo.geometry.make_valid()
    if cfg.get("sr_blk"):
        extra = _shapes_from_blocks(cfg["sr_blk"], sr, specs, sr_geo.index)
        if extra is not None:
            sr_geo = pd.concat([sr_geo, extra])
    placed = sr_geo.index.isin(sr.index)
    sr_geo = sr_geo[placed]
    vals = sr.loc[sr_geo.index]
    unplaced = sr[~sr.index.isin(sr_geo.index)]
    print(f"{set_name} results: {len(sr)} SR precincts, {len(sr_geo)} matched to map shapes, "
          f"{len(unplaced)} with no shape in the MPREC table (see vote totals below)")

    races = {}
    sr_cd = pd.to_numeric(vals["CDDIST"], errors="coerce").to_numpy() if "CDDIST" in vals.columns else None
    for rkey, cols in specs.items():
        races[rkey] = {}
        in_district = (sr_cd == cols["district"]).astype(float) if "district" in cols else None
        for side in ("dem", "rep", "other"):
            arr = vals[cols[side]].sum(axis=1).to_numpy(dtype=float) if cols[side] else np.zeros(len(vals))
            if in_district is not None:
                races[rkey][side] = arr * in_district
                continue
            races[rkey][side] = arr
            lost = float(unplaced[cols[side]].to_numpy().sum()) if cols[side] else 0.0
            print(f"  {rkey}.{side}: {float(sr[cols[side]].to_numpy().sum()) if cols[side] else 0:,.0f} reported, "
                  f"{arr.sum():,.0f} matched to shapes, {lost:,.0f} in SR precincts with no shape")
    print(f"{set_name} sources ready in {time.time()-t0:.1f}s")
    return {"geoms": list(sr_geo.geometry.values), "races": races}


def load_all_sources(race_keys=None):
    return {name: load_swdb_sources(name) for name in swdb_set_names(race_keys)}


def attach_sources_to_precincts(records, srcs):
    """Allocate older elections' votes onto the 2024 precincts: each old precinct's votes are split across the
    2024 precincts it overlaps in proportion to the voting-age population living in each overlap (area where an
    old precinct has no populated block). Totals are conserved."""
    n = len(records)
    pg = gpd.GeoDataFrame({"pid": np.arange(n)}, geometry=[r["geom"] for r in records], crs="EPSG:4326").to_crs(EQUAL_AREA_CRS)
    pg_geoms = list(pg.geometry.make_valid().values)
    for name, src in srcs.items():
        inter = overlay_transfer(src["geoms"], pg_geoms, f"{name} precincts -> 2024 precincts")
        w = transfer_weights(inter["pid"], inter["a"], inter["f"], len(src["geoms"]))
        for rkey, sides in src["races"].items():
            alloc = {}
            for side, vals in sides.items():
                dst = np.bincount(inter["tid"], weights=vals[inter["pid"]] * w, minlength=n)
                alloc[side] = np.rint(dst)
                print(f"  {rkey}.{side}: {name} precincts {vals.sum():,.0f} -> 2024 precincts {alloc[side].sum():,.0f}")
            for k, r in enumerate(records):
                r["races"][rkey] = {side: float(alloc[side][k]) for side in ("dem", "rep", "other")}


def load_block_groups():
    """2025 TIGER block groups: (lat/lon frame, valid equal-area copy), in a fixed row order."""
    bg_ll = gpd.read_file("zip://" + BG_ZIP_PATH)
    bg_ll = bg_ll.reset_index(drop=True)
    bg_ll["bgi"] = np.arange(len(bg_ll))
    bg_m = bg_ll.to_crs(EQUAL_AREA_CRS)
    bg_m["geometry"] = bg_m.geometry.make_valid()
    return bg_ll, bg_m


CACHE_DIR = os.path.join(CIVITAS_DIR, "data", ".cache")


def overlay_cache_path():
    return os.path.join(CACHE_DIR, "overlay_%s.npz" % STATE_KEY)


def records_shape_hash(records):
    """Hash of the precinct shapes, ids, counties and registration. If it is unchanged, results-only updates
    can reuse the cached precinct->block-group overlay instead of redoing the geometry work."""
    h = hashlib.sha256()
    for wkb in shapely.to_wkb(np.array([r["geom"] for r in records], dtype=object)):
        h.update(wkb)
    for r in records:
        h.update(f"{r['county']}|{r['precinct']}|{r['totreg']}".encode("utf-8"))
    return h.hexdigest()


def save_overlay_cache(records, inter, nbg, keep_idx, out):
    """Keep the precinct->block-group overlap table and which block groups were kept, so a results-only
    rebuild can allocate new votes to block groups without recomputing the overlay or the demographics."""
    os.makedirs(CACHE_DIR, exist_ok=True)
    np.savez_compressed(
        overlay_cache_path(), pid=inter["pid"], bgi=inter["bgi"], a=inter["a"], f=inter["f"], nbg=np.array(nbg),
        keep_idx=np.array(keep_idx, dtype=int), geoid=np.array([o["precinct"] for o in out]),
        county=np.array([o["county"] for o in out]), geom_hash=np.array(records_shape_hash(records)),
        base_fp=np.array(base_fingerprint()))


def load_overlay_cache():
    try:
        with np.load(overlay_cache_path(), allow_pickle=False) as z:
            return {k: z[k] for k in z.files}
    except (OSError, ValueError):
        return None


def interpolate_to_block_groups(records, srcs=None):
    """Area-weighted allocation of precinct votes onto 2025 TIGER block groups.

    Each precinct's votes are split across the block groups it overlaps in proportion to
    overlapping land area (in an equal-area projection). Weights are normalised per precinct
    so total votes are conserved. This is an estimate: votes are assumed evenly spread
    across each precinct."""
    t0 = time.time()
    n = len(records)
    pg = gpd.GeoDataFrame({"pid": np.arange(n)}, geometry=[r["geom"] for r in records], crs="EPSG:4326").to_crs(EQUAL_AREA_CRS)
    pg["geometry"] = pg.geometry.make_valid()

    bg_ll, bg_m = load_block_groups()
    print(f"interpolate: {n} precincts -> {len(bg_ll)} block groups, overlaying...")

    p_geoms = list(pg.geometry.values)
    b_geoms = list(bg_m.geometry.values)
    ov = overlay_transfer(p_geoms, b_geoms, "precincts -> block groups")
    inter = {"pid": ov["pid"], "bgi": ov["tid"], "a": ov["a"], "f": ov["f"]}
    ov_by_set = {}
    for set_name, src in (srcs or {}).items():
        ov_set = overlay_transfer(src["geoms"], b_geoms, f"{set_name} precincts -> block groups")
        ov_by_set[set_name] = (ov_set, transfer_weights(ov_set["pid"], ov_set["a"], ov_set["f"], len(src["geoms"])))
    pid = inter["pid"]
    bgi = inter["bgi"]
    w = transfer_weights(pid, inter["a"], inter["f"], n)
    covered = np.zeros(n, dtype=bool)
    covered[pid] = True
    print(f"interpolate: overlay done in {time.time()-t0:.1f}s, {int((~covered).sum())} precincts had no overlap")

    nbg = len(bg_ll)
    has_area = np.zeros(nbg, dtype=bool)
    has_area[bgi] = True

    totreg_p = np.array([r["totreg"] for r in records])
    totreg_bg = np.zeros(nbg)
    np.add.at(totreg_bg, bgi, totreg_p[pid] * w)

    bg_geoids = list(bg_ll["GEOID"])
    pop_bg = {}
    for src in ("acs", "2020"):
        m = load_bg_population(src)
        pop_bg[src] = np.array([m.get(g, 0) for g in bg_geoids], dtype=float)
        miss = sum(1 for g in bg_geoids if g not in m)
        print(f"population[{src}]: {pop_bg[src].sum():,.0f} on 2020 block groups ({miss} block groups missing from the CSV)")
    for src in ("2010", "2000"):
        pop_bg[src] = allocate_old_bg_population(src, bg_ll)
    vap20_map = load_bg_vap_2020()
    extra_pop = {
        "vap_2020": vap20_map,
        "vap_acs": load_bg_vap_acs(),
        "vap_acs22": load_bg_vap_acs(VAP22_CSV, VAP22_URL, "vap_acs22"),
        "cvap_acs": load_bg_cvap("2024"),
    }
    for src, m in extra_pop.items():
        pop_bg[src] = np.array([m.get(g, 0) for g in bg_geoids], dtype=float)
        miss = sum(1 for g in bg_geoids if g not in m)
        print(f"population[{src}]: {pop_bg[src].sum():,.0f} on 2020 block groups ({miss} block groups missing)")

    eth_map = load_bg_ethnicity()
    eth_bg = {field: np.array([m.get(g, 0) for g in bg_geoids], dtype=float) for field, m in eth_map.items()}
    edu_map = load_bg_education()
    edu_bg = {field: np.array([m.get(g, 0) for g in bg_geoids], dtype=float) for field, m in edu_map.items()}
    age_map = load_bg_age()
    age_bg = {field: np.array([m.get(g, 0) for g in bg_geoids], dtype=float) for field, m in age_map.items()}
    origin_map = load_tract_origin()
    tract_of = [g[:11] for g in bg_geoids]
    tract_pop, tract_n = {}, {}
    for t, p in zip(tract_of, pop_bg["acs"]):
        tract_pop[t] = tract_pop.get(t, 0.0) + p
        tract_n[t] = tract_n.get(t, 0) + 1
    tract_share = np.array([(p / tract_pop[t]) if tract_pop[t] > 0 else 1.0 / tract_n[t] for t, p in zip(tract_of, pop_bg["acs"])])
    origin_bg = {field: np.array([m.get(t, 0) for t in tract_of], dtype=float) * tract_share for field, m in origin_map.items()}
    lang_map = load_bg_language()
    lang_bg = {field: np.array([m.get(g, 0) for g in bg_geoids], dtype=float) for field, m in lang_map.items()}
    inc_map = load_bg_income()
    inc_bg = {field: np.array([m.get(g, 0) for g in bg_geoids], dtype=float) for field, m in inc_map.items()}

    w_rev = transfer_weights(bgi, inter["a"], inter["f"], len(bg_ll))
    for src, field in POP_FIELDS.items():
        pop_p = np.zeros(n)
        np.add.at(pop_p, pid, pop_bg[src][bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(pop_p[k])
        print(f"population[{src}]: {pop_bg[src].sum():,.0f} in block groups -> {pop_p.sum():,.0f} in precincts "
              f"({pop_bg[src][~has_area].sum():,.0f} in block groups with no precinct overlap)")
    for field, arr in eth_bg.items():
        eth_p = np.zeros(n)
        np.add.at(eth_p, pid, arr[bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(eth_p[k])
        print(f"ethnicity[{field}]: {arr.sum():,.0f} in block groups -> {eth_p.sum():,.0f} in precincts")
    for field, arr in edu_bg.items():
        edu_p = np.zeros(n)
        np.add.at(edu_p, pid, arr[bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(edu_p[k])
        print(f"education[{field}]: {arr.sum():,.0f} in block groups -> {edu_p.sum():,.0f} in precincts")
    for field, arr in origin_bg.items():
        origin_p = np.zeros(n)
        np.add.at(origin_p, pid, arr[bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(origin_p[k])
        print(f"origin[{field}]: {arr.sum():,.0f} in block groups -> {origin_p.sum():,.0f} in precincts")
    for field, arr in lang_bg.items():
        lang_p = np.zeros(n)
        np.add.at(lang_p, pid, arr[bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(lang_p[k])
        print(f"language[{field}]: {arr.sum():,.0f} in block groups -> {lang_p.sum():,.0f} in precincts")
    for field, arr in age_bg.items():
        age_p = np.zeros(n)
        np.add.at(age_p, pid, arr[bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(age_p[k])
        print(f"age[{field}]: {arr.sum():,.0f} in block groups -> {age_p.sum():,.0f} in precincts")
    for field, arr in inc_bg.items():
        if field == "inc_med":
            continue
        inc_p = np.zeros(n)
        np.add.at(inc_p, pid, arr[bgi] * w_rev)
        for k, r in enumerate(records):
            r[field] = float(inc_p[k])
        print(f"income[{field}]: {arr.sum():,.0f} in block groups -> {inc_p.sum():,.0f} in precincts")
    has_med = inc_bg["inc_med"] > 0
    med_w = np.zeros(n)
    med_hh = np.zeros(n)
    np.add.at(med_w, pid, (inc_bg["inc_med"] * inc_bg["inc_total"])[bgi] * w_rev)
    np.add.at(med_hh, pid, np.where(has_med, inc_bg["inc_total"], 0.0)[bgi] * w_rev)
    for k, r in enumerate(records):
        r["inc_med"] = float(med_w[k] / med_hh[k]) if med_hh[k] > 0 else 0.0
    print(f"income[inc_med]: {int((med_hh > 0).sum()):,} of {n:,} precincts got a median")

    race_bg = {}
    for rkey in RACES:
        race_bg[rkey] = {}
        if "swdb" in RACES[rkey]:
            set_name = RACES[rkey]["swdb"]["set"]
            if set_name not in ov_by_set:
                raise SystemExit(f"{rkey} needs the {set_name} sources but none were passed")
            # Older votes go straight from their own precincts to block groups (not via the 2024 precincts).
            ov_set, w_set = ov_by_set[set_name]
            for f in ("dem", "rep", "other"):
                src = srcs[set_name]["races"][rkey][f]
                dst = np.bincount(ov_set["tid"], weights=src[ov_set["pid"]] * w_set, minlength=nbg)
                race_bg[rkey][f] = np.rint(dst)
                print(f"  {rkey}.{f}: {set_name} precincts {src.sum():,.0f} -> block groups {dst.sum():,.0f}")
            continue
        for f in ("dem", "rep", "other"):
            src = np.array([r["races"][rkey][f] for r in records])
            dst = np.bincount(bgi, weights=src[pid] * w, minlength=nbg)
            race_bg[rkey][f] = np.rint(dst)
            print(f"  {rkey}.{f}: source {src.sum():,.0f} -> block groups {dst.sum():,.0f}")

    fips_to_county = {r["countyfp"][-3:]: r["county"] for r in records}
    out = []
    keep_idx = []
    for i in range(nbg):
        row = bg_ll.iloc[i]
        if not has_area[i] and row["GEOID"] not in KEEP_WATER_BGS:
            continue
        county = fips_to_county.get(row["COUNTYFP"])
        if county is None:
            continue
        keep_idx.append(i)
        out.append(
            {
                "precinct": row["GEOID"],
                "unique_id": row["GEOID"],
                "county": county,
                "totreg": float(np.rint(totreg_bg[i])),
                **{field: float(pop_bg[src][i]) for src, field in POP_FIELDS.items()},
                **{field: float(eth_bg[field][i]) for field in ETH_VARS},
                **{field: float(edu_bg[field][i]) for field in EDU_FIELDS},
                **{field: float(age_bg[field][i]) for field in AGE_FIELDS},
                **{field: float(lang_bg[field][i]) for field in LANG_FIELDS},
                **{field: float(origin_bg[field][i]) for field in ORIGIN_FIELDS},
                **{field: float(inc_bg[field][i]) for field in INC_FIELDS},
                "geom": row["geometry"],
                "races": {rk: {f: float(race_bg[rk][f][i]) for f in ("dem", "rep", "other")} for rk in RACES},
            }
        )
    print(f"interpolate: {len(out)} block groups kept in {time.time()-t0:.1f}s")
    save_overlay_cache(records, inter, nbg, keep_idx, out)
    return out


def ring_to_path(coords, project):
    parts = []
    last = None
    for lon, lat in coords:
        x, y = project(lon, lat)
        p = f"{x:.2f},{y:.2f}"
        if p != last:
            parts.append(p)
            last = p
    if len(parts) > 1 and parts[0] != parts[-1]:
        parts.append(parts[0])
    return "M " + " ".join(parts) + " Z"


SLIVER_RING_AREA = 0.02  # map units^2; the map is ~1000 units wide, so this is far below one visible pixel


def ring_is_sliver(coords, project):
    """True for a degenerate ring (a spike or hairline left by snapping/simplifying). It encloses no visible
    area, but the precinct border stroke draws it as a stray line that belongs to nothing."""
    pts = [project(lon, lat) for lon, lat in coords]
    area = 0.0
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        area += x0 * y1 - x1 * y0
    return abs(area) / 2 < SLIVER_RING_AREA


def geom_to_path(geom, project):
    gj = mapping(geom)
    parts = []
    if gj["type"] == "Polygon":
        rings = gj["coordinates"]
        kept = [r for r in rings if not ring_is_sliver(r, project)] or rings
        for ring in kept:
            parts.append(ring_to_path(ring, project))
    elif gj["type"] == "MultiPolygon":
        # Drop sliver rings, but never a precinct's last remaining ring (it would vanish from the map).
        rings = [ring for poly in gj["coordinates"] for ring in poly]
        kept = [r for r in rings if not ring_is_sliver(r, project)] or rings
        for ring in kept:
            parts.append(ring_to_path(ring, project))
    elif gj["type"] == "GeometryCollection":
        # make_valid on a self-intersecting precinct can return a collection (polygons plus stray lines/points);
        # without this branch the precinct came out with an empty path and was never drawn (Kings 1110, 1424).
        for sub in geom.geoms:
            sub_path = geom_to_path(sub, project)
            if sub_path:
                parts.append(sub_path)
    return " ".join(parts)


def snap_to_grid(geoms):
    """Snap every vertex to the GRID_UNIT grid. Fast vectorized path first; if GEOS rejects any shape
    ("unable to assign free hole to a shell" and similar), redo it shape by shape, retrying a failing shape
    after make_valid and finally with pointwise snapping (no topology repair, so it can't throw)."""
    geoms = np.asarray(geoms, dtype=object)
    try:
        return shapely.set_precision(geoms, GRID_UNIT)
    except shapely.errors.GEOSException:
        pass
    out = np.empty(len(geoms), dtype=object)
    repaired = pointwise = kept = 0
    for i, g in enumerate(geoms):
        try:
            out[i] = shapely.set_precision(g, GRID_UNIT)
            continue
        except shapely.errors.GEOSException:
            pass
        try:
            out[i] = shapely.set_precision(shapely.make_valid(g), GRID_UNIT)
            repaired += 1
            continue
        except shapely.errors.GEOSException:
            pass
        try:
            out[i] = shapely.set_precision(g, GRID_UNIT, mode="pointwise")
            pointwise += 1
        except (shapely.errors.GEOSException, ValueError):
            out[i] = g
            kept += 1
    print(f"snap to grid: vectorized snap failed; {repaired} shapes needed make_valid, "
          f"{pointwise} snapped pointwise, {kept} left unsnapped")
    return out


def simplify_as_coverage(geoms):
    """Simplify projected, grid-snapped polygons so neighbors keep identical shared borders.

    shapely.coverage_simplify treats the shapes as a coverage: an edge two shapes share is simplified once
    and used by both, so simplification can't open gaps or overlaps between them (simplifying each shape
    on its own can). Shapes the coverage check flags (overlapping or non-matching edges) and any
    non-polygon results are simplified individually instead."""
    geoms = np.asarray(geoms, dtype=object)
    out = np.empty(len(geoms), dtype=object)
    try:
        tid = shapely.get_type_id(geoms)
        use = (tid == 3) | (tid == 6)
        bad = np.zeros(len(geoms), dtype=bool)
        if use.any():
            inv = shapely.coverage_invalid_edges(geoms[use])
            bad_sub = np.array([g is not None and not g.is_empty for g in inv], dtype=bool)
            bad[np.flatnonzero(use)[bad_sub]] = True
        good = use & ~bad
        if good.any():
            out[good] = shapely.coverage_simplify(geoms[good], COVERAGE_TOLERANCE)
        rest = ~good
        if rest.any():
            out[rest] = shapely.simplify(geoms[rest], COVERAGE_TOLERANCE, preserve_topology=True)
        print(f"coverage simplify: {int(good.sum())} shapes as a coverage, "
              f"{int(bad.sum())} flagged as overlapping/non-matching, {int((~use).sum())} non-polygon")
    except (AttributeError, shapely.errors.GEOSException) as err:
        print(f"coverage simplify unavailable ({err!r}); simplifying each shape on its own")
        out = shapely.simplify(geoms, COVERAGE_TOLERANCE, preserve_topology=True)
    return out


def albers_raw(lon, lat):
    """Spherical Albers equal-area conic on the unit sphere (lon/lat in degrees; numpy arrays or scalars).

    The page re-implements this exact formula in JavaScript (makeProjection), using the parameters written to
    geometry/manifest.json, so the background map lines up with the shapes. Keep the two in step."""
    p = STATE_PROJECTION
    phi1, phi2, phi0 = (np.radians(p[k]) for k in ("lat1", "lat2", "lat0"))
    n = (np.sin(phi1) + np.sin(phi2)) / 2
    c = np.cos(phi1) ** 2 + 2 * n * np.sin(phi1)
    rho0 = np.sqrt(c - 2 * n * np.sin(phi0)) / n
    rho = np.sqrt(c - 2 * n * np.sin(np.radians(lat))) / n
    theta = n * (np.radians(lon) - np.radians(p["lon0"]))
    return rho * np.sin(theta), rho0 - rho * np.cos(theta)


def build_geometry(records):
    source = np.array([r["geom"] for r in records], dtype=object)

    def to_raw(coords):
        x, y = albers_raw(coords[:, 0], coords[:, 1])
        return np.column_stack([x, y])

    raw = shapely.transform(source, to_raw)
    xmin, ymin, xmax, ymax = (float(v) for v in shapely.total_bounds(raw))
    scale = TARGET_W / (xmax - xmin)
    target_h = (ymax - ymin) * scale

    def project(lon, lat):
        x, y = albers_raw(lon, lat)
        return float((x - xmin) * scale), float((ymax - y) * scale)

    PROJECTION["project"] = project
    PROJECTION["params"] = dict({"kind": "albers"}, **STATE_PROJECTION, xmin=xmin, ymax=ymax, scale=scale)

    def to_xy(coords):
        xy = np.empty_like(coords, dtype=float)
        xy[:, 0] = (coords[:, 0] - xmin) * scale
        xy[:, 1] = (ymax - coords[:, 1]) * scale
        return xy

    projected = shapely.transform(raw, to_xy)
    snapped = snap_to_grid(projected)
    snapped = np.where(shapely.is_empty(snapped), projected, snapped)
    final = simplify_as_coverage(snapped)
    final = np.where(shapely.is_empty(final), snapped, final)

    out_records = []
    total_path_chars = 0
    identity = lambda x, y: (x, y)
    for r, g in zip(records, final):
        d = geom_to_path(g, identity)
        total_path_chars += len(d)

        bx0, by0, bx1, by1 = g.bounds

        out_records.append(
            {
                "precinct": r["precinct"],
                "county": r["county"],
                "totreg": int(r["totreg"]),
                **{field: int(round(r.get(field, 0))) for field in list(POP_FIELDS.values()) + list(ETH_VARS) + EDU_FIELDS + AGE_FIELDS + ORIGIN_FIELDS + LANG_FIELDS + INC_FIELDS},
                "d": d,
                "bbox": [bx0, by0, bx1, by1],
            }
        )

    print("geometry:", len(out_records), "precincts,",
          "%.1fMB" % (total_path_chars / 1e6), "of path data,",
          "viewbox %sx%.0f" % (TARGET_W, target_h))
    return out_records, TARGET_W, target_h


def build_county_borders():
    names = {}
    if os.path.exists(COUNTY_CSV_PATH):
        with open(COUNTY_CSV_PATH, newline="", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                names[str(row["id"])] = row["Name"]

    with open(COUNTY_GEOJSON_PATH, encoding="utf-8") as f:
        gj = json.load(f)

    project = PROJECTION["project"]
    out = []
    for feat in gj["features"]:
        geom = shape(feat["geometry"])
        simplified = geom.simplify(COUNTY_TOLERANCE, preserve_topology=True)
        if simplified.is_empty:
            simplified = geom
        cid = str(feat["properties"].get("id"))
        out.append({"id": cid, "name": names.get(cid, cid), "d": geom_to_path(simplified, project)})
    print("county borders:", len(out), "counties")
    return out


def write_data(records, geo_records, W, H, state_key):
    data_dir = os.path.join(CIVITAS_DIR, "data", state_key)
    os.makedirs(data_dir, exist_ok=True)

    geo_by_county = {}
    for gr in geo_records:
        geo_by_county.setdefault(gr["county"], []).append(gr)

    geo_dir = os.path.join(data_dir, "geometry")
    os.makedirs(geo_dir, exist_ok=True)
    geo_manifest_files = []
    for county, county_records in sorted(geo_by_county.items()):
        fname = "precincts-%s.json" % slugify(county)
        with open(os.path.join(geo_dir, fname), "w", encoding="utf-8") as f:
            json.dump({"records": county_records}, f)
        geo_manifest_files.append(fname)
    with open(os.path.join(geo_dir, "counties.json"), "w", encoding="utf-8") as f:
        json.dump({"records": build_county_borders()}, f)
    with open(os.path.join(geo_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"width": W, "height": H, "files": geo_manifest_files, "counties": "counties.json",
                   "projection": PROJECTION.get("params")}, f)
    print(f"geometry data: {len(geo_by_county)} counties, {len(geo_records)} precincts -> {geo_dir}")

    entries = write_race_sets(records, state_key, list(RACE_META))
    write_races_index(state_key, entries)


def write_race_sets(units, state_key, race_keys):
    """Write the per-county vote files and manifest for each race in `race_keys`.

    `units` are the map units (precincts or block groups) as dicts with "precinct", "county" and "races".
    Returns {race_key: its entry for races.json}. Races not in `race_keys` are left untouched."""
    data_dir = os.path.join(CIVITAS_DIR, "data", state_key)
    entries = {}
    for race_key in race_keys:
        meta = RACE_META[race_key]
        sparse = bool(meta.get("sparse"))
        race_dir = os.path.join(data_dir, race_key)
        os.makedirs(race_dir, exist_ok=True)

        by_county = {}
        for vr in units:
            votes = vr["races"][race_key]
            if sparse and not (votes["dem"] or votes["rep"] or votes["other"]):
                continue
            rec = {
                "precinct": vr["precinct"],
                "county": vr["county"],
                "dem": int(votes["dem"]),
                "rep": int(votes["rep"]),
                "other": int(votes["other"]),
            }
            if meta.get("sparse") and not (rec["dem"] or rec["rep"] or rec["other"]):
                continue
            by_county.setdefault(vr["county"], []).append(rec)

        total_dem = sum(r["dem"] for county_records in by_county.values() for r in county_records)
        total_rep = sum(r["rep"] for county_records in by_county.values() for r in county_records)
        two_party = total_dem + total_rep
        if two_party > 0:
            statewide_margin = (total_dem - total_rep) / two_party
            winner = "dem" if statewide_margin >= 0 else "rep"
            tag = meta.get("demTag", "D") if statewide_margin >= 0 else meta.get("repTag", "R")
            margin_text = "%s+%d" % (tag, round(abs(statewide_margin) * 100))
        else:
            winner = None
            margin_text = None
        print(f"{race_key}: statewide margin {margin_text}")

        manifest_files = []
        for county, county_records in sorted(by_county.items()):
            fname = "votes-%s.json" % slugify(county)
            out_path = os.path.join(race_dir, fname)
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump({"records": county_records}, f)
            manifest_files.append(fname)

        manifest_path = os.path.join(race_dir, "manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump({"files": manifest_files}, f)

        total_precincts = sum(len(v) for v in by_county.values())
        print(f"{race_key}: {len(by_county)} counties, {total_precincts} precincts -> {race_dir}")

        entries[race_key] = {
            "key": race_key,
            "year": meta["year"],
            "label": meta["label"],
            "legend": meta["legend"],
            "demName": meta["demName"],
            "repName": meta["repName"],
            "demShort": meta["demShort"],
            "repShort": meta["repShort"],
            "hasOther": meta["hasOther"],
            "blurb": meta["blurb"],
            "demColor": meta.get("demColor"),
            "repColor": meta.get("repColor"),
            "margin": round(statewide_margin, 4) if two_party > 0 else None,
            "marginText": margin_text,
            "winner": winner,
            "group": meta.get("group"),
            "moreGroup": meta.get("moreGroup"),
            "sparse": bool(meta.get("sparse")),
            "manifest": "data/%s/%s/manifest.json" % (state_key, race_key),
        }
    return entries


def write_races_index(state_key, fresh_entries):
    """Write races.json in RACE_META order, taking `fresh_entries` for the races just rewritten and the
    existing races.json entry for every other race. Returns False (writing nothing) if an untouched race has
    no existing entry, so the caller can fall back to a full build."""
    path = os.path.join(CIVITAS_DIR, "data", state_key, "races.json")
    old = {}
    try:
        with open(path, encoding="utf-8") as f:
            old = {e["key"]: e for e in json.load(f).get("races", [])}
    except (OSError, ValueError):
        pass
    races_index = []
    for race_key in RACE_META:
        entry = fresh_entries.get(race_key) or old.get(race_key)
        if entry is None:
            return False
        races_index.append(entry)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"races": races_index, "geometry": "data/%s/geometry/manifest.json" % state_key}, f)
    print("wrote", path, "with", len(races_index), "races (%d rewritten)" % len(fresh_entries))
    return True


def write_html():
    html = r"""<meta charset="utf-8">
<title>ElectionCord's Civitas</title>
<link rel="icon" type="image/jpeg" href="favicon.jpg">
<link rel="apple-touch-icon" href="favicon.jpg">
<meta name="description" content="Zoomable precinct-level California election results, colored by margin.">
<style>
:root {
  --dem: #1375B7;
  --rep: #C93135;
  --dem-mid: #9dc3e2;
  --rep-mid: #e8a6a7;
  --bg: #ffffff;
  --surface: #ffffff;
  --border: #d8dbe0;
  --text: #14181f;
  --text-dim: #666e7a;
  --accent: #b9862e;
  --district-sidebar-w: 310px;
  --panel-gap: 8px;
  --sidebar-w: 0px;
  --right-sidebar-w: 270px;
  color-scheme: light;
}
* { box-sizing: border-box; }
html, body {
  height: 100%;
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font-family: "IBM Plex Sans", -apple-system, "Segoe UI", sans-serif;
  overflow: hidden;
  overscroll-behavior: none;
}
#stage {
  position: fixed;
  top: 0;
  left: calc(var(--district-sidebar-w) + var(--panel-gap) + var(--sidebar-w));
  right: var(--right-sidebar-w);
  bottom: 0;
  background: var(--bg);
  touch-action: none;
  transition: left 0.22s cubic-bezier(.32,.72,0,1), right 0.22s cubic-bezier(.32,.72,0,1);
}
#map {
  width: 100%;
  height: 100%;
  display: block;
  cursor: grab;
  touch-action: none;
}
#map.panning { cursor: grabbing; }
#basemap-attribution {
  position: absolute;
  right: 6px;
  bottom: 4px;
  z-index: 4;
  padding: 1px 6px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.78);
  font-size: 0.64rem;
  color: var(--text-dim);
}
#basemap-attribution[hidden] { display: none; }
#hover-overlay {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}
.settings-columns {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(340px, max-content));
  column-gap: 56px;
  align-items: start;
}
.settings-column > .setting-row:first-child { margin-top: 0; }
.setting-row input[type="color"] {
  flex: none;
  width: 34px;
  height: 26px;
  padding: 0;
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 4px;
  background: none;
  cursor: pointer;
}
.setting-row .hex-input {
  flex: none;
  width: 84px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  font-family: "IBM Plex Mono", monospace;
  font-size: 0.8rem;
  padding: 5px 8px;
}
.setting-row .hex-input.input-error { border-color: #C93135; }
#basemap-attribution a { color: inherit; }

#loading {
  position: absolute;
  inset: 0;
  z-index: 5;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg);
  color: var(--text-dim);
  font-size: 0.9rem;
  transition: opacity 0.2s ease;
}
#loading[hidden] { display: none; }

.legend-bar {
  height: 10px;
  border-radius: 5px;
  background: linear-gradient(to right, var(--rep), var(--rep-mid), #ffffff, var(--dem-mid), var(--dem));
  border: 1px solid rgba(255, 255, 255, 0.15);
}
.legend-cat-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 6px;
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.75);
}
.legend-cat-label {
  width: 58px;
  flex: none;
}
.legend-cat-swatch {
  flex: 1;
  height: 12px;
  border-radius: 3px;
}
.legend-bar-pop {
  height: 10px;
  border-radius: 5px;
  background: linear-gradient(to right, #d53e4f, #fc8d59, #fee08b, #ffffbf, #e6f598, #99d594, #3288bd);
  border: 1px solid rgba(255, 255, 255, 0.15);
}
.layer-btn::after {
  content: "A";
  margin-left: auto;
  color: rgba(255, 255, 255, 0.5);
  font-size: 1rem;
  line-height: 1;
}
.legend-ticks {
  display: flex;
  justify-content: space-between;
  font-size: 0.65rem;
  font-family: "IBM Plex Mono", monospace;
  color: rgba(255, 255, 255, 0.5);
  margin-top: 2px;
}
.legend-scale-label {
  font-size: 0.6rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: rgba(255, 255, 255, 0.4);
  margin: 8px 0 4px;
}
.legend-names {
  display: flex;
  justify-content: space-between;
  font-size: 0.68rem;
  color: rgba(255, 255, 255, 0.5);
  margin-top: 10px;
}
#detail-box .precinct-id {
  font-family: "IBM Plex Mono", monospace;
  font-size: 1.15rem;
  font-weight: 600;
  line-height: 1.2;
  color: #ffffff;
}
#detail-box .county-name {
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 10px;
}
#detail-box .district-line {
  font-size: 0.72rem;
  letter-spacing: 0.04em;
  color: rgba(255, 255, 255, 0.8);
  margin: 2px 0 10px;
}
#detail-box .district-line[hidden] { display: none; }
.stat-row[hidden] { display: none; }
.stat-row {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  padding: 6px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
  font-size: 0.86rem;
  gap: 10px;
}
.stat-row:last-child { border-bottom: none; }
#d-dem-name, #d-rep-name, #di-dem-name, #di-rep-name { flex: 1 1 0; min-width: 0; white-space: nowrap; overflow: hidden; }
.stat-row .n {
  font-family: "IBM Plex Mono", monospace;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.stat-row .pct {
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.78rem;
}
.dem-text { color: var(--dem); font-weight: 600; }
.rep-text { color: var(--rep); font-weight: 600; }
.other-text { color: rgba(255, 255, 255, 0.65); font-weight: 600; }
.placeholder {
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.84rem;
  line-height: 1.5;
}
#district-sidebar, #race-sidebar, #demo-sidebar, #detail-sidebar {
  position: fixed;
  top: 0;
  bottom: 0;
  z-index: 15;
  background: #1e1f24;
  color: #ffffff;
  padding: 16px 12px 64px;
  overflow-x: hidden;
  overflow-y: auto;
  transition: width 0.22s cubic-bezier(.32,.72,0,1), padding 0.22s cubic-bezier(.32,.72,0,1), box-shadow 0.22s ease;
}
#district-sidebar {
  left: 0;
  width: var(--district-sidebar-w);
  box-shadow: 2px 0 10px rgba(20, 24, 31, 0.12);
}
#race-sidebar, #demo-sidebar {
  left: calc(var(--district-sidebar-w) + var(--panel-gap));
  width: max-content;
  min-width: 240px;
  box-shadow: 2px 0 10px rgba(20, 24, 31, 0.12);
}
#detail-sidebar {
  right: 0;
  width: var(--right-sidebar-w);
  box-shadow: -2px 0 10px rgba(20, 24, 31, 0.12);
}
#race-sidebar.collapsed, #demo-sidebar.collapsed { width: 0; min-width: 0; }
#district-sidebar.collapsed, #race-sidebar.collapsed, #demo-sidebar.collapsed, #detail-sidebar.collapsed {
  padding-left: 0;
  padding-right: 0;
  box-shadow: none;
}
.sidebar-toggle {
  position: fixed;
  top: 16px;
  width: 20px;
  height: 28px;
  border: none;
  border-radius: 6px;
  background: #000000;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  font-size: 0.78rem;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 6px rgba(20, 24, 31, 0.35);
  z-index: 16;
  transition: left 0.22s cubic-bezier(.32,.72,0,1), right 0.22s cubic-bezier(.32,.72,0,1), background 0.15s ease, color 0.15s ease;
}
.sidebar-toggle:hover { background: #1a1b1f; color: #ffffff; }
#toggle-district-sidebar { left: calc(var(--district-sidebar-w) + var(--panel-gap) / 2 - 10px); }
#toggle-detail-sidebar { right: calc(var(--right-sidebar-w) + 4px); }
.sidebar-content { transition: opacity 0.15s ease; }
#detail-sidebar .sidebar-content { display: flex; flex-direction: column; height: 100%; }
#legend-box { margin-top: auto; }
#district-sidebar.collapsed .sidebar-content, #race-sidebar.collapsed .sidebar-content, #demo-sidebar.collapsed .sidebar-content, #detail-sidebar.collapsed .sidebar-content {
  opacity: 0;
  pointer-events: none;
}
#district-sidebar .eyebrow, #race-sidebar .eyebrow, #demo-sidebar .eyebrow, #detail-sidebar .eyebrow {
  font-size: 0.68rem;
  text-transform: uppercase;
  letter-spacing: 0.07em;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 10px;
}
.section-gap { margin-top: 24px; }
.district-controls { margin-bottom: 14px; }
.district-controls label {
  display: block;
  font-size: 0.78rem;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 6px;
}
.district-count-row { display: flex; align-items: center; gap: 6px; }
.district-ideal {
  margin-top: 6px;
  font-family: "IBM Plex Mono", monospace;
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.55);
}
.district-count-row button {
  width: 28px;
  height: 28px;
  flex: none;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.06);
  color: #ffffff;
  border-radius: 6px;
  font-size: 1rem;
  cursor: pointer;
}
.district-count-row button:hover { background: rgba(255, 255, 255, 0.14); }
.district-count-row input {
  flex: 1;
  min-width: 0;
  text-align: center;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  font-family: "IBM Plex Mono", monospace;
  font-size: 0.9rem;
  padding: 5px 0;
}
.district-mode-toggle {
  display: flex;
  gap: 4px;
  margin-bottom: 14px;
  background: rgba(255, 255, 255, 0.06);
  border-radius: 6px;
  padding: 3px;
}
.district-mode-btn {
  flex: 1;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.03em;
  text-transform: uppercase;
  padding: 7px 4px;
  border-radius: 4px;
  cursor: pointer;
}
.district-mode-btn.active { background: rgba(255, 255, 255, 0.18); color: #ffffff; }
#shift-box { margin: 0 0 8px; }
#shift-box.active { background: #c9b6f2; border-color: #c9b6f2; color: #1a1305; }
#shift-panel { margin-bottom: 12px; }
#shift-panel label {
  display: block;
  margin: 8px 0 4px;
  font-size: 0.68rem;
  font-weight: 600;
  letter-spacing: 0.03em;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.6);
}
#shift-panel select {
  width: 100%;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  color-scheme: dark;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.82rem;
  padding: 6px 8px;
}
#shift-panel select option { background: #1e1f24; color: #ffffff; }
#district-list { max-height: 33vh; overflow-y: auto; }
.district-divider {
  border: none;
  border-top: 1px solid rgba(255, 255, 255, 0.12);
  margin: 16px 0;
}
.district-tool-toggle {
  display: flex;
  gap: 4px;
  background: rgba(255, 255, 255, 0.06);
  border-radius: 6px;
  padding: 3px;
}
.district-tool-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  padding: 8px 4px;
  border-radius: 4px;
  cursor: pointer;
}
.district-tool-btn:hover { color: #ffffff; }
.district-tool-btn.active { background: rgba(255, 255, 255, 0.18); color: #ffffff; }
.edu-more-btn {
  display: block;
  background: none;
  border: none;
  padding: 8px 2px 4px;
  font: inherit;
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.6);
  cursor: pointer;
}
.edu-more-btn:hover { color: #ffffff; }
.paint-by-row { margin-top: 10px; }
.brush-size-row { margin-top: 10px; }
.brush-size-row[hidden] { display: none; }
.brush-size-row input[type=range] { width: 100%; margin: 4px 0 0; }
#overlay-name { word-break: break-word; }
#overlay-name:empty { display: none; }
.paint-by-label {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 4px;
}
.paint-by-row .district-tool-btn { font-size: 12px; padding: 7px 4px; }
.district-checkbox-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.75);
  cursor: pointer;
}
.district-checkbox-row input[type="checkbox"] {
  width: 15px;
  height: 15px;
  accent-color: var(--accent);
  cursor: pointer;
}
.district-name-input {
  flex: 1;
  min-width: 0;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 4px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.8rem;
  padding: 2px 6px;
}
.district-name-row {
  display: flex;
  align-items: center;
  gap: 6px;
}
.district-name-row .precinct-id, .district-name-row .district-name-input { flex: 1; }
.district-rename-btn {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.4);
  cursor: pointer;
  padding: 2px;
  border-radius: 4px;
}
.district-rename-btn:hover { color: #ffffff; background: rgba(255, 255, 255, 0.1); }
.district-box {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  text-align: left;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 8px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-weight: 600;
  font-size: 0.8rem;
  padding: 8px 10px;
  margin-top: 6px;
  cursor: pointer;
  white-space: nowrap;
}
.district-name {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.district-box:hover { background: rgba(255, 255, 255, 0.1); }
.district-box.active { background: rgba(255, 255, 255, 0.18); border-color: rgba(255, 255, 255, 0.4); }
.district-swatch {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  flex: none;
}
.district-count-badge {
  flex: none;
  margin-left: auto;
  font-family: "IBM Plex Mono", monospace;
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.55);
}
.district-pct-badge {
  flex: none;
  min-width: 46px;
  margin-left: 4px;
  text-align: right;
  font-family: "IBM Plex Mono", monospace;
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.55);
}
.district-lock-btn {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 6px;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.35);
  cursor: pointer;
  padding: 2px;
  border-radius: 4px;
}
.district-lock-btn:hover { color: rgba(255, 255, 255, 0.7); background: rgba(255, 255, 255, 0.08); }
.district-lock-btn.locked { color: var(--accent); }
.race-year-label {
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: rgba(255, 255, 255, 0.45);
  margin: 16px 0 6px;
}
.race-year-label:first-child { margin-top: 0; }
.race-box {
  display: flex;
  align-items: baseline;
  gap: 0.3em;
  white-space: nowrap;
  width: 100%;
  text-align: left;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 8px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-weight: 600;
  font-size: calc(0.82rem - 1px);
  padding: 10px 12px;
  margin-top: 6px;
  cursor: pointer;
}
.race-box:hover { background: rgba(255, 255, 255, 0.1); }
.race-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 5px; margin-top: 6px; }
.race-grid[hidden] { display: none; }
.race-chip { margin-top: 0; padding: 6px 0; justify-content: center; text-align: center; }
.race-chip .race-margin { display: none; }
.race-box.party-dem { border-color: var(--dem); }
.race-box.party-rep { border-color: var(--rep); }
.race-box .race-label { flex: none; }
.race-box .race-margin { flex: none; font-weight: 700; }
.race-box .race-margin::before { content: "- "; }
.race-box.party-dem .race-margin { color: var(--dem); }
.race-box.party-rep .race-margin { color: var(--rep); }
.race-box.active .race-margin { color: inherit; }
.race-box.active.party-none {
  background: var(--accent);
  border-color: var(--accent);
  color: #1a1305;
}
.race-box.active.party-dem {
  background: var(--dem);
  border-color: var(--dem);
  color: #ffffff;
}
.race-box.active.party-rep {
  background: var(--rep);
  border-color: var(--rep);
  color: #ffffff;
}
#demo-list .race-box.active {
  border-color: #2ecc71;
  box-shadow: 0 0 0 1px #2ecc71;
}

#dock {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 22;
  display: flex;
  flex-direction: column;
}

#settings-panel {
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  background: #000000;
  color: #ffffff;
  border-top: 1px solid rgba(255, 255, 255, 0.12);
  box-shadow: 0 -6px 20px rgba(20, 24, 31, 0.12);
  transition: max-height 0.22s cubic-bezier(.32,.72,0,1), opacity 0.16s ease;
}
#settings-panel.open { max-height: 65vh; opacity: 1; }
#settings-panel .inner {
  padding: 18px 24px;
  max-height: 65vh;
  overflow-y: auto;
}
#settings-panel h3 {
  margin: 0 0 4px;
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: rgba(255, 255, 255, 0.55);
}
.sources-lede {
  font-size: 0.88rem;
  line-height: 1.55;
  max-width: 62ch;
  margin: 10px 0 0;
}
.sources-lede a { color: var(--accent); }
.sources-caveats {
  margin: 14px 0 0;
  padding-left: 0;
  font-size: 0.84rem;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.55);
  column-count: 3;
  column-width: 260px;
  column-gap: 36px;
}
.sources-caveats li {
  margin: 0 0 8px 18px;
  break-inside: avoid;
}
.sources-coverage {
  margin: 14px 0 0;
  font-size: 0.84rem;
  color: rgba(255, 255, 255, 0.55);
}
.sources-columns {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
  gap: 0 24px;
  margin-top: 8px;
  max-width: 780px;
}
.sources-county-row {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  padding: 4px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
  font-size: 0.82rem;
}
.sources-county-row .n {
  font-family: "IBM Plex Mono", monospace;
  font-variant-numeric: tabular-nums;
  color: rgba(255, 255, 255, 0.55);
}
.setting-row {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-top: 14px;
  max-width: 420px;
}
.setting-row label {
  font-size: 0.88rem;
  flex: none;
  width: 180px;
}
.setting-row input[type="range"] {
  flex: 1;
  accent-color: var(--accent);
}
.setting-row input[type="checkbox"] {
  flex: none;
  width: 15px;
  height: 15px;
  margin: 0;
  accent-color: var(--accent);
  cursor: pointer;
}
.setting-row select {
  flex: 1;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  color-scheme: dark;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.82rem;
  padding: 6px 8px;
}
.setting-row select option { background: #1e1f24; color: #ffffff; }
.setting-hint {
  max-width: 420px;
  margin-top: 6px;
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.5);
}
.setting-row .value {
  font-family: "IBM Plex Mono", monospace;
  font-size: 0.8rem;
  width: 46px;
  text-align: right;
  color: rgba(255, 255, 255, 0.55);
}

#bottom-bar {
  background: #000000;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 9px 18px;
  padding-bottom: calc(9px + env(safe-area-inset-bottom, 0px));
}
#bottom-bar .bar-menu {
  display: flex;
  align-items: center;
  gap: 4px;
}
.nav-item-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-weight: 600;
  font-size: 0.72rem;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  padding: 9px 14px;
  border-radius: 6px;
}
.nav-item-btn:hover { background: rgba(255, 255, 255, 0.08); }
.nav-item-btn.active { background: rgba(255, 255, 255, 0.16); }
#bottom-bar input[type="text"] {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.78rem;
  padding: 7px 10px;
  width: 160px;
  transition: border-color 0.15s ease;
}
#bottom-bar input[type="text"]::placeholder { color: rgba(255, 255, 255, 0.4); }
#bottom-bar input[type="text"].input-error { border-color: #C93135; }

#unsaved-modal {
  position: fixed;
  inset: 0;
  z-index: 40;
  background: rgba(15, 18, 24, 0.55);
  display: flex;
  align-items: center;
  justify-content: center;
}
#unsaved-modal[hidden] { display: none; }
#unsaved-modal-box {
  width: 340px;
  max-width: 90vw;
  background: #1e1f24;
  color: #ffffff;
  border-radius: 12px;
  padding: 22px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
}
#unsaved-modal-box h3 { margin: 0 0 10px; font-size: 1.02rem; }
#unsaved-modal-box p {
  margin: 0 0 18px;
  font-size: 0.86rem;
  color: rgba(255, 255, 255, 0.7);
  line-height: 1.5;
}
.unsaved-modal-actions { display: flex; flex-direction: column; gap: 8px; }
.unsaved-modal-actions button {
  width: 100%;
  border-radius: 8px;
  padding: 10px 12px;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.82rem;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.06);
  color: #ffffff;
}
.unsaved-modal-actions button:hover { background: rgba(255, 255, 255, 0.14); }
#unsaved-save-btn { background: var(--accent); border-color: var(--accent); color: #1a1305; margin-top: 0; }
#unsaved-save-btn:hover { filter: brightness(1.08); background: var(--accent); }

#backdrop {
  position: fixed;
  inset: 0;
  background: rgba(15, 18, 24, 0.14);
  z-index: 19;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.18s ease;
}
#backdrop.open { opacity: 1; pointer-events: auto; }

#home-screen {
  position: fixed;
  inset: 0;
  z-index: 30;
  display: flex;
  background: var(--bg);
}
#home-screen[hidden] { display: none; }
.home-hero {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 60px;
  overflow-y: auto;
}
.home-hero h1 {
  font-size: 2.4rem;
  margin: 0 0 8px;
  color: var(--text);
}
.home-hero .home-tagline {
  font-size: 1rem;
  color: var(--text-dim);
  margin: 0 0 32px;
  line-height: 1.55;
}
.home-maps-table-wrap { flex: 1; width: 100%; }
.home-maps-table { width: 100%; border-collapse: collapse; font-size: 0.88rem; }
.home-maps-table th {
  text-align: left;
  font-size: 0.68rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-dim);
  padding: 0 10px 8px;
  border-bottom: 1px solid var(--border);
}
.home-maps-table td {
  padding: 10px;
  border-bottom: 1px solid var(--border);
  color: var(--text);
}
.home-maps-table tbody tr { cursor: pointer; }
.home-maps-table tbody tr:hover { background: rgba(185, 134, 46, 0.08); }
.home-maps-table .home-map-name { font-weight: 600; }
.home-maps-table .home-map-delete {
  background: transparent;
  border: none;
  color: var(--text-dim);
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  cursor: pointer;
  padding: 4px 6px;
}
.home-maps-table .home-map-delete:hover { color: #a0262a; }
.home-maps-table .home-map-share {
  background: transparent;
  border: none;
  color: var(--text-dim);
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  cursor: pointer;
  padding: 4px 6px;
}
.home-maps-table .home-map-share:hover { color: var(--accent); }
#home-panel {
  width: 320px;
  flex: none;
  background: #1e1f24;
  color: #ffffff;
  padding: 24px 20px;
  overflow-y: auto;
  box-shadow: -2px 0 10px rgba(20, 24, 31, 0.12);
}
#home-panel .eyebrow {
  font-size: 0.68rem;
  text-transform: uppercase;
  letter-spacing: 0.07em;
  color: rgba(255, 255, 255, 0.5);
  margin-bottom: 10px;
}
.district-controls select option {
  background: #1e1f24;
  color: #ffffff;
}
.district-controls select {
  color-scheme: dark;
  width: 100%;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.82rem;
  padding: 6px 8px;
}
.home-primary-btn {
  display: block;
  width: 100%;
  background: var(--accent);
  border: none;
  color: #1a1305;
  font-family: "IBM Plex Sans", sans-serif;
  font-weight: 700;
  font-size: 0.86rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 11px 12px;
  border-radius: 8px;
  cursor: pointer;
  margin-top: 4px;
}
.home-primary-btn:hover { filter: brightness(1.08); }
#home-create-btn { background: #7c5cbf; color: #ffffff; }
#home-import-btn { background: rgba(255, 255, 255, 0.1); color: #ffffff; margin-top: 10px; }
#home-import-btn[hidden] { display: none; }
#account-bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 12px;
  min-height: 30px;
  margin: -36px 0 18px;
  font-size: 0.8rem;
  color: var(--text-dim);
}
#account-bar[hidden] { display: none; }
#account-bar .account-email { color: var(--text); font-weight: 600; }
#account-bar button, .account-links button {
  background: transparent;
  border: none;
  color: var(--text-dim);
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.74rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  cursor: pointer;
  padding: 4px 6px;
}
#account-bar button:hover, .account-links button:hover { color: var(--text); }
#account-bar .account-login-btn {
  border: 1px solid var(--border);
  border-radius: 6px;
  color: var(--text);
  padding: 6px 12px;
}
#account-modal {
  position: fixed;
  inset: 0;
  z-index: 60;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(10, 12, 16, 0.6);
}
#account-modal[hidden] { display: none; }
.account-card {
  position: relative;
  width: min(380px, calc(100vw - 32px));
  background: #1e1f24;
  color: #ffffff;
  border-radius: 12px;
  padding: 26px 24px 20px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
  font-family: "IBM Plex Sans", sans-serif;
}
.account-card h2 { margin: 0 0 16px; font-size: 1.1rem; }
#account-close {
  position: absolute;
  top: 8px;
  right: 12px;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-size: 1.5rem;
  cursor: pointer;
}
.account-card input[type="email"], .account-card input[type="password"] {
  width: 100%;
  box-sizing: border-box;
  margin-bottom: 10px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.9rem;
  padding: 9px 10px;
}
.account-card input[hidden] { display: none; }
.account-hp { position: absolute; left: -9999px; width: 1px; height: 1px; opacity: 0; }
#account-msg { min-height: 1.2em; margin-bottom: 10px; font-size: 0.8rem; color: rgba(255, 255, 255, 0.75); line-height: 1.4; }
#account-msg.error { color: #ff8a8a; }
.account-links { display: flex; flex-wrap: wrap; gap: 4px 10px; margin-top: 12px; }
.account-links button { color: rgba(255, 255, 255, 0.6); }
.account-links button:hover { color: #ffffff; }
.account-links button[hidden] { display: none; }
#readonly-banner {
  position: fixed;
  top: 10px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 40;
  display: flex;
  align-items: center;
  gap: 12px;
  max-width: min(640px, calc(100vw - 32px));
  background: #1e1f24;
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 10px;
  padding: 8px 12px;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.78rem;
  line-height: 1.35;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
}
#readonly-banner[hidden] { display: none; }
#readonly-banner.flash { border-color: var(--accent); }
#readonly-banner button {
  flex: none;
  background: var(--accent);
  border: none;
  color: #1a1305;
  font-family: "IBM Plex Sans", sans-serif;
  font-weight: 700;
  font-size: 0.74rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 7px 10px;
  border-radius: 6px;
  cursor: pointer;
}
.account-note { margin: 14px 0 0; font-size: 0.7rem; line-height: 1.45; color: rgba(255, 255, 255, 0.45); }

#stats-page {
  position: fixed;
  inset: 0;
  z-index: 26;
  display: flex;
  flex-direction: column;
  background: #1e1f24;
  color: #ffffff;
}
#stats-page[hidden] { display: none; }
.stats-header {
  display: flex;
  align-items: center;
  gap: 18px;
  padding: 14px 24px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}
.stats-header h2 { margin: 0; font-size: 1.1rem; }
.stats-back-btn {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 8px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.82rem;
  font-weight: 600;
  padding: 8px 14px;
  cursor: pointer;
}
.stats-back-btn:hover { background: rgba(255, 255, 255, 0.16); }
.stats-body { flex: 1; overflow-y: auto; padding: 24px; }
.stats-card {
  max-width: none;
  margin: 0 0 24px;
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  padding: 20px 22px;
}
.stats-card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 18px;
}
.stats-card h3 { margin: 0; font-size: 0.95rem; }
.stats-controls { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.stats-controls label { font-size: 0.78rem; color: rgba(255, 255, 255, 0.7); }
.stats-controls select {
  color-scheme: dark;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 6px;
  color: #ffffff;
  font-family: "IBM Plex Sans", sans-serif;
  font-size: 0.82rem;
  padding: 6px 8px;
}
.stats-controls select option { background: #1e1f24; color: #ffffff; }
#lean-wrap { position: relative; margin-top: 30px; }
#lean-flip {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 0;
  margin-left: -1.5px;
  border-left: 3px solid #000000;
  z-index: 2;
  pointer-events: none;
}
#lean-flip[hidden] { display: none; }
#lean-flip-label {
  position: absolute;
  top: -22px;
  left: 1.5px;
  transform: translateX(-50%);
  white-space: nowrap;
  font-size: 0.72rem;
  font-weight: 600;
  color: #ffffff;
}
#lean-chart {
  display: flex;
  width: 100%;
  height: 150px;
  border-radius: 6px;
  overflow: hidden;
}
.lean-sliver { flex: 1 1 0; min-width: 0; height: 100%; cursor: default; }
.lean-sliver:hover { outline: 2px solid #ffffff; outline-offset: -2px; }
.lean-axis {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  font-size: 0.72rem;
  font-weight: 600;
}
.lean-axis[hidden] { display: none; }
.lean-readout { margin-top: 14px; min-height: 1.4em; font-size: 0.86rem; color: rgba(255, 255, 255, 0.85); }
.lean-summary { margin-top: 10px; font-size: 0.8rem; color: rgba(255, 255, 255, 0.55); }
</style>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">

<div id="account-modal" hidden>
  <div class="account-card" role="dialog" aria-modal="true" aria-labelledby="account-title">
    <button id="account-close" type="button" aria-label="Close">&times;</button>
    <h2 id="account-title">Log in</h2>
    <form id="account-form">
      <input type="email" id="account-email" placeholder="E-mail" autocomplete="email" maxlength="254">
      <input type="password" id="account-password" placeholder="Password" autocomplete="current-password" maxlength="200">
      <input type="text" id="account-website" class="account-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <div id="account-msg" role="status"></div>
      <button type="submit" class="home-primary-btn" id="account-submit">Log in</button>
    </form>
    <div class="account-links">
      <button type="button" id="account-switch">Create an account</button>
      <button type="button" id="account-forgot">Forgot password?</button>
      <button type="button" id="account-resend" hidden>Resend confirmation e-mail</button>
    </div>
    <p class="account-note">Every map you save gets a link that anyone can open to view, but only you can edit it. Your password is never stored in readable form.</p>
  </div>
</div>

<div id="home-screen">
  <div class="home-hero">
    <div id="account-bar" hidden></div>
    <h1>ElectionCord's Civitas</h1>
    <p class="home-tagline">The Ultimate Redistricting and Election Analyzing Tool</p>
    <div class="home-maps-table-wrap">
      <table class="home-maps-table">
        <thead>
          <tr><th>Name</th><th>State</th><th>Districts</th><th></th></tr>
        </thead>
        <tbody id="home-maps-tbody"></tbody>
      </table>
    </div>
  </div>
  <div id="home-panel">
    <div class="eyebrow">New Map</div>
    <div class="district-controls">
      <label for="home-state-select">State</label>
      <select id="home-state-select"></select>
    </div>
    <div class="district-controls">
      <label for="home-geo-select">Geography</label>
      <select id="home-geo-select"></select>
    </div>
    <div class="district-controls">
      <label for="home-district-count">Number of districts</label>
      <div class="district-count-row">
        <button id="home-count-minus" type="button">&minus;</button>
        <input type="number" id="home-district-count" min="0" max="1000" value="52">
        <button id="home-count-plus" type="button">+</button>
      </div>
      <div class="district-ideal" id="home-ideal" hidden></div>
    </div>
    <button class="home-primary-btn" id="home-create-btn" type="button">Create Map</button>
    <button class="home-primary-btn" id="home-import-btn" type="button" hidden>Open map file&hellip;</button>
    <input type="file" id="home-import-file" accept=".geojson,.civitasmap,.json" hidden>
  </div>
</div>

<div id="app-view" hidden>
<div id="readonly-banner" hidden>
  <span id="readonly-text"></span>
  <button type="button" id="readonly-copy">Save a copy</button>
</div>
<button class="sidebar-toggle" id="toggle-district-sidebar" type="button" aria-label="Toggle districts panel"></button>
<div id="district-sidebar">
  <div class="sidebar-content">
    <div class="eyebrow">Districts</div>
    <div class="district-controls">
      <label for="district-count-input">Number of districts</label>
      <div class="district-count-row">
        <button id="district-count-minus" type="button">&minus;</button>
        <input type="number" id="district-count-input" min="0" max="1000" value="0">
        <button id="district-count-plus" type="button">+</button>
      </div>
      <div class="district-ideal" id="district-ideal" hidden></div>
    </div>
    <div class="district-mode-toggle">
      <button class="district-mode-btn active" id="district-mode-by-district" type="button">By District</button>
      <button class="district-mode-btn" id="district-mode-by-lean" type="button">By Map Layer</button>
    </div>
    <div id="district-list"></div>
    <hr class="district-divider">
    <div class="eyebrow">Map Layers</div>
    <button class="district-box layer-btn" id="layer-elections" type="button">Elections</button>
    <button class="district-box layer-btn" id="layer-demographics" type="button">Demographics</button>
    <hr class="district-divider">
    <div class="eyebrow">Tools</div>
    <div class="district-tool-toggle">
      <button class="district-tool-btn active" id="tool-cursor" type="button" title="Cursor: pan and inspect" aria-label="Cursor">
        <svg viewBox="0 0 20 20" width="16" height="16"><polygon points="4,3 4,16 7.5,12.8 10,18 12,17 9.7,12 15,12" fill="currentColor"/></svg>
      </button>
      <button class="district-tool-btn" id="tool-paint" type="button" title="Paint: assign precincts to the selected district" data-geo-title="Paint: assign {units} to the selected district" aria-label="Paint">
        <svg viewBox="0 0 20 20" width="16" height="16" fill="currentColor"><path d="M10 3 C10 3 5 9 5 12 a5 5 0 0 0 10 0 C15 9 10 3 10 3 Z"/></svg>
      </button>
      <button class="district-tool-btn" id="tool-eraser" type="button" title="Eraser: unassign precincts" data-geo-title="Eraser: unassign {units}" aria-label="Eraser">
        <svg viewBox="0 0 20 20" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="14" height="8" rx="1.5" transform="rotate(-20 10 10)"></rect><line x1="3" y1="10" x2="17" y2="10" transform="rotate(-20 10 10)"></line></svg>
      </button>
    </div>
    <div class="brush-size-row" id="brush-size-row" hidden>
      <div class="paint-by-label">Brush Size: <span id="brush-size-value">Single</span></div>
      <input type="range" id="brush-size" min="0" max="150" value="0">
    </div>
    <div class="paint-by-row">
      <div class="paint-by-label">Color By</div>
      <div class="district-tool-toggle">
        <button class="district-tool-btn active" id="paintby-unit" type="button" data-geo-text="{Unit}">Precinct</button>
        <button class="district-tool-btn" id="paintby-county" type="button">County</button>
      </div>
    </div>
    <label class="district-checkbox-row">
      <input type="checkbox" id="drag-paint" checked>
      <span data-geo-text="Drag to paint/erase {units}">Drag to paint/erase precincts</span>
    </label>
    <label class="district-checkbox-row">
      <input type="checkbox" id="show-county-borders">
      <span>Show county borders</span>
    </label>
    <label class="district-checkbox-row">
      <input type="checkbox" id="highlight-district">
      <span>Highlight selected district</span>
    </label>
    <label class="district-checkbox-row">
      <input type="checkbox" id="show-units-in-district">
      <span data-geo-text="Show {units} on selected district">Show precincts on selected district</span>
    </label>
  </div>
</div>

<div id="race-sidebar" class="collapsed">
  <div class="sidebar-content">
    <div class="eyebrow">Elections</div>
    <div class="district-mode-toggle">
      <button class="district-mode-btn active" id="election-view-margin" type="button">Margin</button>
      <button class="district-mode-btn" id="election-view-turnout" type="button">Turnout</button>
    </div>
    <button class="race-box party-none" id="shift-box" type="button"><span class="race-label">Shift</span></button>
    <div id="shift-panel" hidden>
      <label for="shift-from">From</label>
      <select id="shift-from"></select>
      <label for="shift-to">To</label>
      <select id="shift-to"></select>
    </div>
    <div id="race-list"></div>
  </div>
</div>
<div id="demo-sidebar" class="collapsed">
  <div class="sidebar-content">
    <div class="eyebrow">Demographics</div>
    <div id="demo-list">
      <div class="race-year-label">Population</div>
    </div>

  </div>
</div>

<div id="stage">
  <canvas id="map"></canvas>
  <canvas id="hover-overlay"></canvas>
  <div id="loading">Loading precincts&hellip;</div>
  <div id="basemap-attribution"><a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> <a href="https://www.openmaptiles.org/" target="_blank" rel="noopener">&copy; OpenMapTiles</a> Data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a></div>
</div>

<button class="sidebar-toggle" id="toggle-detail-sidebar" type="button" aria-label="Toggle detail panel"></button>
<div id="detail-sidebar">
  <div class="sidebar-content">
    <div class="eyebrow">District</div>
    <div id="district-info-box">
      <div class="placeholder" id="district-placeholder">Select a district to see its totals.</div>
      <div id="district-detail" hidden>
        <div class="district-name-row">
          <span class="precinct-id" id="di-name"></span>
          <input type="text" class="district-name-input" id="di-name-input" maxlength="40" hidden>
          <button class="district-rename-btn" id="di-rename-btn" type="button" title="Rename district" aria-label="Rename district">
            <svg viewBox="0 0 20 20" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12.5 3.5 L16.5 7.5 L7 17 L3 17.5 L3.5 13.5 Z"></path></svg>
          </button>
        </div>
        <div class="stat-row"><span class="dem-text" id="di-dem-name"></span><span class="n"><span id="di-dem"></span> <span class="pct" id="di-dem-pct"></span></span></div>
        <div class="stat-row"><span class="rep-text" id="di-rep-name"></span><span class="n"><span id="di-rep"></span> <span class="pct" id="di-rep-pct"></span></span></div>
        <div class="stat-row" id="di-other-row"><span class="other-text">Other</span><span class="n"><span id="di-other"></span> <span class="pct" id="di-other-pct"></span></span></div>
        <div class="stat-row" id="di-margin-row"><span>Margin</span><span class="n" id="di-margin"></span></div>
        <div class="stat-row" id="di-turnout-row" hidden><span>Turnout (VAP)</span><span class="n"><span id="di-turnout"></span></span></div>
        <div class="stat-row" id="di-shift-row" hidden><span id="di-shift-label"></span><span class="n" id="di-shift"></span></div>
        <div class="stat-row" id="di-shiftft-row" hidden><span>From &rarr; to</span><span class="n" id="di-shiftft"></span></div>
        <div class="stat-row"><span id="di-pop-label"></span><span class="n" id="di-pop"></span></div>
      </div>
    </div>
    <label class="district-checkbox-row">
      <input type="checkbox" id="hover-district">
      <span>Show hovered district</span>
    </label>
    <hr class="district-divider">
    <div class="eyebrow" id="detail-heading" data-geo-text="{Unit}">Precinct</div>
    <div id="detail-box">
      <div class="placeholder" id="placeholder" data-geo-text="Hover or tap a {unit}.">Hover or tap a precinct.</div>
      <div id="detail" hidden>
        <div class="precinct-id" id="d-precinct"></div>
        <div class="county-name" id="d-county"></div>
        <div class="district-line" id="d-district" hidden></div>
        <div class="stat-row"><span class="dem-text" id="d-dem-name"></span><span class="n"><span id="d-dem"></span> <span class="pct" id="d-dem-pct"></span></span></div>
        <div class="stat-row"><span class="rep-text" id="d-rep-name"></span><span class="n"><span id="d-rep"></span> <span class="pct" id="d-rep-pct"></span></span></div>
        <div class="stat-row" id="d-other-row"><span class="other-text">Other</span><span class="n"><span id="d-other"></span> <span class="pct" id="d-other-pct"></span></span></div>
        <div class="stat-row" id="d-margin-row"><span>Margin</span><span class="n" id="d-margin"></span></div>
        <div class="stat-row" id="d-turnout-row" hidden><span>Turnout (VAP)</span><span class="n"><span id="d-turnout"></span></span></div>
        <div class="stat-row" id="d-shift-row" hidden><span id="d-shift-label"></span><span class="n" id="d-shift"></span></div>
        <div class="stat-row" id="d-shiftft-row" hidden><span>From &rarr; to</span><span class="n" id="d-shiftft"></span></div>
        <div class="stat-row"><span id="d-pop-label"></span><span class="n" id="d-pop"></span></div>
        <div class="stat-row" id="d-layer-row" hidden><span id="d-layer-label"></span><span class="n" id="d-layer"></span></div>
      </div>
    </div>
    <div id="legend-box">
      <div id="legend-pop" hidden>
        <div class="eyebrow" id="legend-pop-title">Population</div>
        <div id="legend-pop-bars">
        <div class="legend-scale-label" id="legend-pop-scale-label" data-geo-text="{Unit} population">Precinct population</div>
        <div class="legend-bar-pop"></div>
        <div class="legend-ticks"><span id="legend-pop-lo"></span><span id="legend-pop-mid"></span><span id="legend-pop-hi"></span></div>
        <div id="legend-dpop-block">
        <div class="legend-scale-label" id="legend-dpop-scale-label">District population</div>
        <div class="legend-bar-pop"></div>
        <div class="legend-ticks"><span id="legend-dpop-lo"></span><span id="legend-dpop-mid"></span><span id="legend-dpop-hi"></span></div>
        </div>
        </div>
        <div id="legend-cat" hidden></div>
      </div>
      <div id="legend-election">
      <div class="eyebrow" id="legend-title">President 2024 &middot; margin</div>
      <div id="legend-shift" hidden></div>
      <div id="legend-turnout" hidden>
        <div class="legend-scale-label">Turnout (votes &divide; voting age population)</div>
        <div class="legend-bar-pop"></div>
        <div class="legend-ticks"><span id="legend-turnout-lo"></span><span id="legend-turnout-mid"></span><span id="legend-turnout-hi"></span></div>
      </div>
      <div id="legend-margin">
      <div class="legend-scale-label" data-geo-text="{Unit} margin">Precinct margin</div>
      <div class="legend-bar"></div>
      <div class="legend-ticks"><span>-100</span><span>-50</span><span>Even</span><span>+50</span><span>+100</span></div>
      <div class="legend-scale-label">District margin</div>
      <div class="legend-bar"></div>
      <div class="legend-ticks"><span>-30</span><span>-15</span><span>Even</span><span>+15</span><span>+30</span></div>
      <div class="legend-names"><span id="legend-rep-short">Trump</span><span id="legend-dem-short">Harris</span></div>
      </div>
      </div>
    </div>
  </div>
</div>

<div id="backdrop"></div>
<div id="dock">
  <div id="settings-panel" role="region" aria-label="Map settings and sources">
    <div class="inner">
      <div id="panel-map-settings">
        <div class="settings-columns">
        <div class="settings-column">
        <div class="setting-row">
          <label for="border-slider" data-geo-text="{Unit} Border Width">Precinct Border Width</label>
          <input type="range" id="border-slider" min="0" max="2.4" step="0.05" value="0.15">
          <span class="value" id="border-value">0.15px</span>
        </div>
        <div class="setting-row">
          <label for="district-border-slider">District Border Width</label>
          <input type="range" id="district-border-slider" min="0" max="2.4" step="0.05" value="1">
          <span class="value" id="district-border-value">1px</span>
        </div>
        <div class="setting-row">
          <label for="county-border-slider">County Border Width</label>
          <input type="range" id="county-border-slider" min="0" max="2.4" step="0.05" value="0.5">
          <span class="value" id="county-border-value">0.50px</span>
        </div>
        <div class="setting-row">
          <label for="shape-opacity">Shape Opacity</label>
          <input type="range" id="shape-opacity" min="0.15" max="1" step="0.05" value="0.8">
          <span class="value" id="shape-opacity-value">80%</span>
        </div>
        </div>
        <div class="settings-column">
        <div class="setting-row">
          <label for="border-color-hex" data-geo-text="{Unit} Border Color">Precinct Border Color</label>
          <input type="color" id="border-color" value="#000000">
          <input type="text" id="border-color-hex" class="hex-input" value="#000000" maxlength="7" spellcheck="false">
        </div>
        <div class="setting-row">
          <label for="district-border-color-hex">District Border Color</label>
          <input type="color" id="district-border-color" value="#000000">
          <input type="text" id="district-border-color-hex" class="hex-input" value="#000000" maxlength="7" spellcheck="false">
        </div>
        <div class="setting-row">
          <label for="county-border-color-hex">County Border Color</label>
          <input type="color" id="county-border-color" value="#000000">
          <input type="text" id="county-border-color-hex" class="hex-input" value="#000000" maxlength="7" spellcheck="false">
        </div>
        <div class="setting-row">
          <label for="demo-scheme">Map Color (Demographics &amp; Turnout)</label>
          <select id="demo-scheme"></select>
        </div>
        </div>
        <div class="settings-column">
        <div class="setting-row">
          <label for="show-basemap" style="width:auto;flex:1;cursor:pointer;">Show Background Map</label>
          <input type="checkbox" id="show-basemap" checked>
        </div>
        <div class="setting-hint" id="basemap-hint"></div>
        <div class="setting-row">
          <label for="show-place-names" style="width:auto;flex:1;cursor:pointer;">Show Place Names</label>
          <input type="checkbox" id="show-place-names" checked>
        </div>
        <div class="setting-row">
          <label for="place-names-front" style="width:auto;flex:1;cursor:pointer;">Place Names In Front of Shapes</label>
          <input type="checkbox" id="place-names-front">
        </div>
        <div class="setting-row">
          <label for="show-district-labels" style="width:auto;flex:1;cursor:pointer;">Show District Names on Map</label>
          <input type="checkbox" id="show-district-labels">
        </div>
        </div>
        </div>
      </div>
      <div id="panel-overlays" hidden>
        <div class="settings-columns">
        <div class="settings-column">
        <div class="setting-row">
          <label style="width:auto;flex:1;">Boundary Overlay (GeoJSON)</label>
          <button class="district-tool-btn" id="overlay-upload" type="button" style="width:auto;padding:6px 10px;" title="Show the borders from a GeoJSON file on top of this map. It does not create or change any districts.">Upload</button>
          <button class="district-tool-btn" id="overlay-clear" type="button" style="display:none;width:auto;padding:6px 10px;">Clear</button>
          <input type="file" id="overlay-file" accept=".geojson,.json,application/geo+json,application/json" hidden>
        </div>
        <div class="setting-hint" id="overlay-name"></div>
        <div class="setting-row">
          <label for="overlay-width-slider">Overlay Border Width</label>
          <input type="range" id="overlay-width-slider" min="0.25" max="4" step="0.25" value="1">
          <span class="value" id="overlay-width-value">1.00px</span>
        </div>
        <div class="setting-row">
          <label for="overlay-color-hex">Overlay Border Color</label>
          <input type="color" id="overlay-color" value="#000000">
          <input type="text" id="overlay-color-hex" class="hex-input" value="#000000" maxlength="7" spellcheck="false">
        </div>
        </div>
        </div>
      </div>
      <div id="panel-sources" hidden></div>
    </div>
  </div>
  <div id="bottom-bar">
    <div class="bar-menu">
      <button class="nav-item-btn" id="nav-map-settings" type="button">Map Settings</button>
      <button class="nav-item-btn" id="nav-overlays" type="button">Map Overlays</button>
      <button class="nav-item-btn" id="nav-stats" type="button">Stats</button>
      <button class="nav-item-btn" id="nav-sources" type="button">Sources</button>
    </div>
    <div class="bar-menu">
      <button class="nav-item-btn" id="nav-share-map" type="button" title="Copy a link to this map">Share</button>
      <input type="text" id="map-name-input" placeholder="Map name" maxlength="40">
      <button class="nav-item-btn" id="nav-save-map" type="button">Save</button>
      <button class="nav-item-btn" id="nav-home" type="button">Back to Menu</button>
    </div>
  </div>
</div>

<div id="stats-page" hidden>
  <div class="stats-header">
    <button class="stats-back-btn" id="stats-back" type="button">&larr; Back to Map</button>
    <h2>Stats</h2>
  </div>
  <div class="stats-body">
    <section class="stats-card">
      <div class="stats-card-head">
        <h3>District Lean</h3>
        <div class="stats-controls">
          <label for="stats-race">Election</label>
          <select id="stats-race"></select>
        </div>
      </div>
      <div class="placeholder" id="lean-empty" hidden></div>
      <div id="lean-wrap">
        <div id="lean-flip" hidden><span id="lean-flip-label"></span></div>
        <div id="lean-chart"></div>
      </div>
      <div class="lean-axis" id="lean-axis"><span id="lean-axis-rep"></span><span id="lean-axis-dem"></span></div>
      <div class="lean-readout" id="lean-readout">Hover a sliver to see its district.</div>
      <div class="lean-summary" id="lean-summary"></div>
    </section>
  </div>
</div>

<div id="unsaved-modal" hidden>
  <div id="unsaved-modal-box">
    <h3>Unsaved changes</h3>
    <p>This map has changes that haven&rsquo;t been saved yet. What would you like to do?</p>
    <div class="unsaved-modal-actions">
      <button id="unsaved-save-btn" type="button" class="home-primary-btn">Save &amp; Back to Menu</button>
      <button id="unsaved-discard-btn" type="button">Discard &amp; Back to Menu</button>
      <button id="unsaved-cancel-btn" type="button">Cancel</button>
    </div>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/polygon-clipping@0.15.7/dist/polygon-clipping.umd.js"></script>
<script>
(function() {
  var canvas = document.getElementById('map');
  var ctx = canvas.getContext('2d');
  var loading = document.getElementById('loading');
  var placeholder = document.getElementById('placeholder');
  var detail = document.getElementById('detail');
  var elPrecinct = document.getElementById('d-precinct');
  var elCounty = document.getElementById('d-county');
  function fitName(el) {
    el.style.fontSize = '';
    var size = parseFloat(getComputedStyle(el).fontSize);
    while (el.scrollWidth > el.clientWidth && size > 8) { size -= 0.5; el.style.fontSize = size + 'px'; }
  }
  var elDemName = document.getElementById('d-dem-name');
  var elRepName = document.getElementById('d-rep-name');
  var elDem = document.getElementById('d-dem');
  var elDemPct = document.getElementById('d-dem-pct');
  var elRep = document.getElementById('d-rep');
  var elRepPct = document.getElementById('d-rep-pct');
  var elOtherRow = document.getElementById('d-other-row');
  var elOther = document.getElementById('d-other');
  var elOtherPct = document.getElementById('d-other-pct');
  var elMargin = document.getElementById('d-margin');
  function fillPopRow(prefix, values, isBG) {
    var onLayer = layerMode === 'population';
    var L = popLayerFor(prefix === 'd' ? 'pop' : (onLayer ? popKey : 'pop'));
    document.getElementById(prefix + '-pop-label').textContent = L.rowLabel + (!isBG || L.est ? ' (est.)' : '');
    document.getElementById(prefix + '-pop').textContent = layerText(values, L);
    if (prefix === 'd') {
      var layerRow = document.getElementById('d-layer-row');
      var LL = popLayerFor(popKey);
      layerRow.hidden = !(onLayer && popKey !== 'pop');
      if (!layerRow.hidden) {
        document.getElementById('d-layer-label').textContent = LL.rowLabel + (!isBG || LL.est ? ' (est.)' : '');
        document.getElementById('d-layer').textContent = layerText(values, LL);
      }
    }
  }
  var legendRepShort = document.getElementById('legend-rep-short');
  var legendDemShort = document.getElementById('legend-dem-short');
  var activeRace = null;

  var STATES = {
    CA: { key: 'CA', base: 'CA', label: 'California', geo: 'precinct', dataDir: 'data/CA/', districts: 52, population: __POP_CA__ },
    'CA-BG': { key: 'CA-BG', base: 'CA', label: 'California', geo: 'blockgroup', dataDir: 'data/CA-BG/', districts: 52, population: __POP_CA_BG__ },
  };
  var GEO_LABELS = { precinct: 'Precincts (2024)', blockgroup: 'Block Groups' };
  var GEO_UNITS = { precinct: ['precinct', 'precincts'], blockgroup: ['block group', 'block groups'] };
  var currentState = null;
  var loadedStateKey = null;

  function geoUnit(plural) {
    var g = currentState ? currentState.geo : 'precinct';
    return GEO_UNITS[g][plural ? 1 : 0];
  }
  function capFirst(t) { return t.replace(/(^|\s)\S/g, function(c) { return c.toUpperCase(); }); }
  function fillGeoTemplate(t) {
    return t.replace(/\{Units\}/g, capFirst(geoUnit(true))).replace(/\{Unit\}/g, capFirst(geoUnit(false)))
      .replace(/\{units\}/g, geoUnit(true)).replace(/\{unit\}/g, geoUnit(false));
  }
  function applyGeoLabels() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-geo-text]'), function(el) {
      el.textContent = fillGeoTemplate(el.getAttribute('data-geo-text'));
    });
    Array.prototype.forEach.call(document.querySelectorAll('[data-geo-title]'), function(el) {
      el.title = fillGeoTemplate(el.getAttribute('data-geo-title'));
    });
  }
  var racesBootstrapped = false;
  var allRaces = [];
  var selectedRaceKey = null;
  // currentMapId is this browser's own draft id (#draft=N). currentSid is the site-wide id handed out by the
  // server once a map is saved to an account (#map=N, the shareable link). mapReadOnly is true while viewing
  // someone else's map: it can be looked at but not changed.
  var currentMapId = null;
  var currentSid = null;
  var mapReadOnly = false;
  // True inside the Windows desktop app (it serves this page from civitas://app/). There, maps are saved on the
  // computer and shared as files, so the website's accounts and share links are hidden.
  var IS_DESKTOP = location.protocol === 'civitas:';
  // Website accounts and share links are switched off for now (no longer hosted on WordPress): every build saves
  // maps on this computer and shares them as files. Set to false to bring the website accounts back.
  var FILE_SHARING = true;

  function draftKey(id) { return 'civitas-draft-' + id; }

  function allocateMapId() {
    var n = 0;
    try { n = parseInt(localStorage.getItem('civitas-next-map-id'), 10) || 0; } catch (err) {}
    n += 1;
    try { localStorage.setItem('civitas-next-map-id', String(n)); } catch (err) {}
    return n;
  }

  function clearCurrentDraft() {
    if (currentMapId !== null) {
      try { localStorage.removeItem(draftKey(currentMapId)); } catch (err) {}
    }
    currentMapId = null;
    currentSid = null;
    setReadOnly(false);
    location.hash = '';
  }

  var DEM =[0x13, 0x75, 0xB7];
  var REP = [0xC9, 0x31, 0x35];
  var NODATA_FILL = '#e3e5e9';
  var NODATA_FAINT_FILL = '#6b7280';
  var DEFAULT_DEM_HEX = '#1375B7', DEFAULT_REP_HEX = '#C93135';
  // A race can override the two sides' colors (e.g. the 2018 Senate was Democrat vs. Democrat).
  function applyRaceColors(race) {
    var dh = (race && race.demColor) || DEFAULT_DEM_HEX, rh = (race && race.repColor) || DEFAULT_REP_HEX;
    DEM = hexToRgb(dh);
    REP = hexToRgb(rh);
    var root = document.documentElement.style;
    root.setProperty('--dem', dh);
    root.setProperty('--rep', rh);
    root.setProperty('--dem-mid', lerpColor(0.57, DEM));
    root.setProperty('--rep-mid', lerpColor(0.57, REP));
  }

  function lerpColor(t, target) {
    var r = Math.round(255 + (target[0] - 255) * t);
    var g = Math.round(255 + (target[1] - 255) * t);
    var b = Math.round(255 + (target[2] - 255) * t);
    return '#' + [r, g, b].map(function(v) { return v.toString(16).padStart(2, '0'); }).join('');
  }
  var POP_SCHEMES = {
    pg: { label: 'Purple/Green', stops: ['#762a83', '#9970ab', '#c2a5cf', '#e7d4e8', '#f7f7f7', '#d9f0d3', '#a6dba0', '#5aae61', '#1b7837'] },
    inferno: { label: 'Inferno', stops: ['#000004', '#1b0c41', '#4a0c6b', '#781c6d', '#a52c60', '#cf4446', '#ed6925', '#fb9b06', '#f7d13d', '#fcffa4'] },
    spectral: { label: 'Spectral', stops: ['#9e0142', '#d53e4f', '#f46d43', '#fdae61', '#fee08b', '#ffffbf', '#e6f598', '#abdda4', '#66c2a5', '#3288bd', '#5e4fa2'] },
    brbg: { label: 'Brown/Green', stops: ['#543005', '#8c510a', '#bf812d', '#dfc27d', '#f6e8c3', '#f5f5f5', '#c7eae5', '#80cdc1', '#35978f', '#01665e', '#003c30'] },
    rb: { label: 'Red/Blue', stops: ['#b2182b', '#d6604d', '#f4a582', '#fddbc7', '#f7f7f7', '#d1e5f0', '#92c5de', '#4393c3', '#2166ac'] },
    ryg: { label: 'Red/Yellow/Green', stops: ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#ffffbf', '#d9ef8b', '#a6d96a', '#66bd63', '#1a9850'] },
    reds: { label: 'Reds', stops: ['#fff5f0', '#fee0d2', '#fcbba1', '#fc9272', '#fb6a4a', '#ef3b2c', '#cb181d', '#a50f15', '#67000d'] },
    blues: { label: 'Blues', stops: ['#f7fbff', '#deebf7', '#c6dbef', '#9ecae1', '#6baed6', '#4292c6', '#2171b5', '#08519c', '#08306b'] },
    greens: { label: 'Greens', stops: ['#f7fcf5', '#e5f5e0', '#c7e9c0', '#a1d99b', '#74c476', '#41ab5d', '#238b45', '#006d2c', '#00441b'] },
    orange: { label: 'Oranges', stops: ['#fff5eb', '#fee6ce', '#fdd0a2', '#fdae6b', '#fd8d3c', '#f16913', '#d94801', '#a63603', '#7f2704'] },
    grey: { label: 'Greys', stops: ['#ffffff', '#f0f0f0', '#d9d9d9', '#bdbdbd', '#969696', '#737373', '#525252', '#252525', '#000000'] },
  };
  var popSchemeKey = 'spectral';
  function hexToRgb(h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; }
  function schemeColor(t) {
    var stops = POP_SCHEMES[popSchemeKey].stops;
    t = Math.min(1, Math.max(0, t)) * (stops.length - 1);
    var i = Math.min(stops.length - 2, Math.floor(t)), f = t - i;
    var a = hexToRgb(stops[i]), b = hexToRgb(stops[i + 1]);
    return '#' + [0, 1, 2].map(function(c) {
      return Math.round(a[c] + (b[c] - a[c]) * f).toString(16).padStart(2, '0');
    }).join('');
  }
  function schemeGradientCss() {
    return 'linear-gradient(to right, ' + POP_SCHEMES[popSchemeKey].stops.join(', ') + ')';
  }
  var layerMode = 'election';
  var POP_LAYERS = [
    { key: 'pop', label: 'ACS (2024)', rowLabel: 'Population (2024)', est: false },
    { key: 'pop20', label: 'Census (2020)', rowLabel: 'Pop. Census (2020)', est: false },
    { key: 'pop10', label: 'Census (2010)', rowLabel: 'Pop. Census (2010)', est: true },
    { key: 'pop00', label: 'Census (2000)', rowLabel: 'Pop. Census (2000)', est: true },
  ];
  var POP_MORE_LAYERS = [
    { key: 'vap', label: 'Voting Age Pop. · ACS (2024)', rowLabel: 'VAP ACS (2024)', est: false },
    { key: 'vap20', label: 'Voting Age Pop. · Census (2020)', rowLabel: 'VAP Census (2020)', est: false },
    { key: 'cvap', label: 'Citizen VAP · ACS (2024)', rowLabel: 'CVAP ACS (2024)', est: false },
  ];
  var POP_MORE_KEYS = ['vap', 'vap20', 'vap22', 'cvap'];
  var ETH_GROUPS = [
    { key: 'eth_white', label: 'White', rowLabel: 'White %', pct: true, est: false, color: '#2b6cb0' },
    { key: 'eth_black', label: 'Black', rowLabel: 'Black %', pct: true, est: false, color: '#2f9e44' },
    { key: 'eth_hisp', label: 'Hispanic', rowLabel: 'Hispanic %', pct: true, est: false, color: '#d6403a' },
    { key: 'eth_asian', label: 'Asian', rowLabel: 'Asian %', pct: true, est: false, color: '#f2c200' },
    { key: 'eth_native', label: 'Native', rowLabel: 'Native %', pct: true, est: false, color: '#8b5a2b' },
    { key: 'eth_pacific', label: 'Pacific', rowLabel: 'Pacific %', pct: true, est: false, color: '#7c4dbd' },
  ];
  var ETH_TOP = { key: 'eth_top', label: 'Most Prevalent', rowLabel: 'Most prevalent', cat: true, est: false };
  var ETH_LAYERS = [ETH_TOP].concat(ETH_GROUPS);
  var EDU_KEYS = ['edu_total', 'edu_coll', 'edu_noncoll', 'edu_lths', 'edu_hs', 'edu_somecol', 'edu_bach', 'edu_grad'];
  var EDU_LAYERS = [
    { key: 'edu_noncoll', label: 'Non-College', rowLabel: 'Non-College %', pct: true, est: false, edu: true, den: 'edu_total' },
    { key: 'edu_coll', label: 'College+', rowLabel: 'College+ %', pct: true, est: false, edu: true, den: 'edu_total' },
    { key: 'edu_lths', label: 'Less than High School', rowLabel: 'Less than HS %', pct: true, est: false, edu: true, den: 'edu_total' },
    { key: 'edu_hs', label: 'High School', rowLabel: 'High School %', pct: true, est: false, edu: true, den: 'edu_total' },
    { key: 'edu_somecol', label: 'Some College', rowLabel: 'Some College %', pct: true, est: false, edu: true, den: 'edu_total' },
    { key: 'edu_bach', label: 'Bachelor’s Degree', rowLabel: 'Bachelor’s %', pct: true, est: false, edu: true, den: 'edu_total' },
    { key: 'edu_grad', label: 'Graduate Degree+', rowLabel: 'Graduate+ %', pct: true, est: false, edu: true, den: 'edu_total' },
  ];
  var AGE_KEYS = ['age_sum', 'age_total', 'age_u18', 'age_18_29', 'age_30_44', 'age_45_64', 'age_65'];
  function ageLayer(key, label, rowLabel) {
    return { key: key, label: label, rowLabel: rowLabel, pct: true, est: false, age: true, den: 'age_total' };
  }
  var AGE_LAYERS = [
    { key: 'age_avg', label: 'Average Age', rowLabel: 'Average Age', est: false, age: true, avg: true, decimal: true },
    ageLayer('age_u18', 'Under 18', 'Under 18 %'),
    ageLayer('age_18_29', '18–29', '18–29 %'),
    ageLayer('age_30_44', '30–44', '30–44 %'),
    ageLayer('age_45_64', '45–64', '45–64 %'),
    ageLayer('age_65', '65+', '65+ %'),
  ];
  var ORIGIN_KEYS = ['orig_total', 'orig_instate', 'orig_outstate', 'orig_foreign', 'cit_total', 'cit_yes'];
  function originLayer(key, label, rowLabel, den) {
    return { key: key, label: label, rowLabel: rowLabel, pct: true, est: false, origin: true, den: den };
  }
  var ORIGIN_LAYERS = [
    originLayer('orig_instate', 'Born In-State', 'Born In-State %', 'orig_total'),
    originLayer('orig_outstate', 'Born Out-of-State', 'Born Out-of-State %', 'orig_total'),
    originLayer('orig_foreign', 'Foreign Born', 'Foreign Born %', 'orig_total'),
    originLayer('cit_yes', 'Citizen %', 'Citizen %', 'cit_total'),
  ];
  var LANG_KEYS = ['lang_total', 'eng_vw', 'eng_lvw', 'lang_english', 'lang_spanish', 'lang_indo', 'lang_asian', 'lang_other'];
  function langLayer(key, label, title) {
    return { key: key, label: label, rowLabel: label + ' %', pct: true, est: false, pop5: true, title: title, den: 'lang_total' };
  }
  var ENG_LAYERS = [
    langLayer('eng_vw', 'English Very Well +', 'English proficiency'),
    langLayer('eng_lvw', 'English Less Than Very Well', 'English proficiency'),
  ];
  var LANG_LAYERS = [
    langLayer('lang_english', 'English', 'Language at home'),
    langLayer('lang_spanish', 'Spanish', 'Language at home'),
    langLayer('lang_indo', 'Other Indo-European', 'Language at home'),
    langLayer('lang_asian', 'Asian / Pacific Island', 'Language at home'),
    langLayer('lang_other', 'Other Language', 'Language at home'),
  ];
  var INC_KEYS = ['inc_medw', 'inc_medhh', 'inc_total', 'inc_lt50k', 'inc_50_100k', 'inc_gt100k', 'inc_lt30k', 'inc_30_50k', 'inc_50_75k', 'inc_75_100k', 'inc_100_200k', 'inc_gt200k'];
  function incLayer(key, label, rowLabel) {
    return { key: key, label: label, rowLabel: rowLabel, pct: true, est: false, inc: true, den: 'inc_total' };
  }
  var INC_TOP_LAYERS = [
    incLayer('inc_lt50k', 'Under $50K', 'Under $50K %'),
    incLayer('inc_50_100k', '$50K–$100K', '$50K–$100K %'),
    incLayer('inc_gt100k', '$100K+', '$100K+ %'),
  ];
  var INC_DETAIL_LAYERS = [
    incLayer('inc_lt30k', 'Under $30K', 'Under $30K %'),
    incLayer('inc_30_50k', '$30K–$50K', '$30K–$50K %'),
    incLayer('inc_50_75k', '$50K–$75K', '$50K–$75K %'),
    incLayer('inc_75_100k', '$75K–$100K', '$75K–$100K %'),
    incLayer('inc_100_200k', '$100K–$200K', '$100K–$200K %'),
    incLayer('inc_gt200k', '$200K+', '$200K+ %'),
  ];
  var INC_MEDIAN_LAYER = { key: 'inc_med', label: 'Median Household Income', rowLabel: 'Median HH Income', est: false, inc: true, dollar: true, median: true };
  var INC_LAYERS = [INC_MEDIAN_LAYER].concat(INC_TOP_LAYERS, INC_DETAIL_LAYERS);
  function setIncomeMedian(o) {
    o.inc_med = o.inc_medhh > 0 ? o.inc_medw / o.inc_medhh : 0;
    o.age_avg = o.age_total > 0 ? o.age_sum / o.age_total : 0;
  }
  var popKey = 'pop';
  function popLayerFor(key) {
    for (var n = 0; n < INC_LAYERS.length; n++) if (INC_LAYERS[n].key === key) return INC_LAYERS[n];
    for (var pm = 0; pm < POP_MORE_LAYERS.length; pm++) if (POP_MORE_LAYERS[pm].key === key) return POP_MORE_LAYERS[pm];
    for (var i = 0; i < POP_LAYERS.length; i++) if (POP_LAYERS[i].key === key) return POP_LAYERS[i];
    for (var j = 0; j < ETH_LAYERS.length; j++) if (ETH_LAYERS[j].key === key) return ETH_LAYERS[j];
    for (var m = 0; m < EDU_LAYERS.length; m++) if (EDU_LAYERS[m].key === key) return EDU_LAYERS[m];
    for (var ag = 0; ag < AGE_LAYERS.length; ag++) if (AGE_LAYERS[ag].key === key) return AGE_LAYERS[ag];
    for (var og = 0; og < ORIGIN_LAYERS.length; og++) if (ORIGIN_LAYERS[og].key === key) return ORIGIN_LAYERS[og];
    for (var en = 0; en < ENG_LAYERS.length; en++) if (ENG_LAYERS[en].key === key) return ENG_LAYERS[en];
    for (var lg = 0; lg < LANG_LAYERS.length; lg++) if (LANG_LAYERS[lg].key === key) return LANG_LAYERS[lg];
    return POP_LAYERS[0];
  }
  function layerValue(o, key) {
    var L = popLayerFor(key);
    if (L.pct) {
      var den = o[L.den || 'pop'];
      return den > 0 ? (o[key] || 0) / den * 100 : null;
    }
    return o[key] || 0;
  }
  function formatLayerValue(v, L) {
    if (v === null) return '\u2014';
    return L.pct ? v.toFixed(1) + '%' : L.decimal ? v.toFixed(1) : (L.dollar ? '$' : '') + Math.round(v).toLocaleString();
  }
  function mixHex(a, b, t) {
    var x = hexToRgb(a), y = hexToRgb(b);
    return '#' + [0, 1, 2].map(function(c) {
      return Math.round(x[c] + (y[c] - x[c]) * t).toString(16).padStart(2, '0');
    }).join('');
  }
  var CAT_PCT_LO = 30, CAT_PCT_HI = 100;
  function shadeStops(color) { return [mixHex(color, '#ffffff', 0.82), color, mixHex(color, '#000000', 0.5)]; }
  function shadeFor(color, pct) {
    var t = Math.min(1, Math.max(0, (pct - CAT_PCT_LO) / (CAT_PCT_HI - CAT_PCT_LO))), st = shadeStops(color);
    return t < 0.5 ? mixHex(st[0], st[1], t / 0.5) : mixHex(st[1], st[2], (t - 0.5) / 0.5);
  }
  function topEthnicity(o) {
    if (!(o.pop > 0)) return null;
    var best = null, bestN = 0;
    for (var i = 0; i < ETH_GROUPS.length; i++) {
      var n = o[ETH_GROUPS[i].key] || 0;
      if (n > bestN) { bestN = n; best = ETH_GROUPS[i]; }
    }
    return best ? { group: best, pct: bestN / o.pop * 100 } : null;
  }
  function layerText(o, L) {
    if (L.cat) {
      var t = topEthnicity(o);
      return t ? t.group.label + ' ' + t.pct.toFixed(1) + '%' : '\u2014';
    }
    return formatLayerValue(layerValue(o, L.key), L);
  }
  var POP_PCT_LO = 0.1;
  var POP_PCT_HI = 99.9;
  var popScale = { lo: 0, hi: 1 };
  function computePopScale() {
    if (popLayerFor(popKey).pct || popLayerFor(popKey).cat) { popScale = { lo: 0, hi: 100 }; return; }
    var vals = [];
    for (var i = 0; i < shapes.length; i++) if (shapes[i][popKey] > 0) vals.push(shapes[i][popKey]);
    if (!vals.length) { popScale = { lo: 0, hi: 0 }; return; }
    vals.sort(function(a, b) { return a - b; });
    var last = vals.length - 1;
    popScale = {
      lo: vals[Math.floor(last * POP_PCT_LO / 100)],
      hi: vals[Math.ceil(last * POP_PCT_HI / 100)],
    };
  }
  function scalePos(v, lo, hi) { return hi > lo ? (v - lo) / (hi - lo) : 0.5; }
  var districtPopScale = { lo: 0, hi: 0 };
  function computeDistrictPopScale() {
    if (popLayerFor(popKey).pct || popLayerFor(popKey).cat) { districtPopScale = { lo: 0, hi: 100 }; return; }
    if (popLayerFor(popKey).median) { districtPopScale = { lo: 30000, mid: 100000, hi: 200000 }; return; }
    var lo = Infinity, hi = -Infinity;
    for (var k = 1; k <= districtCount; k++) {
      var d = districtStats[k];
      if (!d || !(d.count > 0)) continue;
      var v = d[popKey] || 0;
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    districtPopScale = lo <= hi ? { lo: lo, hi: hi } : { lo: 0, hi: 0 };
  }
  var electionView = 'margin';
  var turnoutScale = { lo: 0, hi: 100 };
  function vapKeyFor(race) { return race && race.year === '2022' ? 'vap22' : race && (race.year === '2020' || race.year === '2018' || race.year === '2016') ? 'vap20' : 'vap'; }
  function turnoutOf(o) {
    if (!activeRace) return null;
    var vap = o[vapKeyFor(activeRace)];
    var votes = o.dem + o.rep + o.other;
    return vap > 0 && votes > 0 ? votes / vap : null;
  }
  var raceMarginSpans = {};
  var raceButtonEls = {};
  // Race boxes are shaded like the map: pale for a close race, deeper as the statewide margin grows. Uses the
  // race's own two colors, so it does not depend on which race is open.
  function sameParty(race) {
    if (race.group !== 'more' || race.moreGroup === 'statewide') return null;
    var a = /\((\w)\)$/.exec(race.demName || ''), b = /\((\w)\)$/.exec(race.repName || '');
    return a && b && a[1] === b[1] && (a[1] === 'D' || a[1] === 'R') ? a[1] : null;
  }
  function raceBoxColor(race) {
    var sp = sameParty(race);
    if (sp) return sp === 'D' ? DEFAULT_DEM_HEX : DEFAULT_REP_HEX;
    var m = race.margin;
    if (m == null) {
      var found = /(\d+)$/.exec(race.marginText || '');
      if (found && race.winner) m = (race.winner === 'dem' ? 1 : -1) * parseInt(found[1], 10) / 100;
    }
    if (m == null) return '';
    var side = hexToRgb(m > 0 ? (race.demColor || DEFAULT_DEM_HEX) : (race.repColor || DEFAULT_REP_HEX));
    return lerpColor(Math.min(Math.abs(m) / DISTRICT_LEAN_SCALE, 1), side);
  }
  function updateRaceButtons() {
    var turnoutView = electionView === 'turnout';
    allRaces.forEach(function(race) {
      var span = raceMarginSpans[race.key], btn = raceButtonEls[race.key];
      if (!span || !btn) return;
      var t = turnoutView && race.turnout != null ? race.turnout : null;
      span.textContent = t !== null ? (t * 100).toFixed(1) + '%' : race.marginText;
      var col = t !== null ? layerFillTurnout(t) : raceBoxColor(race);
      var isActive = btn.classList.contains('active');
      btn.style.borderColor = col;
      btn.style.background = isActive ? col : '';
      if (isActive && col) {
        var rgb = hexToRgb(col);
        btn.style.color = (rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114) > 150 ? '#1a1305' : '#ffffff';
        span.style.color = 'inherit';
      } else {
        btn.style.color = '';
        span.style.color = col;
      }
    });
  }
  function layerFillTurnout(t) {
    return t === null ? NODATA_FILL : schemeColor(scalePos(t * 100, turnoutScale.lo, turnoutScale.hi));
  }
  // The race boxes show each race's statewide turnout in the Turnout view. That needs every main race's vote
  // files (hundreds of requests), so it is only fetched when someone actually switches to Turnout, not on load.
  var raceTurnoutsPromise = null;
  function ensureRaceTurnouts() {
    if (raceTurnoutsPromise) return raceTurnoutsPromise;
    var main = allRaces.filter(function(r) { return r.group !== 'more'; });
    raceTurnoutsPromise = loadGeometry().then(function() {
      return Promise.all(main.map(function(race) {
        return fetchRaceRecords(race).then(function(records) {
          var key = vapKeyFor(race), votes = 0, vap = 0;
          for (var i = 0; i < records.length; i++) votes += records[i].dem + records[i].rep + records[i].other;
          for (var j = 0; j < shapes.length; j++) vap += shapes[j][key];
          race.turnout = vap > 0 ? votes / vap : null;
        });
      }));
    }).then(updateRaceButtons).catch(function() { raceTurnoutsPromise = null; });
    return raceTurnoutsPromise;
  }

  // ---- Shift: the change between two elections (To minus From), for both the Margin and Turnout views ----
  // Each shape/aggregate carries the From race's votes in shA* and the To race's in shB*.
  var SHIFT_KEYS = ['shAd', 'shAr', 'shAo', 'shBd', 'shBr', 'shBo'];
  var shiftMode = false, shiftReady = false, shiftFromKey = null, shiftToKey = null, shiftToken = 0;
  var SHIFT_MARGIN_SCALE = { precinct: 0.4, district: 0.15 };
  var SHIFT_TURNOUT_SCALE = { precinct: 0.3, district: 0.1 };
  var TSHIFT_NEG = [0xD7, 0x30, 0x27], TSHIFT_POS = [0x1A, 0x98, 0x50];
  var shiftBox = document.getElementById('shift-box');
  var shiftPanel = document.getElementById('shift-panel');
  var shiftFromSel = document.getElementById('shift-from');
  var shiftToSel = document.getElementById('shift-to');
  function shiftActive() { return shiftMode && shiftReady && !!shiftFromKey && !!shiftToKey; }
  function marginAt(d, r) { var two = d + r; return two > 0 ? (d - r) / two : null; }
  function shiftParts(o) {
    var vapA = o[vapKeyFor(raceByKey(shiftFromKey))], vapB = o[vapKeyFor(raceByKey(shiftToKey))];
    var votesA = o.shAd + o.shAr + o.shAo, votesB = o.shBd + o.shBr + o.shBo;
    var p = {
      mA: marginAt(o.shAd, o.shAr), mB: marginAt(o.shBd, o.shBr),
      tA: vapA > 0 && votesA > 0 ? votesA / vapA : null, tB: vapB > 0 && votesB > 0 ? votesB / vapB : null
    };
    p.margin = p.mA !== null && p.mB !== null ? p.mB - p.mA : null;
    p.turnout = p.tA !== null && p.tB !== null ? p.tB - p.tA : null;
    return p;
  }
  function shiftFill(o, isDistrict) {
    var p = shiftParts(o), k = isDistrict ? 'district' : 'precinct';
    if (electionView === 'turnout') {
      if (p.turnout === null) return NODATA_FILL;
      return lerpColor(Math.min(Math.abs(p.turnout) / SHIFT_TURNOUT_SCALE[k], 1), p.turnout > 0 ? TSHIFT_POS : TSHIFT_NEG);
    }
    return p.margin === null ? NODATA_FILL : colorFor(p.margin, SHIFT_MARGIN_SCALE[k]);
  }
  function fmtMarginAt(m) { return m === null ? 'n/a' : (m >= 0 ? 'D+' : 'R+') + Math.abs(m * 100).toFixed(1); }
  function fmtTurnoutAt(t) { return t === null ? 'n/a' : (t * 100).toFixed(1) + '%'; }
  function updateShiftRows(i, o) {
    var on = shiftActive() && layerMode === 'election';
    ['shift', 'shiftft'].forEach(function(r) { document.getElementById(i + '-' + r + '-row').hidden = !on; });
    if (!on) return;
    var p = shiftParts(o), t = electionView === 'turnout', v = t ? p.turnout : p.margin;
    document.getElementById(i + '-shift-label').textContent = t ? 'Turnout shift' : 'Margin shift';
    document.getElementById(i + '-shift').textContent = v === null ? 'no data'
      : t ? (v >= 0 ? '+' : '−') + Math.abs(v * 100).toFixed(1) + ' pts'
          : (v >= 0 ? 'Dem +' : 'Rep +') + Math.abs(v * 100).toFixed(1) + ' pts';
    document.getElementById(i + '-shiftft').textContent = t
      ? fmtTurnoutAt(p.tA) + ' → ' + fmtTurnoutAt(p.tB)
      : fmtMarginAt(p.mA) + ' → ' + fmtMarginAt(p.mB);
  }
  function shiftRaceName(key) { var r = raceByKey(key); return r ? r.year + ' ' + r.label : ''; }
  function shiftTitle() {
    return (electionView === 'turnout' ? 'Turnout' : 'Margin') + ' shift · ' + shiftRaceName(shiftFromKey) + ' → ' + shiftRaceName(shiftToKey);
  }
  function renderShiftLegend() {
    var t = electionView === 'turnout', sc = t ? SHIFT_TURNOUT_SCALE : SHIFT_MARGIN_SCALE;
    function block(label, v) {
      var hi = Math.round(v * 100), mid = Math.round(v * 500) / 10;
      return '<div class="legend-scale-label">' + label + '</div>' +
        '<div class="legend-bar"' + (t ? ' style="background:linear-gradient(to right, #d73027, #ffffff, #1a9850)"' : '') + '></div>' +
        '<div class="legend-ticks"><span>-' + hi + '</span><span>-' + mid + '</span><span>0</span><span>+' + mid + '</span><span>+' + hi + '</span></div>';
    }
    document.getElementById('legend-shift').innerHTML =
      block(capFirst(geoUnit(false)) + (t ? ' turnout shift' : ' margin shift'), sc.precinct) +
      block('District ' + (t ? 'turnout' : 'margin') + ' shift', sc.district) +
      '<div class="legend-names">' + (t ? '<span>Lower turnout</span><span>Higher turnout</span>' : '<span>Toward Rep</span><span>Toward Dem</span>') + '</div>';
  }
  function refreshShift() {
    shiftReady = false;
    if (!shiftMode || !shiftFromKey || !shiftToKey) return;
    var token = ++shiftToken;
    loading.hidden = false;
    loading.textContent = 'Loading shift…';
    Promise.all([loadGeometry(), fetchRaceRecords(raceByKey(shiftFromKey)), fetchRaceRecords(raceByKey(shiftToKey))]).then(function(res) {
      if (token !== shiftToken) return;
      for (var i = 0; i < shapes.length; i++) for (var k = 0; k < SHIFT_KEYS.length; k++) shapes[i][SHIFT_KEYS[k]] = 0;
      [['shAd', 'shAr', 'shAo', res[1]], ['shBd', 'shBr', 'shBo', res[2]]].forEach(function(spec) {
        var recs = spec[3];
        for (var j = 0; j < recs.length; j++) {
          var s = shapesIndex[recs[j].county + '|' + recs[j].precinct];
          if (!s) continue;
          s[spec[0]] = recs[j].dem;
          s[spec[1]] = recs[j].rep;
          s[spec[2]] = recs[j].other;
        }
      });
      shiftReady = true;
      countyAggCache = {};
      loading.hidden = true;
      applyRaceColors(raceByKey(shiftToKey));
      recomputeDistricts();
    }).catch(function(err) {
      if (token === shiftToken) loading.textContent = 'Could not load shift: ' + err.message;
    });
  }
  function setShiftMode(on) {
    shiftMode = on;
    shiftPanel.hidden = !on;
    shiftBox.classList.toggle('active', on);
    if (on) {
      Array.prototype.forEach.call(document.querySelectorAll('#race-list .race-box'), function(b) { b.classList.remove('active'); });
      layerMode = 'election';
      refreshShift();
      syncLayerUI();
    } else {
      shiftToken++;
      shiftReady = false;
      if (activeRace) applyRaceColors(activeRace);
      if (selectedRaceKey && raceButtonEls[selectedRaceKey]) raceButtonEls[selectedRaceKey].classList.add('active');
      recomputeDistricts();
    }
  }
  function populateShiftSelects(races) {
    [shiftFromSel, shiftToSel].forEach(function(sel) {
      sel.innerHTML = '';
      races.forEach(function(r) {
        var opt = document.createElement('option');
        opt.value = r.key;
        opt.textContent = r.year + ' ' + r.label;
        sel.appendChild(opt);
      });
    });
    var to = races[0], from = races[1] || races[0];
    for (var i = 1; i < races.length; i++) if (races[i].label === to.label && races[i].year !== to.year) { from = races[i]; break; }
    shiftToKey = to.key;
    shiftFromKey = from.key;
    shiftToSel.value = shiftToKey;
    shiftFromSel.value = shiftFromKey;
  }
  shiftBox.addEventListener('click', function() { setShiftMode(!shiftMode); });
  shiftFromSel.addEventListener('change', function() { shiftFromKey = shiftFromSel.value; refreshShift(); });
  shiftToSel.addEventListener('change', function() { shiftToKey = shiftToSel.value; refreshShift(); });
  var adjCache = null;
  function buildAdjacency() {
    var n = shapes.length, owner = new Map(), nbrs = new Array(n), free = new Uint8Array(n), i, r, p;
    for (i = 0; i < n; i++) nbrs[i] = [];
    function edgeKey(a, b) {
      var ka = a[0] + ',' + a[1], kb = b[0] + ',' + b[1];
      return ka < kb ? ka + '|' + kb : kb + '|' + ka;
    }
    for (i = 0; i < n; i++) {
      for (r = 0; r < shapes[i].rings.length; r++) {
        var ring = shapes[i].rings[r];
        for (p = 0; p < ring.length - 1; p++) {
          if (ring[p][0] === ring[p + 1][0] && ring[p][1] === ring[p + 1][1]) continue;
          var k = edgeKey(ring[p], ring[p + 1]), o = owner.get(k);
          if (o === undefined) owner.set(k, i);
          else if (o >= 0 && o !== i) { nbrs[i].push(o); nbrs[o].push(i); owner.set(k, -1); }
        }
      }
    }
    for (i = 0; i < n; i++) {
      for (r = 0; r < shapes[i].rings.length && !free[i]; r++) {
        var rg = shapes[i].rings[r];
        for (p = 0; p < rg.length - 1; p++) {
          if (rg[p][0] === rg[p + 1][0] && rg[p][1] === rg[p + 1][1]) continue;
          if (owner.get(edgeKey(rg[p], rg[p + 1])) >= 0) { free[i] = 1; break; }
        }
      }
    }
    return { nbrs: nbrs, free: free };
  }
  function markEnclosedUnits() {
    var n = shapes.length, i;
    for (i = 0; i < n; i++) shapes[i].enclosed = false;
    if (!adjCache || adjCache.nbrs.length !== n) adjCache = buildAdjacency();
    var nbrs = adjCache.nbrs, free = adjCache.free, seen = new Uint8Array(n);
    function hasVotes(s) { return s.dem + s.rep + s.other > 0; }
    for (i = 0; i < n; i++) {
      if (seen[i] || hasVotes(shapes[i])) continue;
      var stack = [i], comp = [], open = false;
      seen[i] = 1;
      while (stack.length) {
        var cur = stack.pop();
        comp.push(cur);
        if (free[cur]) open = true;
        var nb = nbrs[cur];
        for (var q = 0; q < nb.length; q++) {
          var m = nb[q];
          if (!seen[m] && !hasVotes(shapes[m])) { seen[m] = 1; stack.push(m); }
        }
      }
      if (!open) for (var c = 0; c < comp.length; c++) shapes[comp[c]].enclosed = true;
    }
  }
  function layerFill(s) {
    if (layerMode === 'population') {
      if (popLayerFor(popKey).cat) {
        var top = topEthnicity(s);
        return top ? shadeFor(top.group.color, top.pct) : NODATA_FILL;
      }
      var v = layerValue(s, popKey);
      if (v === null || (!popLayerFor(popKey).pct && !(v > 0))) return NODATA_FILL;
      return schemeColor(scalePos(v, popScale.lo, popScale.hi));
    }
    if (shiftActive()) return shiftFill(s, false);
    if (activeRace && activeRace.sparse && !(s.dem + s.rep + s.other > 0) && !s.enclosed) return NODATA_FAINT_FILL;
    if (electionView === 'turnout') {
      return layerFillTurnout(turnoutOf(s));
    }
    return colorFor(s.margin, undefined, s.lead);
  }
  var DISTRICT_LEAN_SCALE = 0.3;
  function districtLayerFill(stats) {
    if (!stats) return NODATA_FILL;
    if (layerMode === 'population') {
      if (!(stats.count > 0)) return NODATA_FILL;
      if (popLayerFor(popKey).cat) {
        var dtop = topEthnicity(stats);
        return dtop ? shadeFor(dtop.group.color, dtop.pct) : NODATA_FILL;
      }
      var dv = layerValue(stats, popKey);
      if (dv === null) return NODATA_FILL;
      if (districtPopScale.mid !== undefined) {
        var dm = districtPopScale.mid;
        return schemeColor(dv <= dm ? 0.5 * scalePos(dv, districtPopScale.lo, dm) : 0.5 + 0.5 * scalePos(dv, dm, districtPopScale.hi));
      }
      return schemeColor(scalePos(dv, districtPopScale.lo, districtPopScale.hi));
    }
    if (shiftActive() && stats.count > 0) return shiftFill(stats, true);
    if (electionView === 'turnout') {
      return layerFillTurnout(turnoutOf(stats));
    }
    return colorFor(stats.margin, DISTRICT_LEAN_SCALE, stats.lead);
  }
  function colorFor(margin, maxMargin, lead) {
    if (margin === null) return NODATA_FILL;
    var t = Math.min(Math.abs(margin) / (maxMargin || 1.0), 1.0);
    return lerpColor(t, lead === 'x' ? OTHER_RGB : (margin > 0 ? DEM : REP));
  }
  var OTHER_RGB = [0x69, 0x69, 0x69];
  function setMargin(o) {
    var d = o.dem, r = o.rep, x = o.other;
    o.lead = null;
    if (!(d + r + x > 0)) { o.margin = null; return; }
    var order = [['d', d], ['r', r], ['x', x]].sort(function(a, b) { return b[1] - a[1]; });
    if (order[0][0] !== 'x' && order[1][0] !== 'x') {
      o.margin = d + r > 0 ? (d - r) / (d + r) : null;
      o.lead = o.margin === null ? null : (o.margin >= 0 ? 'd' : 'r');
      return;
    }
    var top = order[0], second = order[1], mag = (top[1] - second[1]) / (top[1] + second[1]);
    o.lead = top[0];
    o.margin = top[0] === 'r' ? -mag : mag;
  }
  function leaderName(o, race) {
    return o.lead === 'x' ? 'Other' : (o.margin >= 0 ? race.demShort : race.repShort);
  }
  var base = { x: 0, y: 0, w: 1, h: 1 };
  var view = { x: 0, y: 0, w: 1, h: 1 };
  var minScale = 0.55, maxScale = 100, defaultScale = 0.85;
  var borderBase = 0.15;
  var SEAM_PLUG_WIDTH = 1.5;
  var DISTRICT_PLUG_WIDTH = 2;
  var districtBorderBase = 1;
  var countyBorderBase = 0.5;
  var borderColor = '#000000';
  var districtBorderColor = '#000000';
  var countyBorderColor = '#000000';
  var COUNTY_BORDER_ALPHA = 0.85;
  function hexToRgba(hex, a) {
    var c = hexToRgb(hex);
    return 'rgba(' + c[0] + ', ' + c[1] + ', ' + c[2] + ', ' + a + ')';
  }
  var showDistrictLabels = false;
  var showUnitsInDistrict = false;
  var showCountyBorders = false;
  var highlightDistrict = false;
  function isDimmed(s) {
    return highlightDistrict && activeDistrictId !== null && s.districtId !== null && s.districtId !== activeDistrictId;
  }
  function showsUnit(s) {
    return showUnitsInDistrict && activeDistrictId !== null && s.districtId === activeDistrictId;
  }
  var countyBorderPath = null;
  var overlayColor = '#000000', overlayWidth = 1;   // boundary overlay line style (px)
  var overlayLines = null, overlayPath = null, overlayLabel = '';   // uploaded GeoJSON boundary overlay (view only)
  var countyRecordPaths = [];   // one Path2D per county outline, in the same order as counties.json
  var countyOutlineCache = {};  // county name -> the matching outline Path2D (or false when none matched)
  var districtBorderSegments = [];
  var districtFillPaths = {};
  var LOD_EPS = [0, 0.4, 1.2];
  var districtFillLod = [{}, {}, {}];
  var districtBorderLod = [[], [], []];
  function lodForScale(cssScale) { return cssScale <= 0.65 ? 2 : (cssScale <= 2 ? 1 : 0); }
  function decimateRing(ring, eps) {
    var n = ring.length;
    if (n <= 8) return ring;
    var e2 = eps * eps, out = [ring[0]], lx = ring[0][0], ly = ring[0][1];
    for (var i = 1; i < n - 1; i++) {
      var dx = ring[i][0] - lx, dy = ring[i][1] - ly;
      if (dx * dx + dy * dy >= e2) { out.push(ring[i]); lx = ring[i][0]; ly = ring[i][1]; }
    }
    out.push(ring[n - 1]);
    return out.length >= 4 ? out : ring;
  }
  function addRingToPath(path, ring) {
    path.moveTo(ring[0][0], ring[0][1]);
    for (var p = 1; p < ring.length; p++) path.lineTo(ring[p][0], ring[p][1]);
    path.closePath();
  }
  function shapePath(s, lod) {
    var p = s.paths[lod];
    if (p) return p;
    p = new Path2D();
    for (var r = 0; r < s.rings.length; r++) addRingToPath(p, lod ? decimateRing(s.rings[r], LOD_EPS[lod]) : s.rings[r]);
    s.paths[lod] = p;
    return p;
  }
  var districtLabelPoints = {};
  var shapes = [];
  var strokeShapes = [];

  function parseRings(d) {
    var rings = [];
    var ringStrs = d.split(' Z');
    for (var i = 0; i < ringStrs.length; i++) {
      var s = ringStrs[i].trim();
      if (!s) continue;
      if (s.charAt(0) === 'M') s = s.slice(1).trim();
      var parts = s.split(' ');
      var ring = [];
      for (var j = 0; j < parts.length; j++) {
        var xy = parts[j].split(',');
        if (xy.length !== 2) continue;
        ring.push([parseFloat(xy[0]), parseFloat(xy[1])]);
      }
      if (ring.length) rings.push(ring);
    }
    return rings;
  }

  var MIN_RING_AREA = 1;

  function ringArea(ring) {
    var area = 0;
    for (var i = 0; i < ring.length - 1; i++) {
      area += ring[i][0] * ring[i + 1][1] - ring[i + 1][0] * ring[i][1];
    }
    return Math.abs(area) / 2;
  }

  function ringCentroid(ring) {
    var a = 0, cx = 0, cy = 0;
    for (var i = 0; i < ring.length - 1; i++) {
      var x0 = ring[i][0], y0 = ring[i][1];
      var x1 = ring[i + 1][0], y1 = ring[i + 1][1];
      var cross = x0 * y1 - x1 * y0;
      a += cross;
      cx += (x0 + x1) * cross;
      cy += (y0 + y1) * cross;
    }
    a *= 0.5;
    if (Math.abs(a) < 1e-9) {
      var sx = 0, sy = 0, n = ring.length - 1;
      for (var i = 0; i < n; i++) { sx += ring[i][0]; sy += ring[i][1]; }
      return { x: sx / n, y: sy / n };
    }
    return { x: cx / (6 * a), y: cy / (6 * a) };
  }

  var UNION_CHUNK = 256;
  function unionItems(items, failed) {
    if (!items.length) return null;
    if (items.length === 1) return items[0].mp;
    if (items.length <= UNION_CHUNK) {
      try { return polygonClipping.union.apply(null, items.map(function(i) { return i.mp; })); } catch (err) {}
      if (items.length === 2) { failed.push(items[1].shape); return items[0].mp; }
    }
    var mid = items.length >> 1;
    var a = unionItems(items.slice(0, mid), failed);
    var b = unionItems(items.slice(mid), failed);
    if (!a) return b;
    if (!b) return a;
    try { return polygonClipping.union(a, b); } catch (err) {
      items.slice(mid).forEach(function(i) { failed.push(i.shape); });
      return a;
    }
  }

  function pointInRing(x, y, ring) {
    var inside = false;
    for (var i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      var xi = ring[i][0], yi = ring[i][1], xj = ring[j][0], yj = ring[j][1];
      if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }

  var unassignedPoints = null;
  function holeHoldsUnassignedShape(ring) {
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (var i = 0; i < ring.length; i++) {
      if (ring[i][0] < minX) minX = ring[i][0];
      if (ring[i][0] > maxX) maxX = ring[i][0];
      if (ring[i][1] < minY) minY = ring[i][1];
      if (ring[i][1] > maxY) maxY = ring[i][1];
    }
    for (var p = 0; p < unassignedPoints.length; p++) {
      var pt = unassignedPoints[p];
      if (pt.x < minX || pt.x > maxX || pt.y < minY || pt.y > maxY) continue;
      if (pointInRing(pt.x, pt.y, ring)) return true;
    }
    return false;
  }

  var districtGeomCache = {};
  var dirtyDistricts = {};
  var anyBordersDirty = true;
  var allBordersDirty = true;
  function markDistrictDirty(id) {
    if (id === null || id === undefined) return;
    dirtyDistricts[id] = true;
    anyBordersDirty = true;
  }
  function markAllBordersDirty() { allBordersDirty = true; anyBordersDirty = true; }

  function shapeCenter(s) {
    if (s.center) return s.center;
    var big = s.rings[0], bigArea = ringArea(big);
    for (var r = 1; r < s.rings.length; r++) {
      var a = ringArea(s.rings[r]);
      if (a > bigArea) { big = s.rings[r]; bigArea = a; }
    }
    s.center = ringCentroid(big);
    return s.center;
  }

  // Round every point to a grid of q map units (about 50 m at 0.1), dropping repeated points and rings that collapse.
  function snapMultiPolygon(mp, q) {
    var out = [];
    mp.forEach(function(poly) {
      var rings = [];
      poly.forEach(function(ring) {
        var pts = [];
        for (var i = 0; i < ring.length; i++) {
          var x = Math.round(ring[i][0] / q) * q, y = Math.round(ring[i][1] / q) * q;
          var last = pts[pts.length - 1];
          if (!last || last[0] !== x || last[1] !== y) pts.push([x, y]);
        }
        if (pts.length > 1 && (pts[0][0] !== pts[pts.length - 1][0] || pts[0][1] !== pts[pts.length - 1][1])) pts.push([pts[0][0], pts[0][1]]);
        if (pts.length >= 4) rings.push(pts);
      });
      if (rings.length) out.push(rings);
    });
    return out;
  }

  function buildDistrictGeom(k, list) {
    var items = [];
    for (var m = 0; m < list.length; m++) {
      var sh = list[m];
      var biggest = 0;
      for (var r = 0; r < sh.rings.length; r++) biggest = Math.max(biggest, ringArea(sh.rings[r]));
      sh.drawSelf = biggest < MIN_RING_AREA;
      items.push({ shape: sh, mp: sh.rings.map(function(ring) { return [ring]; }) });
    }
    var failedShapes = [];
    var result = unionItems(items, failedShapes);
    // Neighboring block groups/precincts often have a hairline gap between them (each was simplified on its own),
    // so a shape that touches the rest of its district only across such a gap comes out as a separate polygon and
    // gets a full outline of its own: a phantom border inside the district. When the merge leaves more than one
    // polygon, try again with the coordinates snapped to a coarse grid (which closes those gaps) and keep that if
    // it joins more of them. A district that is genuinely in several pieces stays in several pieces.
    if (result && result.length > 1) {
      var snapped = items.map(function(it) { return { shape: it.shape, mp: snapMultiPolygon(it.mp, 0.1) }; })
        .filter(function(it) { return it.mp.length; });
      var snapFailed = [];
      var result2 = snapped.length ? unionItems(snapped, snapFailed) : null;
      if (result2 && !snapFailed.length && result2.length < result.length) result = result2;
    }
    failedShapes.forEach(function(f) { f.drawSelf = true; });
    if (failedShapes.length && window.console) console.warn('district ' + k + ': ' + failedShapes.length + ' shape(s) could not be merged into the outline');
    if (!result) return null;
    var paths = [new Path2D(), new Path2D(), new Path2D()];
    var rings = [];
    var bestArea = -1, label = null;
    result.forEach(function(poly) {
      poly.forEach(function(ring, ringIdx) {
        var area = ringArea(ring);
        if (ringIdx === 0 && area < MIN_RING_AREA) return;   // holes are always kept: a tiny one may hold an unpainted shape
        var lods = [ring, decimateRing(ring, LOD_EPS[1]), decimateRing(ring, LOD_EPS[2])];
        for (var l = 0; l < 3; l++) addRingToPath(paths[l], lods[l]);
        rings.push({ outer: ringIdx === 0, lods: lods });
        if (ringIdx === 0 && area > bestArea) {
          bestArea = area;
          label = ringCentroid(ring);
        }
      });
    });
    return rings.length ? { paths: paths, rings: rings, label: label } : null;
  }

  function computeDistrictBorders() {
    if (typeof polygonClipping === 'undefined') {
      districtBorderSegments = [];
      districtFillPaths = {};
      districtFillLod = [districtFillPaths, {}, {}];
      districtBorderLod = [districtBorderSegments, [], []];
      districtLabelPoints = {};
      return;
    }
    if (!anyBordersDirty) return;
    var rebuildAll = allBordersDirty;
    var dirty = dirtyDistricts;
    dirtyDistricts = {};
    anyBordersDirty = false;
    allBordersDirty = false;
    if (rebuildAll) districtGeomCache = {};

    unassignedPoints = [];
    var byDistrict = {};
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i];
      if (s.districtId === null) {
        if (s.rings.length) unassignedPoints.push(shapeCenter(s));
        continue;
      }
      (byDistrict[s.districtId] = byDistrict[s.districtId] || []).push(s);
    }
    Object.keys(districtGeomCache).forEach(function(k) {
      if (!byDistrict[k]) delete districtGeomCache[k];
    });
    Object.keys(byDistrict).forEach(function(k) {
      if (!rebuildAll && !dirty[k] && Object.prototype.hasOwnProperty.call(districtGeomCache, k)) return;
      districtGeomCache[k] = buildDistrictGeom(k, byDistrict[k]);
    });

    districtBorderSegments = [];
    districtFillPaths = {};
    districtFillLod = [districtFillPaths, {}, {}];
    districtBorderLod = [districtBorderSegments, [], []];
    districtLabelPoints = {};
    Object.keys(districtGeomCache).forEach(function(k) {
      var g = districtGeomCache[k];
      if (!g) return;
      for (var l = 0; l < 3; l++) districtFillLod[l][k] = g.paths[l];
      if (g.label) districtLabelPoints[k] = g.label;
      g.rings.forEach(function(r) {
        if (!r.outer && !holeHoldsUnassignedShape(r.lods[0])) return;
        for (var l = 0; l < 3; l++) {
          var lr = r.lods[l];
          for (var p = 0; p < lr.length - 1; p++) districtBorderLod[l].push([lr[p], lr[p + 1]]);
        }
      });
    });
  }
  var dpr = Math.max(1, window.devicePixelRatio || 1);

  function resizeCanvas() {
    var rect = canvas.getBoundingClientRect();
    canvas.width = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
    hoverCanvas.width = canvas.width;
    hoverCanvas.height = canvas.height;
    drawHoverOutline();
  }

  var hoverCanvas = document.getElementById('hover-overlay');
  var hoverCtx = hoverCanvas.getContext('2d');
  var hoverShape = null;
  var brushRadius = 0, brushCursor = null;   // radius in screen pixels; 0 = single-shape tool
  function brushActive() { return brushRadius > 0 && (activeTool === 'paint' || activeTool === 'eraser'); }
  function setHoverShape(s) {
    if (s === hoverShape) return;
    hoverShape = s;
    drawHoverOutline();
  }
  // With "Color By County" the outline is the whole county. counties.json has no names to match on, so the
  // county's outline is the one that contains a sample of its own precincts' points (majority vote).
  function countyOutlineFor(county) {
    if (countyOutlineCache[county] !== undefined) return countyOutlineCache[county] || null;
    var list = shapesByCounty[county];
    if (!list || !countyRecordPaths.length) return null;   // not loaded yet: not cached, so it is retried
    var votes = [], sampled = 0, step = Math.max(1, Math.floor(list.length / 40)), i, j, k;
    for (j = 0; j < countyRecordPaths.length; j++) votes.push(0);
    hoverCtx.setTransform(1, 0, 0, 1, 0, 0);
    for (i = 0; i < list.length; i += step) {
      var ring = list[i].rings[0];
      if (!ring || !ring.length) continue;
      // A point well inside the shape (halfway from a vertex to the ring's average), never on a county border.
      var cx = 0, cy = 0;
      for (k = 0; k < ring.length; k++) { cx += ring[k][0]; cy += ring[k][1]; }
      var px = (ring[0][0] + cx / ring.length) / 2, py = (ring[0][1] + cy / ring.length) / 2;
      sampled++;
      for (j = 0; j < countyRecordPaths.length; j++) {
        if (hoverCtx.isPointInPath(countyRecordPaths[j], px, py, 'evenodd')) votes[j]++;
      }
    }
    var best = -1, bestVotes = 0;
    for (j = 0; j < votes.length; j++) if (votes[j] > bestVotes) { bestVotes = votes[j]; best = j; }
    // Only trust a clear majority; otherwise show the single shape's outline rather than a wrong county.
    countyOutlineCache[county] = best >= 0 && bestVotes > sampled / 2 ? countyRecordPaths[best] : false;
    return countyOutlineCache[county] || null;
  }
  function drawHoverOutline() {
    hoverCtx.setTransform(1, 0, 0, 1, 0, 0);
    hoverCtx.clearRect(0, 0, hoverCanvas.width, hoverCanvas.height);
    if (brushActive()) {
      if (!brushCursor) return;
      var bRel = base.w / view.w, bCss = baseScale * bRel, bTotal = dpr * bCss;
      var bLod = lodForScale(bCss);
      var bShapes = shapesUnderBrush(brushCursor.x, brushCursor.y);
      var bPaths = bShapes.map(function(x) { return shapePath(x, bLod); });
      hoverCtx.setTransform(bTotal, 0, 0, bTotal, dpr * offX - view.x * bTotal, dpr * offY - view.y * bTotal);
      hoverCtx.lineJoin = 'round';
      hoverCtx.strokeStyle = '#ffffff';
      hoverCtx.lineWidth = 3.5 / bCss;
      bPaths.forEach(function(p) { hoverCtx.stroke(p); });
      hoverCtx.strokeStyle = '#000000';
      hoverCtx.lineWidth = 1.5 / bCss;
      bPaths.forEach(function(p) { hoverCtx.stroke(p); });
      // the brush circle itself, thin, so its size is visible
      var brect = canvas.getBoundingClientRect();
      hoverCtx.setTransform(1, 0, 0, 1, 0, 0);
      hoverCtx.beginPath();
      hoverCtx.arc((brushCursor.x - brect.left) * dpr, (brushCursor.y - brect.top) * dpr, brushRadius * dpr, 0, Math.PI * 2);
      hoverCtx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
      hoverCtx.lineWidth = 1 * dpr;
      hoverCtx.stroke();
      return;
    }
    if (!hoverShape || activeTool === 'cursor') return;
    var relScale = base.w / view.w;
    var total = dpr * baseScale * relScale;
    var cssScale = baseScale * relScale;
    // Pick the path first: countyOutlineFor() resets the context's transform while it works.
    var p = null;
    if (paintBy === 'county' && (activeTool === 'paint' || activeTool === 'eraser')) p = countyOutlineFor(hoverShape.county);
    if (!p) p = shapePath(hoverShape, lodForScale(cssScale));
    hoverCtx.setTransform(total, 0, 0, total, dpr * offX - view.x * total, dpr * offY - view.y * total);
    hoverCtx.lineJoin = 'round';
    hoverCtx.strokeStyle = '#ffffff';
    hoverCtx.lineWidth = 3.5 / cssScale;
    hoverCtx.stroke(p);
    hoverCtx.strokeStyle = '#000000';
    hoverCtx.lineWidth = 1.5 / cssScale;
    hoverCtx.stroke(p);
  }

  var baseScale = 1, offX = 0, offY = 0;
  function computeFit() {
    var rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    baseScale = Math.min(rect.width / base.w, rect.height / base.h);
    offX = (rect.width - base.w * baseScale) / 2;
    offY = (rect.height - base.h * baseScale) / 2;
  }
  var stageEl = document.getElementById('stage');
  if (window.ResizeObserver) {
    new ResizeObserver(function() { resizeCanvas(); computeFit(); draw(); }).observe(stageEl);
  } else {
    window.addEventListener('resize', function() { resizeCanvas(); computeFit(); draw(); });
  }

  function screenToWorld(clientX, clientY) {
    var rect = canvas.getBoundingClientRect();
    var relScale = base.w / view.w;
    var cssScale = baseScale * relScale;
    return {
      x: view.x + (clientX - rect.left - offX) / cssScale,
      y: view.y + (clientY - rect.top - offY) / cssScale,
    };
  }

  var BASEMAP_TILEJSON = 'https://tiles.openfreemap.org/planet';
  var placeLabelsOn = true;
  var placeLabelsBehind = true;
  var basemapOn = true;
  var shapeAlpha = 0.8;
  var geoProj = null;
  var basemapTemplate = null;
  var basemapMaxZoom = 14;
  var basemapMetaState = 'idle';
  var basemapDrawn = [];
  var basemapZc = 0;
  var basemapBusy = false;
  var tileCache = {};
  var tileQueue = [];
  var tilesInFlight = 0;
  var tileClock = 0;
  var TILE_MAX_INFLIGHT = 6;
  var TILE_CACHE_MAX = 400;

  var BM = {
    bg: '#1c1c1c', water: '#000000', park: '#242424', boundary: '#7a7a7a', rail: '#555555',
    landcover: { wood: '#212121', forest: '#212121', grass: '#232323', farmland: '#1e1e1e', wetland: '#202020', sand: '#222222', rock: '#262626', ice: '#2a2a2a' },
    landuse: { residential: '#1f1f1f', suburb: '#1f1f1f', commercial: '#252525', retail: '#252525', industrial: '#292929', cemetery: '#222222', hospital: '#262626', school: '#242424', university: '#242424', stadium: '#242424', pitch: '#222222', playground: '#222222', railway: '#262626', military: '#272727' },
  };
  var FILL_LAYERS = ['landcover', 'landuse', 'park', 'water'];
  var ROAD_ORDER = ['minor', 'tertiary', 'secondary', 'primary', 'trunk', 'motorway'];
  var BUSY_ROADS = { primary: true, trunk: true, motorway: true };
  var ROAD_STYLE = {
    minor: { w: 1.2, fill: '#444444', casing: null, minZc: 13 },
    tertiary: { w: 1.5, fill: '#4f4f4f', casing: null, minZc: 11 },
    secondary: { w: 1.9, fill: '#5c5c5c', casing: null, minZc: 9 },
    primary: { w: 2.3, fill: '#686868', casing: null, minZc: 0 },
    trunk: { w: 2.7, fill: '#737373', casing: null, minZc: 0 },
    motorway: { w: 3.0, fill: '#808080', casing: null, minZc: 0 },
  };
  var PLACE_STYLE = {
    country: { size: 15, weight: '600', color: '#bbbbbb', pri: 0, minZc: 0, upper: true },
    city: { size: 14, weight: '600', color: '#f5f5f5', pri: 10, minZc: 0 },
    town: { size: 12, weight: '500', color: '#e6e6e6', pri: 30, minZc: 9 },
    village: { size: 10.5, weight: '400', color: '#d4d4d4', pri: 40, minZc: 11 },
    suburb: { size: 10, weight: '400', color: '#c2c2c2', pri: 50, minZc: 12.5 },
    hamlet: { size: 9.5, weight: '400', color: '#c2c2c2', pri: 55, minZc: 12.5 },
    neighbourhood: { size: 9, weight: '400', color: '#adadad', pri: 60, minZc: 14 },
    quarter: { size: 9, weight: '400', color: '#adadad', pri: 60, minZc: 14 },
    island: { size: 10, weight: '400', color: '#c2c2c2', pri: 45, minZc: 9 },
  };
  var WATER_LABEL_STYLE = { size: 11, weight: '400', color: '#8a8a8a', pri: 70, minZc: 8, italic: true };

  function makeProjection(p) {
    var D = Math.PI / 180;
    var phi1 = p.lat1 * D, phi2 = p.lat2 * D, phi0 = p.lat0 * D, lam0 = p.lon0 * D;
    var n = (Math.sin(phi1) + Math.sin(phi2)) / 2;
    var C = Math.cos(phi1) * Math.cos(phi1) + 2 * n * Math.sin(phi1);
    var rho0 = Math.sqrt(C - 2 * n * Math.sin(phi0)) / n;
    return {
      fwd: function(lon, lat) {
        var rho = Math.sqrt(C - 2 * n * Math.sin(lat * D)) / n;
        var th = n * (lon * D - lam0);
        return [(rho * Math.sin(th) - p.xmin) * p.scale, (p.ymax - (rho0 - rho * Math.cos(th))) * p.scale];
      },
      inv: function(X, Y) {
        var x = X / p.scale + p.xmin, y = p.ymax - Y / p.scale;
        var dy = rho0 - y, rho = Math.sqrt(x * x + dy * dy);
        var th = Math.atan2(x, dy);
        var s = (C - rho * rho * n * n) / (2 * n);
        return [(lam0 + th / n) / D, Math.asin(Math.max(-1, Math.min(1, s))) / D];
      },
    };
  }

  function tileLonLat(z, x, y, fx, fy) {
    var n = Math.pow(2, z);
    return [(x + fx) / n * 360 - 180, Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + fy) / n))) * 180 / Math.PI];
  }
  function lonLatToTile(lon, lat, z) {
    var n = Math.pow(2, z);
    var r = Math.max(-85.05, Math.min(85.05, lat)) * Math.PI / 180;
    return [(lon + 180) / 360 * n, (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n];
  }

  function decodeMvt(buffer) {
    var u8 = new Uint8Array(buffer), dv = new DataView(buffer), pos = 0, td = new TextDecoder();
    function varint() {
      var r = 0, m = 1, b;
      do { b = u8[pos++]; r += (b & 0x7f) * m; m *= 128; } while (b & 0x80);
      return r;
    }
    function skip(w) {
      if (w === 0) varint();
      else if (w === 1) pos += 8;
      else if (w === 2) pos += varint();
      else if (w === 5) pos += 4;
      else throw new Error('bad wire type');
    }
    function readString(len) { var s = td.decode(u8.subarray(pos, pos + len)); pos += len; return s; }
    function readValue(end) {
      var v = null;
      while (pos < end) {
        var tag = varint(), fn = tag >> 3, w = tag & 7;
        if (fn === 1) { var n = varint(); v = readString(n); }
        else if (fn === 2) { v = dv.getFloat32(pos, true); pos += 4; }
        else if (fn === 3) { v = dv.getFloat64(pos, true); pos += 8; }
        else if (fn === 4 || fn === 5) v = varint();
        else if (fn === 6) { var z = varint(); v = (z % 2) ? -(z + 1) / 2 : z / 2; }
        else if (fn === 7) v = varint() !== 0;
        else skip(w);
      }
      return v;
    }
    function readFeature(start, end) {
      pos = start;
      var f = { type: 0, tags: [], geom: [] };
      while (pos < end) {
        var tag = varint(), fn = tag >> 3, w = tag & 7;
        if (fn === 2 && w === 2) { var e = varint() + pos; while (pos < e) f.tags.push(varint()); }
        else if (fn === 3) f.type = varint();
        else if (fn === 4 && w === 2) { var e2 = varint() + pos; while (pos < e2) f.geom.push(varint()); }
        else skip(w);
      }
      return f;
    }
    function readLayer(end) {
      var layer = { name: '', extent: 4096, features: [] }, keys = [], values = [], ranges = [];
      while (pos < end) {
        var tag = varint(), fn = tag >> 3, w = tag & 7;
        if (fn === 1) { var n1 = varint(); layer.name = readString(n1); }
        else if (fn === 2) { var n2 = varint(); ranges.push([pos, pos + n2]); pos += n2; }
        else if (fn === 3) { var n3 = varint(); keys.push(readString(n3)); }
        else if (fn === 4) { var n4 = varint(); values.push(readValue(pos + n4)); }
        else if (fn === 5) layer.extent = varint();
        else skip(w);
      }
      ranges.forEach(function(r) {
        var f = readFeature(r[0], r[1]);
        f.props = {};
        for (var i = 0; i + 1 < f.tags.length; i += 2) f.props[keys[f.tags[i]]] = values[f.tags[i + 1]];
        layer.features.push(f);
      });
      pos = end;
      return layer;
    }
    var layers = {};
    while (pos < u8.length) {
      var tag = varint(), fn = tag >> 3, w = tag & 7;
      if (fn === 3 && w === 2) { var len = varint(); var L = readLayer(pos + len); layers[L.name] = L; }
      else skip(w);
    }
    return layers;
  }

  var scratchPath = new Path2D();
  function buildTile(t, layers) {
    t.fills = {};
    t.roads = {};
    t.waterways = null;
    t.rail = null;
    t.boundary = null;
    t.labels = [];
    if (!layers) return;
    function addGeom(path, f, ext) {
      var g = f.geom, i = 0, x = 0, y = 0, first = null, lx = 0, ly = 0;
      while (i < g.length) {
        var cmd = g[i++], id = cmd & 7, count = cmd >> 3;
        if (id === 7) { path.closePath(); continue; }
        for (var k = 0; k < count; k++) {
          var dx = g[i++], dy = g[i++];
          x += (dx >>> 1) ^ -(dx & 1);
          y += (dy >>> 1) ^ -(dy & 1);
          if (id === 2 && k > 0 && k < count - 1 && Math.abs(x - lx) + Math.abs(y - ly) < 3) continue;
          lx = x;
          ly = y;
          var ll = tileLonLat(t.z, t.x, t.y, x / ext, y / ext);
          var p = geoProj.fwd(ll[0], ll[1]);
          if (!first) first = p;
          if (id === 1) path.moveTo(p[0], p[1]); else path.lineTo(p[0], p[1]);
        }
      }
      return first;
    }
    function each(name, fn) {
      var L = layers[name];
      if (L) L.features.forEach(function(f) { fn(f, L.extent); });
    }
    function fillPath(layer, color) {
      var m = t.fills[layer] || (t.fills[layer] = {});
      return m[color] || (m[color] = new Path2D());
    }
    each('landcover', function(f, ext) {
      var c = BM.landcover[f.props.class];
      if (c && f.type === 3) addGeom(fillPath('landcover', c), f, ext);
    });
    each('landuse', function(f, ext) {
      var c = BM.landuse[f.props.class];
      if (c && f.type === 3) addGeom(fillPath('landuse', c), f, ext);
    });
    each('park', function(f, ext) {
      if (f.type === 3) addGeom(fillPath('park', BM.park), f, ext);
    });
    each('water', function(f, ext) {
      if (f.type === 3 && f.props.class !== 'swimming_pool') addGeom(fillPath('water', BM.water), f, ext);
    });
    each('waterway', function(f, ext) {
      var c = f.props.class;
      if (f.type === 2 && (c === 'river' || c === 'canal' || c === 'stream')) addGeom(t.waterways || (t.waterways = new Path2D()), f, ext);
    });
    each('transportation', function(f, ext) {
      if (f.type !== 2) return;
      var c = f.props.class;
      if (c === 'rail') { addGeom(t.rail || (t.rail = new Path2D()), f, ext); return; }
      if (ROAD_STYLE[c]) addGeom(t.roads[c] || (t.roads[c] = new Path2D()), f, ext);
    });
    each('boundary', function(f, ext) {
      if (f.type === 2 && f.props.admin_level <= 4 && !f.props.maritime) addGeom(t.boundary || (t.boundary = new Path2D()), f, ext);
    });
    each('place', function(f, ext) {
      if (f.type !== 1 || !f.props.name || !PLACE_STYLE[f.props.class]) return;
      var p = addGeom(scratchPath, f, ext);
      if (p) t.labels.push({ text: f.props.name, x: p[0], y: p[1], style: PLACE_STYLE[f.props.class], rank: f.props.rank || 0 });
    });
    each('water_name', function(f, ext) {
      if (f.type !== 1 || !f.props.name) return;
      var p = addGeom(scratchPath, f, ext);
      if (p) t.labels.push({ text: f.props.name, x: p[0], y: p[1], style: WATER_LABEL_STYLE, rank: 0 });
    });
  }

  function loadBasemapMeta() {
    if (basemapMetaState === 'loading' || basemapMetaState === 'ready') return;
    basemapMetaState = 'loading';
    fetch(BASEMAP_TILEJSON)
      .then(function(r) { return r.json(); })
      .then(function(tj) {
        basemapTemplate = tj.tiles && tj.tiles[0];
        basemapMaxZoom = tj.maxzoom || 14;
        basemapMetaState = basemapTemplate ? 'ready' : 'failed';
        updateBasemapHint();
        paintPending = true;
        queueFrame();
      })
      .catch(function() { basemapMetaState = 'failed'; updateBasemapHint(); });
  }

  function fetchTileBytes(url) {
    return fetch(url).then(function(r) {
      if (r.status === 404 || r.status === 204) return null;
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.arrayBuffer();
    }).then(function(buf) {
      if (!buf) return null;
      var u = new Uint8Array(buf);
      if (u.length > 2 && u[0] === 0x1f && u[1] === 0x8b && typeof DecompressionStream !== 'undefined') {
        return new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
      }
      return buf;
    });
  }

  function requestTile(z, x, y) {
    var k = z + '/' + x + '/' + y, t = tileCache[k];
    if (t) { t.used = ++tileClock; return t; }
    t = { key: k, z: z, x: x, y: y, status: 'queued', used: ++tileClock };
    tileCache[k] = t;
    tileQueue.push(t);
    return t;
  }

  function trimTileCache() {
    var keys = Object.keys(tileCache);
    if (keys.length <= TILE_CACHE_MAX) return;
    keys.sort(function(a, b) { return tileCache[a].used - tileCache[b].used; });
    for (var i = 0; i < keys.length - TILE_CACHE_MAX + 80; i++) {
      var st = tileCache[keys[i]].status;
      if (st !== 'loading' && st !== 'fetched') delete tileCache[keys[i]];
    }
  }

  function pumpTiles() {
    while (tilesInFlight < TILE_MAX_INFLIGHT && tileQueue.length) {
      var t = tileQueue.pop();
      if (t.status !== 'queued') continue;
      if (t.used < tileClock - 60) { delete tileCache[t.key]; continue; }
      t.status = 'loading';
      tilesInFlight++;
      (function(t) {
        fetchTileBytes(basemapTemplate.replace('{z}', t.z).replace('{x}', t.x).replace('{y}', t.y))
          .then(function(buf) {
            t.buf = buf;
            t.status = 'fetched';
            buildQueue.push(t);
          })
          .catch(function(err) {
            t.status = 'error';
            if (window.console) console.warn('background map tile ' + t.key + ': ' + err.message);
          })
          .then(function() {
            tilesInFlight--;
            pumpTiles();
            scheduleBuild();
          });
      })(t);
    }
  }

  var buildQueue = [];
  var buildTimer = null;
  function scheduleBuild() {
    if (buildTimer !== null || !buildQueue.length) return;
    buildTimer = setTimeout(buildNext, performance.now() < basemapBusyUntil ? 60 : 0);
  }
  function buildNext() {
    buildTimer = null;
    var t = buildQueue.pop();
    if (!t) return;
    try {
      if (geoProj !== null && tileCache[t.key] === t) {
        buildTile(t, t.buf ? decodeMvt(t.buf) : null);
        t.status = 'ready';
      } else {
        t.status = 'error';
      }
    } catch (err) {
      t.status = 'error';
      if (window.console) console.warn('background map tile ' + t.key + ': ' + err.message);
    }
    t.buf = null;
    trimTileCache();
    paintPending = true;
    queueFrame();
    scheduleBuild();
  }

  var basemapBusyUntil = 0;
  var basemapIdleTimer = null;
  function markBasemapBusy() {
    if (!basemapOn) return;
    basemapBusyUntil = performance.now() + 160;
    if (basemapIdleTimer !== null) clearTimeout(basemapIdleTimer);
    basemapIdleTimer = setTimeout(function() {
      basemapIdleTimer = null;
      paintPending = true;
      queueFrame();
    }, 180);
  }

  function updateBasemapHint() {
    var el = document.getElementById('basemap-hint');
    if (!el) return;
    if (!geoProj) el.textContent = 'This map’s data has no projection info. Rebuild the data to enable the background map.';
    else if (basemapMetaState === 'failed') el.textContent = 'Could not reach the map tile server (needs an internet connection).';
    else el.textContent = '';
  }

  function basemapTiles(cssScale, vx0, vx1, vy0, vy1) {
    var cx = (vx0 + vx1) / 2, cy = (vy0 + vy1) / 2;
    var c = geoProj.inv(cx, cy);
    var q = geoProj.fwd(c[0] + 0.05, c[1]);
    var pxPerDeg = Math.hypot(q[0] - cx, q[1] - cy) / 0.05 * cssScale;
    var zc = Math.log(360 * pxPerDeg / 256) / Math.LN2;
    var z = Math.max(2, Math.min(basemapMaxZoom, Math.round(zc - 0.58)));
    var list;
    for (;;) {
      var n = Math.pow(2, z), minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      for (var i = 0; i <= 8; i++) {
        for (var j = 0; j <= 8; j++) {
          var ll = geoProj.inv(vx0 + (vx1 - vx0) * i / 8, vy0 + (vy1 - vy0) * j / 8);
          var tp = lonLatToTile(ll[0], ll[1], z);
          if (tp[0] < minX) minX = tp[0];
          if (tp[0] > maxX) maxX = tp[0];
          if (tp[1] < minY) minY = tp[1];
          if (tp[1] > maxY) maxY = tp[1];
        }
      }
      var x0 = Math.max(0, Math.floor(minX)), x1 = Math.min(n - 1, Math.floor(maxX));
      var y0 = Math.max(0, Math.floor(minY)), y1 = Math.min(n - 1, Math.floor(maxY));
      if ((x1 - x0 + 1) * (y1 - y0 + 1) <= 40 || z <= 2) {
        list = [];
        for (var tx = x0; tx <= x1; tx++) for (var ty = y0; ty <= y1; ty++) list.push([tx, ty]);
        break;
      }
      z--;
    }
    return { zc: zc, z: z, list: list };
  }

  function tileOutline(z, x, y) {
    var p = new Path2D(), N = 6, first = true;
    function add(fx, fy) {
      var ll = tileLonLat(z, x, y, fx, fy), w = geoProj.fwd(ll[0], ll[1]);
      if (first) { p.moveTo(w[0], w[1]); first = false; } else p.lineTo(w[0], w[1]);
    }
    var i;
    for (i = 0; i <= N; i++) add(i / N, 0);
    for (i = 1; i <= N; i++) add(1, i / N);
    for (i = N - 1; i >= 0; i--) add(i / N, 1);
    for (i = N - 1; i > 0; i--) add(0, i / N);
    p.closePath();
    return p;
  }

  function ancestorTile(z, x, y) {
    for (var dz = 1; dz <= 6 && z - dz >= 0; dz++) {
      var a = tileCache[(z - dz) + '/' + (x >> dz) + '/' + (y >> dz)];
      if (a && a.status === 'ready') return a;
    }
    return null;
  }

  function drawBasemap(cssScale, vx0, vx1, vy0, vy1) {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = BM.bg;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.restore();
    basemapDrawn = [];
    if (basemapMetaState === 'idle' || basemapMetaState === 'failed') loadBasemapMeta();
    if (basemapMetaState !== 'ready') return;
    var v = basemapTiles(cssScale, vx0, vx1, vy0, vy1);
    var zc = v.zc;
    basemapZc = zc;
    var drawn = [];
    v.list.forEach(function(xy) {
      var t = requestTile(v.z, xy[0], xy[1]);
      if (t.status === 'ready') drawn.push({ t: t, clip: null });
      else {
        var a = ancestorTile(v.z, xy[0], xy[1]);
        if (a) drawn.push({ t: a, clip: tileOutline(v.z, xy[0], xy[1]) });
      }
    });
    pumpTiles();
    basemapDrawn = drawn;
    function each(fn) {
      for (var i = 0; i < drawn.length; i++) {
        var d = drawn[i];
        if (d.clip) { ctx.save(); ctx.clip(d.clip); fn(d.t); ctx.restore(); } else fn(d.t);
      }
    }
    var busy = performance.now() < basemapBusyUntil;
    basemapBusy = busy;
    ctx.lineJoin = 'bevel';
    ctx.lineCap = 'butt';
    FILL_LAYERS.forEach(function(layer) {
      each(function(t) {
        var m = t.fills[layer];
        if (!m) return;
        for (var color in m) { ctx.fillStyle = color; ctx.fill(m[color]); }
      });
    });
    var k = Math.min(4, Math.max(0.35, Math.pow(1.45, zc - 11)));
    if (!busy) {
      ctx.strokeStyle = BM.water;
      ctx.lineWidth = Math.max(0.6, 1.1 * k) / cssScale;
      each(function(t) { if (t.waterways) ctx.stroke(t.waterways); });
    }
    ROAD_ORDER.forEach(function(cls) {
      var st = ROAD_STYLE[cls];
      if (zc < st.minZc || (busy && !BUSY_ROADS[cls])) return;
      var w = st.w * k;
      if (st.casing) {
        ctx.strokeStyle = st.casing;
        ctx.lineWidth = (w + (w > 2 ? 1.6 : 1)) / cssScale;
        each(function(t) { if (t.roads[cls]) ctx.stroke(t.roads[cls]); });
      }
      ctx.strokeStyle = st.fill;
      ctx.lineWidth = w / cssScale;
      each(function(t) { if (t.roads[cls]) ctx.stroke(t.roads[cls]); });
    });
    if (zc >= 10 && !busy) {
      ctx.strokeStyle = BM.rail;
      ctx.lineWidth = 0.8 / cssScale;
      ctx.setLineDash([4 / cssScale, 3 / cssScale]);
      each(function(t) { if (t.rail) ctx.stroke(t.rail); });
    }
    ctx.strokeStyle = BM.boundary;
    ctx.lineWidth = 1.1 / cssScale;
    ctx.setLineDash([5 / cssScale, 3 / cssScale]);
    each(function(t) { if (t.boundary) ctx.stroke(t.boundary); });
    ctx.setLineDash([]);
    ctx.lineJoin = 'miter';
  }

  var labelWidthCache = {};
  function drawBasemapLabels(cssScale) {
    if (!basemapDrawn.length) return;
    var cands = [], seen = {};
    var cw = canvas.width / dpr, ch = canvas.height / dpr;
    basemapDrawn.forEach(function(d) {
      if (d.clip) return;
      d.t.labels.forEach(function(L) {
        if (basemapZc < L.style.minZc) return;
        var sx = offX + (L.x - view.x) * cssScale, sy = offY + (L.y - view.y) * cssScale;
        if (sx < -60 || sy < -20 || sx > cw + 60 || sy > ch + 20) return;
        var key = L.text + '|' + Math.round(sx / 4) + '|' + Math.round(sy / 4);
        if (seen[key]) return;
        seen[key] = true;
        cands.push({ L: L, sx: sx, sy: sy, pri: L.style.pri + L.rank * 0.1 });
      });
    });
    cands.sort(function(a, b) { return a.pri - b.pri; });
    if (cands.length > (basemapBusy ? 60 : 200)) cands.length = basemapBusy ? 60 : 200;
    ctx.save();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 3;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.85)';
    var placed = [];
    for (var i = 0; i < cands.length; i++) {
      var c = cands[i], st = c.L.style;
      var text = st.upper ? c.L.text.toUpperCase() : c.L.text;
      var font = (st.italic ? 'italic ' : '') + st.weight + ' ' + st.size + 'px "IBM Plex Sans", sans-serif';
      ctx.font = font;
      var wk = font + '|' + text;
      var w = labelWidthCache[wk];
      if (w === undefined) w = labelWidthCache[wk] = ctx.measureText(text).width;
      var x0 = c.sx - w / 2 - 3, x1 = c.sx + w / 2 + 3, y0 = c.sy - st.size / 2 - 2, y1 = c.sy + st.size / 2 + 2;
      var clash = false;
      for (var j = 0; j < placed.length; j++) {
        var b = placed[j];
        if (x0 < b[2] && x1 > b[0] && y0 < b[3] && y1 > b[1]) { clash = true; break; }
      }
      if (clash) continue;
      placed.push([x0, y0, x1, y1]);
      if (!basemapBusy) ctx.strokeText(text, c.sx, c.sy);
      ctx.fillStyle = st.color;
      ctx.fillText(text, c.sx, c.sy);
    }
    ctx.restore();
  }

  var shapeLayerCanvas = null, shapeLayerCtx = null;
  function beginShapeLayer(total, tx, ty) {
    if (!shapeLayerCanvas) {
      shapeLayerCanvas = document.createElement('canvas');
      shapeLayerCtx = shapeLayerCanvas.getContext('2d');
    }
    if (shapeLayerCanvas.width !== canvas.width || shapeLayerCanvas.height !== canvas.height) {
      shapeLayerCanvas.width = canvas.width;
      shapeLayerCanvas.height = canvas.height;
    }
    shapeLayerCtx.setTransform(1, 0, 0, 1, 0, 0);
    shapeLayerCtx.clearRect(0, 0, shapeLayerCanvas.width, shapeLayerCanvas.height);
    shapeLayerCtx.setTransform(total, 0, 0, total, tx, ty);
    return shapeLayerCtx;
  }

  function draw() {
    var relScale = base.w / view.w;
    var total = dpr * baseScale * relScale;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(total, 0, 0, total, dpr * offX - view.x * total, dpr * offY - view.y * total);

    var borderOn = borderBase > 0;
    var cssScale = baseScale * relScale;
    var lod = lodForScale(cssScale);
    var fillPaths = districtFillLod[lod];
    var borderSegs = districtBorderLod[lod];
    var margin = 3 / cssScale;
    var vx0 = view.x - offX / cssScale - margin, vx1 = view.x + (canvas.width / dpr - offX) / cssScale + margin;
    var vy0 = view.y - offY / cssScale - margin, vy1 = view.y + (canvas.height / dpr - offY) / cssScale + margin;
    var mainCtx = ctx, layered = false;
    var shapeTx = dpr * offX - view.x * total, shapeTy = dpr * offY - view.y * total;
    var basemapActive = basemapOn && geoProj !== null;
    if (basemapActive) {
      drawBasemap(cssScale, vx0, vx1, vy0, vy1);
      if (placeLabelsOn && placeLabelsBehind) drawBasemapLabels(cssScale);
    }
    var faintOn = !!(activeRace && activeRace.sparse);
    if (faintOn) {
      var fctx = beginShapeLayer(total, shapeTx, shapeTy);
      fctx.lineWidth = SEAM_PLUG_WIDTH / cssScale;
      for (var fi = 0; fi < shapes.length; fi++) {
        var fs = shapes[fi], fb = fs.bbox;
        if (fs.fill !== NODATA_FAINT_FILL) continue;
        if (fb[2] < vx0 || fb[0] > vx1 || fb[3] < vy0 || fb[1] > vy1) continue;
        if (fs.districtId !== null && fillPaths[fs.districtId] && !fs.drawSelf && !isDimmed(fs) && !showsUnit(fs)) continue;
        var fp = shapePath(fs, lod);
        fctx.fillStyle = fs.fill;
        fctx.fill(fp);
        fctx.strokeStyle = fs.fill;
        fctx.stroke(fp);
      }
      mainCtx.setTransform(1, 0, 0, 1, 0, 0);
      mainCtx.globalAlpha = 0.1;
      mainCtx.drawImage(shapeLayerCanvas, 0, 0);
      mainCtx.globalAlpha = 1;
      mainCtx.setTransform(total, 0, 0, total, shapeTx, shapeTy);
    }
    if (shapeAlpha < 1) { layered = true; ctx = beginShapeLayer(total, shapeTx, shapeTy); }
    ctx.lineWidth = SEAM_PLUG_WIDTH / cssScale;
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i], sb = s.bbox;
      if (sb[2] < vx0 || sb[0] > vx1 || sb[3] < vy0 || sb[1] > vy1) continue;
      if (faintOn && s.fill === NODATA_FAINT_FILL) continue;
      if (s.districtId !== null && fillPaths[s.districtId] && !s.drawSelf && !isDimmed(s) && !showsUnit(s)) continue;
      var sp = shapePath(s, lod);
      ctx.fillStyle = s.fill;
      ctx.fill(sp);
      ctx.strokeStyle = s.fill;
      ctx.stroke(sp);
    }

    ctx.lineWidth = DISTRICT_PLUG_WIDTH / cssScale;
    Object.keys(fillPaths).forEach(function(k) {
      if (highlightDistrict && activeDistrictId !== null && Number(k) !== activeDistrictId) return;
      if (showUnitsInDistrict && activeDistrictId !== null && Number(k) === activeDistrictId) return;
      var stats = districtStats[k] || { margin: null };
      var fillColor = districtColorMode === 'by-lean' ? districtLayerFill(stats) : districtColor(k);
      ctx.fillStyle = fillColor;
      ctx.fill(fillPaths[k]);
      ctx.strokeStyle = fillColor;
      ctx.stroke(fillPaths[k]);
    });

    // The district fill and its plug stroke can cover a small unpainted shape sitting in a hole of the district:
    // draw every unassigned shape again on top so it keeps its own color.
    for (var ui = 0; ui < shapes.length; ui++) {
      var us = shapes[ui], ub = us.bbox;
      if (us.districtId !== null) continue;
      if (ub[2] < vx0 || ub[0] > vx1 || ub[3] < vy0 || ub[1] > vy1) continue;
      if (faintOn && us.fill === NODATA_FAINT_FILL) continue;
      ctx.fillStyle = us.fill;
      ctx.fill(shapePath(us, lod));
    }

    for (var q = 0; q < strokeShapes.length; q++) {
      ctx.fillStyle = strokeShapes[q].fill;
      ctx.fill(shapePath(strokeShapes[q], lod));
    }
    if (layered) {
      ctx = mainCtx;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = shapeAlpha;
      ctx.drawImage(shapeLayerCanvas, 0, 0);
      ctx.globalAlpha = 1;
      ctx.setTransform(total, 0, 0, total, shapeTx, shapeTy);
    }

    if (borderOn) {
      ctx.lineWidth = borderBase / cssScale;
      ctx.strokeStyle = borderColor;
      for (var b = 0; b < shapes.length; b++) {
        var bs = shapes[b], bb = bs.bbox;
        if (bs.districtId !== null && !isDimmed(bs) && !showsUnit(bs)) continue;
        if (faintOn && bs.fill === NODATA_FAINT_FILL) continue;
        if (bb[2] < vx0 || bb[0] > vx1 || bb[3] < vy0 || bb[1] > vy1) continue;
        ctx.stroke(shapePath(bs, lod));
      }
    }

    if (!isPainting && districtBorderBase > 0 && borderSegs.length) {
      ctx.lineWidth = districtBorderBase / cssScale;
      ctx.strokeStyle = districtBorderColor;
      ctx.beginPath();
      for (var j = 0; j < borderSegs.length; j++) {
        var seg = borderSegs[j];
        ctx.moveTo(seg[0][0], seg[0][1]);
        ctx.lineTo(seg[1][0], seg[1][1]);
      }
      ctx.stroke();
    }

    if (showCountyBorders && countyBorderPath) {
      ctx.lineWidth = countyBorderBase / cssScale;
      ctx.strokeStyle = hexToRgba(countyBorderColor, COUNTY_BORDER_ALPHA);
      ctx.lineJoin = 'round';
      ctx.stroke(countyBorderPath);
    }

    if (overlayPath) {
      ctx.lineJoin = 'round';
      ctx.strokeStyle = overlayColor;
      ctx.lineWidth = overlayWidth / cssScale;
      ctx.stroke(overlayPath[lod]);
    }

    if (showDistrictLabels) {
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = (13 / cssScale) + 'px "IBM Plex Sans", sans-serif';
      ctx.lineWidth = 3 / cssScale;
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.65)';
      ctx.fillStyle = '#ffffff';
      Object.keys(districtLabelPoints).forEach(function(k) {
        var pt = districtLabelPoints[k];
        var label = districtLabel(k);
        ctx.strokeText(label, pt.x, pt.y);
        ctx.fillText(label, pt.x, pt.y);
      });
    }

    if (basemapActive && placeLabelsOn && !placeLabelsBehind) drawBasemapLabels(cssScale);
    drawHoverOutline();
  }

  function clampView() {
    var scale = base.w / view.w;
    if (scale <= minScale) {
      view.w = base.w / minScale;
      view.h = base.h / minScale;
      view.x = base.x - (view.w - base.w) / 2;
      view.y = base.y - (view.h - base.h) / 2;
      return;
    }
    if (scale > maxScale) {
      view.w = base.w / maxScale;
      view.h = base.h / maxScale;
    }
    var padX = base.w * 0.6, padY = base.h * 0.6;
    var minX = base.x - padX, maxX = base.x + base.w + padX - view.w;
    var minY = base.y - padY, maxY = base.y + base.h + padY - view.h;
    if (maxX < minX) view.x = minX; else view.x = Math.min(Math.max(view.x, minX), maxX);
    if (maxY < minY) view.y = minY; else view.y = Math.min(Math.max(view.y, minY), maxY);
  }

  function zoomAt(clientX, clientY, factor) {
    var anchor = screenToWorld(clientX, clientY);
    var newW = view.w / factor;
    var newH = view.h / factor;
    var newScale = base.w / newW;
    if (newScale > maxScale) {
      newW = base.w / maxScale;
      newH = base.h / maxScale;
    } else if (newScale < minScale) {
      newW = base.w / minScale;
      newH = base.h / minScale;
    }
    view.x = anchor.x - (anchor.x - view.x) * (newW / view.w);
    view.y = anchor.y - (anchor.y - view.y) * (newH / view.h);
    view.w = newW;
    view.h = newH;
    clampView();
  }

  var frameQueued = false;
  var wheelPending = false, wheelFactor = 1, wheelX = 0, wheelY = 0;
  var panDX = 0, panDY = 0, panPending = false, paintPending = false;

  function queueFrame() {
    if (!frameQueued) {
      frameQueued = true;
      requestAnimationFrame(flushFrame);
    }
  }

  function flushFrame() {
    frameQueued = false;
    var changed = false;
    if (wheelPending) {
      zoomAt(wheelX, wheelY, wheelFactor);
      wheelPending = false;
      wheelFactor = 1;
      changed = true;
    }
    if (panPending) {
      var cssScale = baseScale * (base.w / view.w);
      view.x -= panDX / cssScale;
      view.y -= panDY / cssScale;
      clampView();
      panDX = 0;
      panDY = 0;
      panPending = false;
      changed = true;
    }
    if (paintPending) {
      paintPending = false;
      changed = true;
    }
    if (changed) draw();
  }

  function wheelDeltaPixels(e) {
    var mult = e.deltaMode === 1 ? 16 : (e.deltaMode === 2 ? 400 : 1);
    return e.deltaY * mult;
  }

  canvas.addEventListener('wheel', function(e) {
    e.preventDefault();
    markBasemapBusy();
    var px = wheelDeltaPixels(e);
    var factor = Math.pow(1.0022, -px);
    factor = Math.min(2.2, Math.max(0.45, factor));
    wheelFactor *= factor;
    wheelX = e.clientX;
    wheelY = e.clientY;
    wheelPending = true;
    queueFrame();
  }, { passive: false });

  function pickAt(clientX, clientY, strict) {
    var w = screenToWorld(clientX, clientY);
    var wx = w.x, wy = w.y;
    var candidates = [];
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i], b = s.bbox;
      if (wx >= b[0] && wx <= b[2] && wy >= b[1] && wy <= b[3]) candidates.push(s);
    }
    if (!candidates.length) return null;
    candidates.sort(function(a, b) { return a.bboxArea - b.bboxArea; });
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    var hit = null;
    for (var i = 0; i < candidates.length; i++) {
      if (ctx.isPointInPath(shapePath(candidates[i], 0), wx, wy)) { hit = candidates[i]; break; }
    }
    ctx.restore();
    return hit || (strict ? null : candidates[0]);
  }

  var isPanning = false, moved = 0, lastX = 0, lastY = 0, activePointer = null;

  var dragPaintCheckbox = document.getElementById('drag-paint');
  var isPainting = false, lastPaintShape = null, strokeTool = 'paint';

  function applyToolTo(s, tool) {
    if (mapReadOnly) return [];
    var targets = paintBy === 'county' ? (shapesByCounty[s.county] || [s]) : [s];
    var changed = [];
    targets.forEach(function(x) {
      if (x.districtId !== null && districtLocked[x.districtId]) return;
      if (tool === 'eraser') {
        if (x.districtId === null) return;
        markDistrictDirty(x.districtId);
        x.districtId = null;
      } else {
        if (x.districtId === activeDistrictId) return;
        markDistrictDirty(x.districtId);
        markDistrictDirty(activeDistrictId);
        x.districtId = activeDistrictId;
      }
      changed.push(x);
    });
    return changed;
  }

  function ringHitsCircle(ring, cx, cy, r2) {
    if (pointInRing(cx, cy, ring)) return true;
    for (var i = 0; i < ring.length - 1; i++) {
      var ax = ring[i][0], ay = ring[i][1], dx = ring[i + 1][0] - ax, dy = ring[i + 1][1] - ay;
      var len2 = dx * dx + dy * dy;
      var t = len2 > 0 ? Math.max(0, Math.min(1, ((cx - ax) * dx + (cy - ay) * dy) / len2)) : 0;
      var px = ax + t * dx - cx, py = ay + t * dy - cy;
      if (px * px + py * py <= r2) return true;
    }
    return false;
  }

  // Every shape that touches the brush circle (radius in screen pixels) around the pointer.
  function shapesUnderBrush(clientX, clientY) {
    var w = screenToWorld(clientX, clientY);
    var rw = brushRadius / (baseScale * (base.w / view.w));
    var r2 = rw * rw, out = [];
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i], b = s.bbox;
      if (b[2] < w.x - rw || b[0] > w.x + rw || b[3] < w.y - rw || b[1] > w.y + rw) continue;
      for (var r = 0; r < s.rings.length; r++) {
        if (ringHitsCircle(s.rings[r], w.x, w.y, r2)) { out.push(s); break; }
      }
    }
    return out;
  }

  function brushPaintAt(clientX, clientY, tool) {
    brushCursor = { x: clientX, y: clientY };
    var hits = shapesUnderBrush(clientX, clientY), any = false;
    for (var i = 0; i < hits.length; i++) {
      applyToolTo(hits[i], tool).forEach(function(x) {
        recolorShape(x);
        strokeShapes.push(x);
        any = true;
      });
    }
    drawHoverOutline();
    if (any) {
      paintPending = true;
      queueFrame();
    }
  }

  var lastPaintCounty = null;
  function paintShapeAt(clientX, clientY) {
    if (brushActive()) { brushPaintAt(clientX, clientY, strokeTool); return; }
    var s = pickAt(clientX, clientY, true);
    if (!s || s === lastPaintShape) return;
    lastPaintShape = s;
    setHoverShape(s);
    showDetail(s);
    if (paintBy === 'county') {
      if (s.county === lastPaintCounty) return;
      lastPaintCounty = s.county;
    }
    applyToolTo(s, strokeTool).forEach(function(x) {
      recolorShape(x);
      strokeShapes.push(x);
    });
    paintPending = true;
    queueFrame();
  }

  var lastPaintX = 0, lastPaintY = 0;
  function paintAlong(x, y) {
    var dx = x - lastPaintX, dy = y - lastPaintY;
    var stepPx = brushActive() ? Math.max(4, brushRadius / 3) : 4;
    var steps = Math.max(1, Math.ceil(Math.sqrt(dx * dx + dy * dy) / stepPx));
    for (var i = 1; i <= steps; i++) paintShapeAt(lastPaintX + dx * i / steps, lastPaintY + dy * i / steps);
    lastPaintX = x;
    lastPaintY = y;
  }

  function endPaint() {
    if (!isPainting) return;
    isPainting = false;
    lastPaintShape = null;
    try { canvas.releasePointerCapture(activePointer); } catch (err) {}
    activePointer = null;
    if (strokeShapes.length) {
      hasUnsavedChanges = true;
      recomputeDistricts();
    }
    strokeShapes = [];
  }

  canvas.addEventListener('pointerdown', function(e) {
    if (e.button !== undefined && e.button !== 0) return;
    var canPaint = activeTool === 'paint' && activeDistrictId !== null && !districtLocked[activeDistrictId];
    var canBrush = brushActive() && (canPaint || activeTool === 'eraser');
    if (canBrush || (dragPaintCheckbox.checked && (canPaint || activeTool === 'eraser'))) {
      isPainting = true;
      strokeTool = activeTool;
      activePointer = e.pointerId;
      canvas.setPointerCapture(e.pointerId);
      strokeShapes = [];
      lastPaintShape = null;
      lastPaintCounty = null;
      lastPaintX = e.clientX;
      lastPaintY = e.clientY;
      paintShapeAt(e.clientX, e.clientY);
      return;
    }
    setHoverShape(null);
    isPanning = true;
    moved = 0;
    lastX = e.clientX;
    lastY = e.clientY;
    activePointer = e.pointerId;
    canvas.setPointerCapture(e.pointerId);
    canvas.classList.add('panning');
  });

  canvas.addEventListener('pointermove', function(e) {
    if (isPainting) {
      if (e.pointerId === activePointer) paintAlong(e.clientX, e.clientY);
      return;
    }
    if (isPanning && e.pointerId === activePointer) {
      markBasemapBusy();
      var dxClient = e.clientX - lastX;
      var dyClient = e.clientY - lastY;
      moved += Math.abs(dxClient) + Math.abs(dyClient);
      lastX = e.clientX;
      lastY = e.clientY;
      panDX += dxClient;
      panDY += dyClient;
      panPending = true;
      queueFrame();
    } else if (brushActive()) {
      brushCursor = { x: e.clientX, y: e.clientY };
      drawHoverOutline();
    } else {
      var wantOutline = activeTool !== 'cursor';
      var s = pickAt(e.clientX, e.clientY, wantOutline);
      if (s) showDetail(s);
      setHoverShape(wantOutline ? s : null);
    }
  });
  canvas.addEventListener('pointerleave', function() {
    if (isPainting) return;
    if (brushActive()) { brushCursor = null; drawHoverOutline(); return; }
    setHoverShape(null);
  });

  function endPan(e) {
    if (!isPanning) return;
    isPanning = false;
    canvas.classList.remove('panning');
    if (moved < 4) {
      var s = pickAt(e.clientX, e.clientY);
      if (s) {
        showDetail(s);
        var canPaintClick = activeTool === 'paint' && activeDistrictId !== null && !districtLocked[activeDistrictId];
        if (canPaintClick || activeTool === 'eraser') {
          if (applyToolTo(s, activeTool).length) {
            hasUnsavedChanges = true;
            recomputeDistricts();
          }
        }
      }
    }
    try { canvas.releasePointerCapture(activePointer); } catch (err) {}
    activePointer = null;
  }

  canvas.addEventListener('pointerup', function(e) { endPaint(); endPan(e); });
  canvas.addEventListener('pointercancel', function(e) { endPaint(); endPan(e); });

  var countyAggCache = {};
  function countyAggregate(county) {
    if (countyAggCache[county]) return countyAggCache[county];
    var a = { dem: 0, rep: 0, other: 0, pop: 0, pop20: 0, pop10: 0, pop00: 0, totreg: 0, margin: null, count: 0 };
    for (var q = 0; q < ETH_GROUPS.length; q++) a[ETH_GROUPS[q].key] = 0;
    EDU_KEYS.forEach(function(k) { a[k] = 0; });
    AGE_KEYS.forEach(function(k) { a[k] = 0; });
    ORIGIN_KEYS.forEach(function(k) { a[k] = 0; });
    LANG_KEYS.forEach(function(k) { a[k] = 0; });
    INC_KEYS.forEach(function(k) { a[k] = 0; });
    POP_MORE_KEYS.forEach(function(k) { a[k] = 0; });
    SHIFT_KEYS.forEach(function(k) { a[k] = 0; });
    for (var i = 0; i < shapes.length; i++) {
      var x = shapes[i];
      if (x.county !== county) continue;
      for (var sh = 0; sh < SHIFT_KEYS.length; sh++) a[SHIFT_KEYS[sh]] += x[SHIFT_KEYS[sh]];
      a.dem += x.dem;
      a.rep += x.rep;
      a.other += x.other;
      a.pop += x.pop;
      a.pop20 += x.pop20;
      a.pop10 += x.pop10;
      a.pop00 += x.pop00;
      a.totreg += x.totreg || 0;
      for (var e = 0; e < ETH_GROUPS.length; e++) a[ETH_GROUPS[e].key] += x[ETH_GROUPS[e].key];
      for (var ed = 0; ed < EDU_KEYS.length; ed++) a[EDU_KEYS[ed]] += x[EDU_KEYS[ed]];
      for (var ag = 0; ag < AGE_KEYS.length; ag++) a[AGE_KEYS[ag]] += x[AGE_KEYS[ag]];
      for (var og = 0; og < ORIGIN_KEYS.length; og++) a[ORIGIN_KEYS[og]] += x[ORIGIN_KEYS[og]];
      for (var lk = 0; lk < LANG_KEYS.length; lk++) a[LANG_KEYS[lk]] += x[LANG_KEYS[lk]];
      for (var id = 0; id < INC_KEYS.length; id++) a[INC_KEYS[id]] += x[INC_KEYS[id]];
      for (var vd = 0; vd < POP_MORE_KEYS.length; vd++) a[POP_MORE_KEYS[vd]] += x[POP_MORE_KEYS[vd]];
      a.count++;
    }
    setMargin(a);
    setIncomeMedian(a);
    countyAggCache[county] = a;
    return a;
  }

  var detailShape = null;
  var hoverDistrictMode = false;
  var shownInfoDistrictId = null;
  function infoDistrictId() {
    if (hoverDistrictMode && detailShape && detailShape.districtId !== null) return detailShape.districtId;
    return activeDistrictId;
  }
  var detailHeading = document.getElementById('detail-heading');
  function updateDetailHeading() {
    detailHeading.textContent = paintBy === 'county' ? 'County' : fillGeoTemplate('{Unit}');
  }
  function showDetail(shape) {
    var byCounty = paintBy === 'county';
    updateDetailHeading();
    var s = byCounty ? countyAggregate(shape.county) : shape;
    var totalAll = s.dem + s.rep + s.other;
    placeholder.hidden = true;
    detail.hidden = false;
    elPrecinct.textContent = byCounty ? shape.county + ' County' : shape.precinct;
    elCounty.textContent = byCounty ? s.count.toLocaleString() + ' ' + geoUnit(true) : shape.county + ' County';
    var shownDistrict = shape.districtId;
    if (byCounty && shownDistrict !== null) {
      var cList = shapesByCounty[shape.county] || [shape];
      for (var ci = 0; ci < cList.length; ci++) if (cList[ci].districtId !== shownDistrict) { shownDistrict = null; break; }
    }
    var elDistrictLine = document.getElementById('d-district');
    elDistrictLine.hidden = shownDistrict === null;
    elDistrictLine.textContent = shownDistrict === null ? '' : districtLabel(shownDistrict);
    elCounty.style.marginBottom = shownDistrict === null ? '' : '0';
    elDem.textContent = s.dem.toLocaleString();
    elRep.textContent = s.rep.toLocaleString();
    elOther.textContent = s.other.toLocaleString();
    if (totalAll > 0) {
      elDemPct.textContent = '(' + (s.dem / totalAll * 100).toFixed(1) + '%)';
      elRepPct.textContent = '(' + (s.rep / totalAll * 100).toFixed(1) + '%)';
      elOtherPct.textContent = '(' + (s.other / totalAll * 100).toFixed(1) + '%)';
    } else {
      elDemPct.textContent = '';
      elRepPct.textContent = '';
      elOtherPct.textContent = '';
    }
    if (s.margin === null) {
      elMargin.textContent = 'no data';
    } else {
      var who = leaderName(s, activeRace);
      elMargin.textContent = who + ' +' + Math.abs(s.margin * 100).toFixed(1) + ' pts';
    }
    var tv = turnoutOf(s);
    document.getElementById('d-turnout').textContent = tv === null ? 'no data' : (tv * 100).toFixed(1) + '%';
    updateShiftRows('d', s);
    detailShape = shape;
    if (hoverDistrictMode && infoDistrictId() !== shownInfoDistrictId) updateDistrictInfo();
    fillPopRow('d', s, currentState.geo === 'blockgroup');
    fitName(elDemName);
    fitName(elRepName);
  }

  var settingsPanel = document.getElementById('settings-panel');
  var backdrop = document.getElementById('backdrop');
  var navButtons = {
    'map-settings': document.getElementById('nav-map-settings'),
    'overlays': document.getElementById('nav-overlays'),
    'sources': document.getElementById('nav-sources'),
  };
  var panelSections = {
    'map-settings': document.getElementById('panel-map-settings'),
    'overlays': document.getElementById('panel-overlays'),
    'sources': document.getElementById('panel-sources'),
  };
  var activePanel = null;

  function showPanel(key) {
    Object.keys(navButtons).forEach(function(k) {
      navButtons[k].classList.toggle('active', k === key);
      panelSections[k].hidden = k !== key;
    });
    settingsPanel.classList.add('open');
    activePanel = key;
  }
  function closePanel() {
    settingsPanel.classList.remove('open');
    Object.keys(navButtons).forEach(function(k) { navButtons[k].classList.remove('active'); });
    backdrop.classList.remove('open');
    activePanel = null;
  }
  Object.keys(navButtons).forEach(function(key) {
    navButtons[key].addEventListener('click', function() {
      if (activePanel === key) closePanel(); else showPanel(key);
    });
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && activePanel !== null && !e.target.matches('input[type="text"], input[type="number"]')) closePanel();
  });

  var slider = document.getElementById('border-slider');
  var valueLabel = document.getElementById('border-value');
  slider.addEventListener('input', function() {
    borderBase = parseFloat(slider.value);
    valueLabel.textContent = borderBase.toFixed(2) + 'px';
    draw();
  });

  function setupColorSetting(pickerId, hexId, onChange) {
    var picker = document.getElementById(pickerId), hex = document.getElementById(hexId);
    picker.addEventListener('input', function() {
      hex.value = picker.value;
      hex.classList.remove('input-error');
      onChange(picker.value);
    });
    hex.addEventListener('input', function() {
      var v = hex.value.trim();
      if (v.charAt(0) !== '#') v = '#' + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) {
        v = v.toLowerCase();
        picker.value = v;
        hex.classList.remove('input-error');
        onChange(v);
      } else {
        hex.classList.add('input-error');
      }
    });
    hex.addEventListener('blur', function() {
      hex.value = picker.value;
      hex.classList.remove('input-error');
    });
  }
  setupColorSetting('border-color', 'border-color-hex', function(c) { borderColor = c; draw(); });
  setupColorSetting('district-border-color', 'district-border-color-hex', function(c) { districtBorderColor = c; draw(); });
  setupColorSetting('county-border-color', 'county-border-color-hex', function(c) { countyBorderColor = c; draw(); });

  setupColorSetting('overlay-color', 'overlay-color-hex', function(c) { overlayColor = c; draw(); });
  var overlayWidthSlider = document.getElementById('overlay-width-slider');
  var overlayWidthValue = document.getElementById('overlay-width-value');
  overlayWidthSlider.addEventListener('input', function() {
    overlayWidth = parseFloat(overlayWidthSlider.value);
    overlayWidthValue.textContent = overlayWidth.toFixed(2) + 'px';
    draw();
  });

  var countyBorderSlider = document.getElementById('county-border-slider');
  var countyBorderValueLabel = document.getElementById('county-border-value');
  countyBorderSlider.addEventListener('input', function() {
    countyBorderBase = parseFloat(countyBorderSlider.value);
    countyBorderValueLabel.textContent = countyBorderBase.toFixed(2) + 'px';
    draw();
  });

  var districtBorderSlider = document.getElementById('district-border-slider');
  var districtBorderValueLabel = document.getElementById('district-border-value');
  districtBorderSlider.addEventListener('input', function() {
    districtBorderBase = parseFloat(districtBorderSlider.value);
    districtBorderValueLabel.textContent = districtBorderBase.toFixed(2) + 'px';
    draw();
  });

  var showDistrictLabelsCheckbox = document.getElementById('show-district-labels');
  showDistrictLabelsCheckbox.addEventListener('change', function() {
    showDistrictLabels = showDistrictLabelsCheckbox.checked;
    draw();
  });

  var showUnitsInDistrictCheckbox = document.getElementById('show-units-in-district');
  showUnitsInDistrictCheckbox.addEventListener('change', function() {
    showUnitsInDistrict = showUnitsInDistrictCheckbox.checked;
    refreshHighlight();
  });

  var paintBy = 'unit';
  var paintByButtons = { unit: document.getElementById('paintby-unit'), county: document.getElementById('paintby-county') };
  Object.keys(paintByButtons).forEach(function(k) {
    paintByButtons[k].addEventListener('click', function() {
      paintBy = k;
      drawHoverOutline();
      Object.keys(paintByButtons).forEach(function(o) { paintByButtons[o].classList.toggle('active', o === k); });
      if (k === 'county' && !showCountyBordersCheckbox.checked) {
        showCountyBordersCheckbox.checked = true;
        showCountyBorders = true;
        draw();
      }
      updateDetailHeading();
      if (detailShape) showDetail(detailShape);
    });
  });

  function refreshHighlight() {
    for (var i = 0; i < shapes.length; i++) recolorShape(shapes[i]);
    draw();
  }
  var showBasemapCheckbox = document.getElementById('show-basemap');
  showBasemapCheckbox.addEventListener('change', function() {
    basemapOn = showBasemapCheckbox.checked;
    document.getElementById('basemap-attribution').hidden = !basemapOn;
    updateBasemapHint();
    draw();
  });
  var showPlaceNamesCheckbox = document.getElementById('show-place-names');
  showPlaceNamesCheckbox.addEventListener('change', function() {
    placeLabelsOn = showPlaceNamesCheckbox.checked;
    draw();
  });
  var placeNamesFrontCheckbox = document.getElementById('place-names-front');
  placeNamesFrontCheckbox.addEventListener('change', function() {
    placeLabelsBehind = !placeNamesFrontCheckbox.checked;
    draw();
  });
  var shapeOpacitySlider = document.getElementById('shape-opacity');
  shapeOpacitySlider.addEventListener('input', function() {
    shapeAlpha = parseFloat(shapeOpacitySlider.value);
    document.getElementById('shape-opacity-value').textContent = Math.round(shapeAlpha * 100) + '%';
    draw();
  });
  updateBasemapHint();

  var hoverDistrictCheckbox = document.getElementById('hover-district');
  hoverDistrictCheckbox.addEventListener('change', function() {
    hoverDistrictMode = hoverDistrictCheckbox.checked;
    updateDistrictInfo();
  });
  var highlightDistrictCheckbox = document.getElementById('highlight-district');
  highlightDistrictCheckbox.addEventListener('change', function() {
    highlightDistrict = highlightDistrictCheckbox.checked;
    refreshHighlight();
  });

  var showCountyBordersCheckbox = document.getElementById('show-county-borders');
  showCountyBordersCheckbox.addEventListener('change', function() {
    showCountyBorders = showCountyBordersCheckbox.checked;
    draw();
  });

  /* ---- Boundary overlay: draw the borders from an uploaded GeoJSON file on top of the map. View only. ---- */
  var overlayUploadBtn = document.getElementById('overlay-upload');
  var overlayClearBtn = document.getElementById('overlay-clear');
  var overlayFileInput = document.getElementById('overlay-file');
  var overlayNameEl = document.getElementById('overlay-name');

  function overlayCollect(g, out) {
    if (!g || typeof g !== 'object') return;
    var i;
    switch (g.type) {
      case 'FeatureCollection': for (i = 0; i < (g.features || []).length; i++) overlayCollect(g.features[i], out); break;
      case 'Feature': overlayCollect(g.geometry, out); break;
      case 'GeometryCollection': for (i = 0; i < (g.geometries || []).length; i++) overlayCollect(g.geometries[i], out); break;
      case 'Polygon': for (i = 0; i < g.coordinates.length; i++) out.push(g.coordinates[i]); break;
      case 'MultiPolygon': g.coordinates.forEach(function(poly) { poly.forEach(function(r) { out.push(r); }); }); break;
      case 'LineString': out.push(g.coordinates); break;
      case 'MultiLineString': g.coordinates.forEach(function(l) { out.push(l); }); break;
    }
  }
  // Files from state/federal GIS portals are often not in longitude/latitude. Convert the common ones:
  // EPSG:3310 (California Albers, meters), EPSG:3857 (web Mercator) and plain WGS 84.
  function makeAlbersInverse(lat1d, lat2d, lat0d, lon0d, fe, fn) {
    var D = Math.PI / 180, a = 6378137, e2 = 0.00669438002290, e = Math.sqrt(e2);
    function q(phi) { var sn = Math.sin(phi); return (1 - e2) * (sn / (1 - e2 * sn * sn) - Math.log((1 - e * sn) / (1 + e * sn)) / (2 * e)); }
    function m(phi) { var sn = Math.sin(phi); return Math.cos(phi) / Math.sqrt(1 - e2 * sn * sn); }
    var m1 = m(lat1d * D), m2 = m(lat2d * D), q0 = q(lat0d * D), q1 = q(lat1d * D), q2 = q(lat2d * D);
    var n = (m1 * m1 - m2 * m2) / (q2 - q1), C = m1 * m1 + n * q1, rho0 = a * Math.sqrt(C - n * q0) / n;
    return function(X, Y) {
      var x = X - fe, y = Y - fn, dy = rho0 - y, rho = Math.sqrt(x * x + dy * dy);
      var qq = (C - (rho * n / a) * (rho * n / a)) / n;
      var th = Math.atan2(x, dy), phi = Math.asin(Math.max(-1, Math.min(1, qq / 2)));
      for (var i = 0; i < 8; i++) {
        var sn = Math.sin(phi), cs = Math.cos(phi), w = 1 - e2 * sn * sn;
        var dphi = w * w / (2 * cs) * (qq / (1 - e2) - sn / w + Math.log((1 - e * sn) / (1 + e * sn)) / (2 * e));
        phi += dphi;
        if (Math.abs(dphi) < 1e-11) break;
      }
      return [lon0d + th / n / D, phi / D];
    };
  }
  function overlayConverterFor(doc) {
    var crs = doc && doc.crs && doc.crs.properties && doc.crs.properties.name;
    crs = typeof crs === 'string' ? crs : '';
    if (/3310/.test(crs)) return makeAlbersInverse(34, 40.5, 0, -120, 0, -4000000);
    if (/3857|900913/.test(crs)) return function(X, Y) { var R = 6378137; return [X / R * 180 / Math.PI, Math.atan(Math.sinh(Y / R)) * 180 / Math.PI]; };
    return null;
  }
  function overlayBuildPath() {
    overlayPath = null;
    if (!overlayLines || !geoProj) return;
    // Three detail levels like the district outlines: big files are drawn thinned out when zoomed out.
    var paths = [new Path2D(), new Path2D(), new Path2D()];
    overlayLines.forEach(function(line) {
      var pts = line.map(function(ll) { return geoProj.fwd(ll[0], ll[1]); });
      for (var l = 0; l < 3; l++) {
        var e2 = LOD_EPS[l] * LOD_EPS[l], lx = pts[0][0], ly = pts[0][1];
        paths[l].moveTo(lx, ly);
        for (var i = 1; i < pts.length; i++) {
          var dx = pts[i][0] - lx, dy = pts[i][1] - ly;
          if (i === pts.length - 1 || dx * dx + dy * dy >= e2) { paths[l].lineTo(pts[i][0], pts[i][1]); lx = pts[i][0]; ly = pts[i][1]; }
        }
      }
    });
    overlayPath = paths;
  }
  function overlayClear() {
    overlayLines = null;
    overlayPath = null;
    overlayLabel = '';
    overlayNameEl.textContent = '';
    overlayClearBtn.style.display = 'none';
    overlayUploadBtn.textContent = 'Upload';
    draw();
  }
  function overlayLoadFile(file) {
    var reader = new FileReader();
    reader.onload = function() {
      var doc;
      try { doc = JSON.parse(reader.result); } catch (err) { doc = null; }
      if (!doc) { alert('That file is not valid GeoJSON.'); return; }
      var lines = [];
      try { overlayCollect(doc, lines); } catch (err) { lines = []; }
      lines = lines.filter(function(l) { return Array.isArray(l) && l.length > 1 && l.every(function(pt) { return Array.isArray(pt) && isFinite(pt[0]) && isFinite(pt[1]); }); });
      if (!lines.length) { alert('That file has no polygon or line boundaries to show.'); return; }
      var convert = overlayConverterFor(doc);
      if (convert) lines = lines.map(function(l) { return l.map(function(pt) { return convert(pt[0], pt[1]); }); });
      var inRange = lines.every(function(l) { return l.every(function(pt) { return Math.abs(pt[0]) <= 180 && Math.abs(pt[1]) <= 90; }); });
      if (!inRange) { alert('That file does not use longitude/latitude coordinates (WGS 84) or a coordinate system Civitas can convert (California Albers EPSG:3310 or Web Mercator EPSG:3857), so it cannot be placed on the map. Re-export it as standard GeoJSON.'); return; }
      overlayLines = lines;
      overlayLabel = file.name;
      loadGeometry().then(function() {
        overlayBuildPath();
        if (!overlayPath) { alert('The map is not ready for an overlay yet. Try again in a moment.'); overlayLines = null; return; }
        overlayNameEl.textContent = file.name + ' (' + lines.length.toLocaleString() + ' boundaries)';
        overlayClearBtn.style.display = '';
        overlayUploadBtn.textContent = 'Replace';
        draw();
      });
    };
    reader.readAsText(file);
  }
  overlayUploadBtn.addEventListener('click', function() { overlayFileInput.click(); });
  overlayClearBtn.addEventListener('click', overlayClear);
  overlayFileInput.addEventListener('change', function() {
    if (overlayFileInput.files && overlayFileInput.files[0]) overlayLoadFile(overlayFileInput.files[0]);
    overlayFileInput.value = '';
  });

  var legendTitle = document.getElementById('legend-title');

  function setupSidebarToggle(sidebarId, buttonId, cssVar, expandedWidth, collapsedWidth, openGlyph, closedGlyph) {
    var panel = document.getElementById(sidebarId);
    var btn = document.getElementById(buttonId);
    var collapsed = false;
    btn.textContent = openGlyph;
    btn.addEventListener('click', function() {
      collapsed = !collapsed;
      panel.classList.toggle('collapsed', collapsed);
      document.documentElement.style.setProperty(cssVar, collapsed ? collapsedWidth : (typeof expandedWidth === 'function' ? expandedWidth() : expandedWidth));
      btn.textContent = collapsed ? closedGlyph : openGlyph;
    });
  }
  // The left panel is 310px by default but widens to fit its widest district row (long names, big deviation
  // numbers), so the population figures are never clipped.
  var DISTRICT_SIDEBAR_MIN_W = 310;
  var DISTRICT_SIDEBAR_MAX_W = 560;
  var districtSidebarW = DISTRICT_SIDEBAR_MIN_W;
  function fitDistrictSidebar() {
    var panel = document.getElementById('district-sidebar');
    var rows = districtList.children;
    var widest = 0;
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var rs = getComputedStyle(row);
      var gap = parseFloat(rs.columnGap) || 0;
      var w = parseFloat(rs.paddingLeft) + parseFloat(rs.paddingRight) + parseFloat(rs.borderLeftWidth) + parseFloat(rs.borderRightWidth);
      for (var c = 0; c < row.children.length; c++) {
        var ch = row.children[c];
        var cs = getComputedStyle(ch);
        var natural = ch.classList.contains('district-name') ? ch.scrollWidth : (ch.tagName === 'INPUT' ? Math.max(ch.offsetWidth, 150) : ch.offsetWidth);
        w += natural + (parseFloat(cs.marginLeft) || 0) + (parseFloat(cs.marginRight) || 0);
      }
      w += gap * Math.max(0, row.children.length - 1);
      if (w > widest) widest = w;
    }
    var chrome = 17;
    for (var el = districtList; el && el !== panel.parentNode; el = el.parentNode) {
      var s = getComputedStyle(el);
      chrome += (parseFloat(s.paddingLeft) || 0) + (parseFloat(s.paddingRight) || 0) + (parseFloat(s.borderLeftWidth) || 0) + (parseFloat(s.borderRightWidth) || 0);
      if (el !== districtList) chrome += (parseFloat(s.marginLeft) || 0) + (parseFloat(s.marginRight) || 0);
    }
    // Only ever widen (never shrink back) while a map is open, so the panel doesn't jump left and right with every
    // edit as the numbers change. It resets to the minimum when a different map is loaded.
    districtSidebarW = Math.max(districtSidebarW, DISTRICT_SIDEBAR_MIN_W, Math.min(DISTRICT_SIDEBAR_MAX_W, Math.ceil(widest + chrome)));
    if (!panel.classList.contains('collapsed')) {
      document.documentElement.style.setProperty('--district-sidebar-w', districtSidebarW + 'px');
      // The estimate above can come out short (fonts that load after the first render, scrollbars). So measure
      // what is really clipped now and widen by exactly that, so no district name is ever cut off.
      for (var pass = 0; pass < 3 && districtSidebarW < DISTRICT_SIDEBAR_MAX_W; pass++) {
        var deficit = 0;
        var names = districtList.querySelectorAll('.district-name');
        for (var n = 0; n < names.length; n++) deficit = Math.max(deficit, names[n].scrollWidth - names[n].clientWidth);
        if (deficit < 1) break;
        districtSidebarW = Math.min(DISTRICT_SIDEBAR_MAX_W, districtSidebarW + Math.ceil(deficit) + 2);
        document.documentElement.style.setProperty('--district-sidebar-w', districtSidebarW + 'px');
      }
    }
  }
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function() { fitDistrictSidebar(); });
  setupSidebarToggle('district-sidebar', 'toggle-district-sidebar', '--district-sidebar-w', function() { return districtSidebarW + 'px'; }, '0px', '<', '>');
  setupSidebarToggle('detail-sidebar', 'toggle-detail-sidebar', '--right-sidebar-w', '270px', '0px', '>', '<');

  var layerPanels = {
    elections: { panel: document.getElementById('race-sidebar'), btn: document.getElementById('layer-elections') },
    demographics: { panel: document.getElementById('demo-sidebar'), btn: document.getElementById('layer-demographics') },
  };
  var openLayerPanel = null;
  function toggleLayerPanel(which) {
    openLayerPanel = openLayerPanel === which ? null : which;
    Object.keys(layerPanels).forEach(function(k) {
      var open = k === openLayerPanel;
      layerPanels[k].panel.classList.toggle('collapsed', !open);
      layerPanels[k].btn.classList.toggle('active', open);
    });
  }
  Object.keys(layerPanels).forEach(function(k) {
    layerPanels[k].btn.addEventListener('click', function() { toggleLayerPanel(k); });
  });

  var demoButtons = {};
  var demoValueEls = {};
  var demoList = document.getElementById('demo-list');
  function addDemoButtons(layers, parent) {
    layers.forEach(function(L) {
      var b = document.createElement('button');
      b.className = 'race-box';
      b.type = 'button';
      var lbl = document.createElement('span');
      lbl.className = 'race-label';
      lbl.textContent = L.label;
      b.title = L.label;
      b.appendChild(lbl);
      var v = document.createElement('span');
      v.className = 'race-margin';
      b.appendChild(v);
      b.addEventListener('click', function() {
        if (layerMode === 'population' && popKey === L.key) return;
        popKey = L.key;
        setLayerMode('population');
      });
      demoButtons[L.key] = b;
      demoValueEls[L.key] = v;
      (parent || demoList).appendChild(b);
    });
  }
  addDemoButtons(POP_LAYERS);
  addDemoSection(POP_MORE_LAYERS, 0, 'More population categories');
  var ethHeading = document.createElement('div');
  ethHeading.className = 'race-year-label';
  ethHeading.textContent = 'Ethnicity (ACS 2024)';
  demoList.appendChild(ethHeading);
  addDemoButtons(ETH_LAYERS);
  var eduHeading = document.createElement('div');
  eduHeading.className = 'race-year-label';
  eduHeading.textContent = 'Education (ACS 2024)';
  demoList.appendChild(eduHeading);
  function addDemoSection(layers, shown, moreText) {
    addDemoButtons(layers.slice(0, shown));
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'edu-more-btn';
    var list = document.createElement('div');
    list.hidden = true;
    function sync() { btn.textContent = (list.hidden ? '▸ ' : '▾ ') + moreText; }
    btn.addEventListener('click', function() { list.hidden = !list.hidden; sync(); });
    sync();
    demoList.appendChild(btn);
    demoList.appendChild(list);
    addDemoButtons(layers.slice(shown), list);
  }
  addDemoSection(EDU_LAYERS, 2, 'More education categories');
  var incHeading = document.createElement('div');
  incHeading.className = 'race-year-label';
  incHeading.textContent = 'Income (ACS 2024)';
  demoList.appendChild(incHeading);
  addDemoSection(INC_LAYERS, 4, 'More income categories');
  var ageHeading = document.createElement('div');
  ageHeading.className = 'race-year-label';
  ageHeading.textContent = 'Age (ACS 2024)';
  demoList.appendChild(ageHeading);
  addDemoButtons(AGE_LAYERS);
  var originHeading = document.createElement('div');
  originHeading.className = 'race-year-label';
  originHeading.textContent = 'Place of Origin (ACS 2024)';
  demoList.appendChild(originHeading);
  addDemoButtons(ORIGIN_LAYERS);
  var engHeading = document.createElement('div');
  engHeading.className = 'race-year-label';
  engHeading.textContent = 'English Proficiency (ACS 2024)';
  demoList.appendChild(engHeading);
  addDemoButtons(ENG_LAYERS);
  var langHeading = document.createElement('div');
  langHeading.className = 'race-year-label';
  langHeading.textContent = 'Language at Home (ACS 2024)';
  demoList.appendChild(langHeading);
  addDemoButtons(LANG_LAYERS);
  var legendCat = document.getElementById('legend-cat');
  ETH_GROUPS.forEach(function(g) {
    var row = document.createElement('div');
    row.className = 'legend-cat-row';
    var lab = document.createElement('span');
    lab.className = 'legend-cat-label';
    lab.textContent = g.label;
    var sw = document.createElement('span');
    sw.className = 'legend-cat-swatch';
    sw.style.background = 'linear-gradient(to right, ' + shadeStops(g.color).join(', ') + ')';
    row.appendChild(lab);
    row.appendChild(sw);
    legendCat.appendChild(row);
  });
  var legendCatEnds = document.createElement('div');
  legendCatEnds.className = 'legend-ticks';
  legendCatEnds.style.marginLeft = '66px';
  legendCatEnds.innerHTML = '<span>&lt;30%</span><span>100%</span>';
  legendCat.appendChild(legendCatEnds);
  function updateDemoBubbles() {
    var infoId = infoDistrictId();
    var src = (infoId !== null && districtStats[infoId]) ? districtStats[infoId] : mapTotals;
    POP_LAYERS.concat(POP_MORE_LAYERS, ETH_LAYERS, AGE_LAYERS, ORIGIN_LAYERS, ENG_LAYERS, LANG_LAYERS, EDU_LAYERS, INC_LAYERS).forEach(function(L) {
      demoValueEls[L.key].textContent = layerText(src, L);
    });
  }
  var legendElection = document.getElementById('legend-election');
  var legendPop = document.getElementById('legend-pop');
  function syncLayerUI() {
    var pop = layerMode === 'population';
    Object.keys(demoButtons).forEach(function(k) { demoButtons[k].classList.toggle('active', pop && k === popKey); });
    legendElection.hidden = pop;
    legendPop.hidden = !pop;
    var shiftView = !pop && shiftActive();
    var turnoutView = !pop && electionView === 'turnout';
    ['d', 'di'].forEach(function(i) {
      document.getElementById(i + '-turnout-row').hidden = !turnoutView || shiftView;
      document.getElementById(i + '-margin-row').hidden = turnoutView || shiftView;
    });
    document.getElementById('legend-turnout').hidden = !turnoutView || shiftView;
    document.getElementById('legend-margin').hidden = turnoutView || shiftView;
    document.getElementById('legend-shift').hidden = !shiftView;
    if (shiftView) renderShiftLegend();
    document.getElementById('election-view-margin').classList.toggle('active', electionView === 'margin');
    document.getElementById('election-view-turnout').classList.toggle('active', electionView === 'turnout');
    if (activeRace) legendTitle.textContent = turnoutView ? activeRace.legend.replace(/margin$/, 'turnout') : activeRace.legend;
    if (shiftView) legendTitle.textContent = shiftTitle();
    Array.prototype.forEach.call(document.querySelectorAll('.legend-bar-pop'), function(b) { b.style.background = schemeGradientCss(); });
    updateRaceButtons();
    if (turnoutView) {
      document.getElementById('legend-turnout-lo').textContent = '0%';
      document.getElementById('legend-turnout-mid').textContent = '50%';
      document.getElementById('legend-turnout-hi').textContent = '100%';
    }
    if (pop) {
      Array.prototype.forEach.call(document.querySelectorAll('#race-list .race-box'), function(b) { b.classList.remove('active'); });
      Array.prototype.forEach.call(document.querySelectorAll('.legend-bar-pop'), function(b) { b.style.background = schemeGradientCss(); });
      var L = popLayerFor(popKey);
      document.getElementById('legend-pop-title').textContent = (L.title ? L.title.charAt(0).toUpperCase() + L.title.slice(1) + ' (ACS 2024) \u00b7 ' : L.inc ? 'Household income (ACS 2024) \u00b7 ' : L.edu ? 'Education (ACS 2024) \u00b7 ' : L.age ? 'Age (ACS 2024) \u00b7 ' : L.origin ? 'Place of origin (ACS 2024) \u00b7 ' : L.pct || L.cat ? 'Ethnicity (ACS 2024) \u00b7 ' : 'Population \u00b7 ') + L.label;
      document.getElementById('legend-pop-bars').hidden = !!L.cat;
      document.getElementById('legend-cat').hidden = !L.cat;
      document.getElementById('legend-dpop-block').hidden = !!L.pct;
      document.getElementById('legend-pop-scale-label').textContent = L.median ? capFirst(geoUnit(false)) + ' median household income' : L.avg ? capFirst(geoUnit(false)) + ' average age' : L.inc ? 'Share of households (%)' : L.edu ? 'Share of adults 25+ (%)' : L.pop5 ? 'Share of population 5+ (%)' : L.pct ? 'Share of population (%)' : capFirst(geoUnit(false)) + ' population';
      document.getElementById('legend-dpop-scale-label').textContent = L.median ? 'District median household income' : L.avg ? 'District average age' : 'District population';
      if (L.pct) {
        ['legend-pop-', 'legend-dpop-'].forEach(function(pre) {
          document.getElementById(pre + 'lo').textContent = '0%';
          document.getElementById(pre + 'mid').textContent = '50%';
          document.getElementById(pre + 'hi').textContent = '100%';
        });
      } else {
        var dHas = districtPopScale.hi > 0;
        var tick = function(v) { return L.dollar ? '$' + Math.round(v / 1000) + 'K' : Math.round(v).toLocaleString(); };
        var dMid = districtPopScale.mid !== undefined ? districtPopScale.mid : (districtPopScale.lo + districtPopScale.hi) / 2;
        document.getElementById('legend-dpop-lo').textContent = dHas ? tick(districtPopScale.lo) : '';
        document.getElementById('legend-dpop-mid').textContent = dHas ? tick(dMid) : '';
        document.getElementById('legend-dpop-hi').textContent = dHas ? tick(districtPopScale.hi) : '';
        document.getElementById('legend-pop-lo').textContent = '≤' + tick(popScale.lo);
        document.getElementById('legend-pop-mid').textContent = tick((popScale.lo + popScale.hi) / 2);
        document.getElementById('legend-pop-hi').textContent = tick(popScale.hi) + '+';
      }
    }
  }
  function cardRace() {
    if (layerMode === 'election' && selectedRaceKey) return raceByKey(selectedRaceKey);
    return raceByKey('president-2024') || allRaces[0] || null;
  }
  function raceByKey(key) {
    for (var i = 0; i < allRaces.length; i++) if (allRaces[i].key === key) return allRaces[i];
    return null;
  }
  function syncCardRace() {
    var want = cardRace();
    if (want && (!activeRace || activeRace.key !== want.key)) loadRace(want);
  }
  function setLayerMode(mode) {
    layerMode = mode;
    if (mode === 'population') computePopScale();
    syncLayerUI();
    syncCardRace();
    recomputeDistricts();
  }
  ['margin', 'turnout'].forEach(function(v) {
    document.getElementById('election-view-' + v).addEventListener('click', function() {
      electionView = v;
      if (v === 'turnout') ensureRaceTurnouts();
      if (layerMode !== 'election') setLayerMode('election');
      else recomputeDistricts();
    });
  });
  var demoSchemeSelect = document.getElementById('demo-scheme');
  Object.keys(POP_SCHEMES).forEach(function(k) {
    var opt = document.createElement('option');
    opt.value = k;
    opt.textContent = POP_SCHEMES[k].label;
    demoSchemeSelect.appendChild(opt);
  });
  demoSchemeSelect.value = popSchemeKey;
  demoSchemeSelect.addEventListener('change', function() {
    popSchemeKey = demoSchemeSelect.value;
    syncLayerUI();
    recomputeDistricts();
  });

  var shapesIndex = null;
  var shapesByCounty = {};
  var mapTotalsCache = null;
  // Data-file fetches go through a small queue (MAX_CONCURRENT at a time) and retry on 429/5xx, so hosts
  // that rate-limit bursts of requests still serve the ~60 county files per layer.
  var MAX_CONCURRENT = IS_DESKTOP ? 16 : 4, activeFetches = 0, fetchWaiting = [];   // files are local in the desktop app

  // A dropped connection ("Failed to fetch", e.g. the host or a firewall cutting off a burst of large files) or a
  // response truncated mid-download (JSON parse error) is retried like a 429/5xx; real 4xx errors are not.
  // Data files carry the build id (?v=...), so the server can let browsers keep them for a long time: they are
  // downloaded once per rebuild, not on every visit.
  var BUILD_ID = '__BUILD_ID__';
  function versioned(url) { return url + (url.indexOf('?') < 0 ? '?v=' : '&v=') + BUILD_ID; }

  function fetchJSON(url) {
    return new Promise(function(resolve, reject) {
      var attempt = 0;
      function run() {
        activeFetches++;
        fetch(versioned(url)).then(function(r) {
          if (r.status === 429 || r.status >= 500) { var e = new Error('HTTP ' + r.status); e.retry = true; throw e; }
          if (!r.ok) throw new Error('HTTP ' + r.status + ' for ' + url);
          return r.json();
        }).then(function(j) { done(); resolve(j); }, function(err) {
          done();
          if (err instanceof TypeError || err instanceof SyntaxError) err.retry = true;
          if (err.retry && attempt < 8) { setTimeout(function() { fetchWaiting.push(run); pump(); }, 500 * Math.pow(1.7, attempt++)); }
          else {
            if (err instanceof TypeError) err.message = 'the connection was interrupted loading ' + url.split('/').slice(-2).join('/') + '. Please reload to try again';
            reject(err);
          }
        });
      }
      fetchWaiting.push(run);
      pump();
    });
  }

  function done() { activeFetches--; pump(); }

  function pump() {
    while (activeFetches < MAX_CONCURRENT && fetchWaiting.length) fetchWaiting.shift()();
  }

  var geometryReady = null;

  function loadGeometry() {
    if (geometryReady) return geometryReady;
    var geoDir = currentState.dataDir + 'geometry/';
    geometryReady = fetchJSON(geoDir + 'manifest.json')
      .then(function(manifest) {
        base = { x: 0, y: 0, w: manifest.width, h: manifest.height };
        geoProj = manifest.projection ? makeProjection(manifest.projection) : null;
        tileCache = {};
        tileQueue = [];
        basemapDrawn = [];
        updateBasemapHint();
        var vw = base.w / defaultScale, vh = base.h / defaultScale;
        view = { x: base.x - (vw - base.w) / 2, y: base.y - (vh - base.h) / 2, w: vw, h: vh };
        if (manifest.counties) {
          fetchJSON(geoDir + manifest.counties)
            .then(function(c) {
              countyBorderPath = new Path2D();
              countyRecordPaths = [];
              countyOutlineCache = {};
              c.records.forEach(function(rec) {
                var cp = new Path2D(rec.d);
                countyRecordPaths.push(cp);
                countyBorderPath.addPath(cp);
              });
              draw();
            })
            .catch(function() {});
        }
        return Promise.all(manifest.files.map(function(fname) {
          return fetchJSON(geoDir + fname);
        }));
      })
      .then(function(parts) {
        shapesIndex = {};
        for (var i = 0; i < parts.length; i++) {
          var recs = parts[i].records;
          for (var j = 0; j < recs.length; j++) {
            var g = recs[j];
            var b = g.bbox;
            var s = {
              paths: [null, null, null],
              rings: parseRings(g.d),
              fill: NODATA_FILL,
              precinct: g.precinct,
              county: g.county,
              dem: 0, rep: 0, other: 0, totreg: g.totreg, pop: g.pop || 0, pop20: g.pop20 || 0, pop10: g.pop10 || 0, pop00: g.pop00 || 0, eth_white: g.eth_white || 0, eth_black: g.eth_black || 0, eth_hisp: g.eth_hisp || 0, eth_asian: g.eth_asian || 0, eth_native: g.eth_native || 0, eth_pacific: g.eth_pacific || 0, edu_total: g.edu_total || 0, age_total: g.age_total || 0, lang_total: g.lang_total || 0, eng_vw: g.eng_vw || 0, eng_lvw: g.eng_lvw || 0, lang_english: g.lang_english || 0, lang_spanish: g.lang_spanish || 0, lang_indo: g.lang_indo || 0, lang_asian: g.lang_asian || 0, lang_other: g.lang_other || 0, orig_total: g.orig_total || 0, orig_instate: g.orig_instate || 0, orig_outstate: g.orig_outstate || 0, orig_foreign: g.orig_foreign || 0, cit_total: g.cit_total || 0, cit_yes: g.cit_yes || 0, age_sum: g.age_sum || 0, age_avg: g.age_total > 0 ? g.age_sum / g.age_total : 0, age_u18: g.age_u18 || 0, age_18_29: g.age_18_29 || 0, age_30_44: g.age_30_44 || 0, age_45_64: g.age_45_64 || 0, age_65: g.age_65 || 0, edu_coll: g.edu_coll || 0, edu_noncoll: g.edu_noncoll || 0, edu_lths: g.edu_lths || 0, edu_hs: g.edu_hs || 0, edu_somecol: g.edu_somecol || 0, edu_bach: g.edu_bach || 0, edu_grad: g.edu_grad || 0, inc_total: g.inc_total || 0, inc_lt50k: g.inc_lt50k || 0, inc_50_100k: g.inc_50_100k || 0, inc_gt100k: g.inc_gt100k || 0, inc_lt30k: g.inc_lt30k || 0, inc_30_50k: g.inc_30_50k || 0, inc_50_75k: g.inc_50_75k || 0, inc_75_100k: g.inc_75_100k || 0, inc_100_200k: g.inc_100_200k || 0, inc_gt200k: g.inc_gt200k || 0, inc_med: g.inc_med || 0, inc_medw: g.inc_med > 0 ? g.inc_med * (g.inc_total || 0) : 0, inc_medhh: g.inc_med > 0 ? (g.inc_total || 0) : 0, vap: g.vap || 0, vap20: g.vap20 || 0, vap22: g.vap22 || 0, cvap: g.cvap || 0,
              margin: null,
              districtId: null,
              bbox: b,
              bboxArea: (b[2] - b[0]) * (b[3] - b[1]),
            };
            for (var sk = 0; sk < SHIFT_KEYS.length; sk++) s[SHIFT_KEYS[sk]] = 0;
            shapes.push(s);
            shapesIndex[g.county + '|' + g.precinct] = s;
            (shapesByCounty[g.county] = shapesByCounty[g.county] || []).push(s);
          }
        }
        mapTotalsCache = null;
        markAllBordersDirty();
      });
    return geometryReady;
  }

  var raceDataCache = {};
  var raceReadyKeys = {};

  function fetchRaceRecords(race) {
    if (raceDataCache[race.key]) return raceDataCache[race.key];
    var raceDir = race.manifest.replace(/manifest\.json$/, '');
    var p = fetchJSON(race.manifest)
      .then(function(manifest) {
        return Promise.all(manifest.files.map(function(fname) {
          return fetchJSON(raceDir + fname);
        }));
      })
      .then(function(parts) {
        var records = [];
        for (var i = 0; i < parts.length; i++) records = records.concat(parts[i].records);
        return records;
      });
    raceDataCache[race.key] = p;
    p.then(function() { raceReadyKeys[race.key] = true; }).catch(function() {});
    return p;
  }

  function loadRace(race) {
    activeRace = race;
    applyRaceColors(race);
    loading.hidden = !!raceReadyKeys[race.key];
    loading.textContent = 'Loading ' + geoUnit(true) + '…';
    legendTitle.textContent = electionView === 'turnout' ? race.legend.replace(/margin$/, 'turnout') : race.legend;
    legendDemShort.textContent = race.demShort;
    legendRepShort.textContent = race.repShort;
    elDemName.textContent = race.demName;
    elRepName.textContent = race.repName;
    elOtherRow.hidden = !race.hasOther;
    placeholder.hidden = false;
    detail.hidden = true;

    loadGeometry().then(function() {
      return fetchRaceRecords(race);
    })
    .then(function(records) {
      var noDataCount = 0;
      var countyCounts = {};
      if (race.sparse) {
        for (var j = 0; j < shapes.length; j++) {
          shapes[j].dem = 0; shapes[j].rep = 0; shapes[j].other = 0; shapes[j].margin = null; shapes[j].lead = null;
        }
      }
      for (var i = 0; i < records.length; i++) {
        var r = records[i];
        var s = shapesIndex[r.county + '|' + r.precinct];
        if (!s) continue;
        s.dem = r.dem;
        s.rep = r.rep;
        s.other = r.other;
        setMargin(s);
        if (s.margin === null) noDataCount++;
        countyCounts[r.county] = (countyCounts[r.county] || 0) + 1;
      }
      countyAggCache = {};
      if (race.sparse) markEnclosedUnits();

      var counties = Object.keys(countyCounts).sort();

      var countyRows = counties.map(function(c) {
        return '<div class="sources-county-row"><span>' + c + '</span><span class="n">' +
          countyCounts[c].toLocaleString() + '</span></div>';
      }).join('');
      var isBG = currentState.geo === 'blockgroup';
      var lede = isBG
        ? 'Block Group boundaries are 2025 Census TIGER/Line. 2024 general election results are precinct results from the ' +
          '<a href="https://redistrictingdatahub.org" target="_blank" rel="noopener">Redistricting Data Hub</a>, ' +
          'compiled from the California Statewide Database (Madera County’s results were processed separately ' +
          'by RDH and merged in; retrieved December 2, 2025), then allocated to block groups. 2022 general election results are ' +
          'from the <a href="https://statewidedatabase.org" target="_blank" rel="noopener">California Statewide Database</a> ' +
          '(statement of vote by SR precinct, matched to its 2022 master-precinct map) and were allocated directly from the 2022 precincts ' +
          'to block groups by overlapping area. 2020, 2018 and 2016 general election results come from the same source and were allocated the same way.'
        : 'Precinct boundaries and 2024 general election results are from the ' +
          '<a href="https://redistrictingdatahub.org" target="_blank" rel="noopener">Redistricting Data Hub</a>, ' +
          'compiled from the California Statewide Database (Madera County’s results were processed separately ' +
          'by RDH and merged in). Retrieved December 2, 2025. 2022 general election results are from the ' +
          '<a href="https://statewidedatabase.org" target="_blank" rel="noopener">California Statewide Database</a> ' +
          '(statement of vote by SR precinct, matched to its 2022 master-precinct map) and were allocated to these 2024 precincts ' +
          'by overlapping area, so 2022 figures for individual precincts are estimates. 2020, 2018 and 2016 general election results come from the ' +
          'same source and were allocated the same way.';
      var geoCaveat = isBG
        ? '<li><strong>Block Group results are estimates.</strong> Precinct votes were allocated to block groups in ' +
          'proportion to overlapping area, assuming votes are spread evenly within each precinct. Totals are preserved, ' +
          'but individual block groups can be off, especially where a precinct is only partly populated.</li>'
        : '';
      var popNote = isBG
        ? '<li>Population: the latest ACS 5-year estimate (2020\u20132024, table B01003) is used for district totals; 2020 is the ' +
          'Decennial Census (PL 94-171). 2010 and 2000 Census (SF1) block counts were assigned to today\u2019s block groups by ' +
          'each block\u2019s internal point (marked est., since block-group boundaries changed). ACS values carry a margin of error. Ethnicity is ACS 5-year (2020–2024, table B03002): Hispanic or Latino of any race, plus non-Hispanic ' +
          'White, Black, Native (American Indian and Alaska Native) and Pacific (Native Hawaiian and Other Pacific Islander) alone, as a ' +
          'share of total population. Multiracial and other groups are not shown, so the shares do not sum to 100%. "Most Prevalent" colors each area by its largest of these six groups. ' +
          'Education is ACS 5-year (2020–2024, table B15003), as a share of the population 25 and over: College+ is anyone with at least a ' +
          'bachelor’s degree; Non-College is everyone else. The five attainment levels are Less than High School (no diploma), High School ' +
          '(diploma or GED), Some College (some college or an associate’s degree), Bachelor’s Degree and Graduate Degree+ (master’s, professional or doctorate). ' +
          'Voting age population (18+) for 2020 is the Decennial Census (PL 94-171, table P3); the ACS (2024) VAP is the ACS 5-year (2020–2024, table B01001) total minus those under 18, and citizen voting age population (CVAP) comes from the Census Bureau’s CVAP Special Tabulation of that same ACS. The 2020 Census did not ask about citizenship, so there is no Census CVAP. Median household income is the ACS 5-year median (table B19013) for each block group; for precincts, districts, counties and the whole map it is the household-weighted average of the block-group medians, an approximation rather than a true median. Income brackets are ACS 5-year (2020–2024, table B19001, household income), as a share of all households, shown in three brackets ' +
          '(under $50K, $50K–$100K, $100K+) or six (under $30K, $30K–$50K, $50K–$75K, $75K–$100K, $100K–$200K, $200K+).</li>'
        : '<li><strong>Precinct population is an estimate.</strong> Block-group population (2024 ACS 5-year, 2020, 2010 and 2000 Census) ' +
          'was allocated to precincts in proportion to overlapping area, assuming people are spread evenly within each block group. ' +
          'Statewide totals are preserved, but individual precincts can be off.</li>';
      var originNote = '<li>Place of origin (born in-state, out-of-state or abroad, ACS table B05002) and citizenship (table B05001) are only published down to Census tracts, so each ' +
        (isBG ? 'block group' : 'precinct') + ' gets the shares of the tract(s) it falls in. Citizen % is U.S.-born plus naturalized citizens, as a share of total population.</li>';
      var langNote = '<li>English proficiency and language at home are ACS 5-year table B16004 (population 5 and over). English Very Well + includes people who speak only English; ' +
        'Language at Home groups the language spoken at home as English only, Spanish, Other Indo-European, Asian / Pacific Island, or Other.</li>';
      var noSplit = isBG ? '' : '<li>No precinct is split across congressional, state senate, or state assembly districts in this dataset.</li>';
      document.getElementById('panel-sources').innerHTML =
        '<h3>Data sources</h3>' +
        '<p class="sources-lede">' + lede + '</p>' +
        '<p class="sources-coverage">' + race.blurb + '</p>' +
        '<p class="sources-coverage">' + counties.length + ' California counties, ' + records.length.toLocaleString() +
        ' ' + geoUnit(true) + ' total; ' + noDataCount.toLocaleString() + ' shown in grey on the map have no recorded ' +
        'two-party vote for this race.</p>' +
        '<ul class="sources-caveats">' +
        '<li>Some vote totals are suppressed by the source for low counts, so most county/statewide totals here run ' +
        'slightly under the official certified results.</li>' +
        geoCaveat +
        popNote +
        originNote +
        langNote +
        '<li>A small number of confidential or non-precinct rows were removed from the source shapefile before this map was built.</li>' +
        noSplit +
        '</ul>' +
        '<h3 style="margin-top:18px;">' + capFirst(geoUnit(true)) + ' by county</h3>' +
        '<div class="sources-columns">' + countyRows + '</div>';

      resizeCanvas();
      computeFit();
      recomputeDistricts();
      loading.hidden = true;
    })
    .catch(function(err) {
      loading.textContent = 'Could not load ' + geoUnit(false) + ' data: ' + err.message;
    });
  }

  var DISTRICTS_STORAGE_KEY = 'civitas-districts-v2';
  var districtCount = 0;
  var activeDistrictId = null;
  var districtColorMode = 'by-district';
  var districtStats = {};
  var districtNames = {};
  var districtLocked = {};
  var editingDistrictId = null;
  var activeTool = 'cursor';
  var hasUnsavedChanges = false;

  function districtLabel(k) {
    return districtNames[k] || ('District ' + k);
  }

  var districtCountInput = document.getElementById('district-count-input');
  var districtList = document.getElementById('district-list');
  var districtModeByDistrictBtn = document.getElementById('district-mode-by-district');
  var districtModeByLeanBtn = document.getElementById('district-mode-by-lean');
  var mapNameInput = document.getElementById('map-name-input');
  var saveMapBtn = document.getElementById('nav-save-map');

  var toolButtons = {
    cursor: document.getElementById('tool-cursor'),
    paint: document.getElementById('tool-paint'),
    eraser: document.getElementById('tool-eraser'),
  };
  var brushSizeRow = document.getElementById('brush-size-row');
  var brushSizeInput = document.getElementById('brush-size');
  var brushSizeValue = document.getElementById('brush-size-value');
  brushSizeInput.addEventListener('input', function() {
    brushRadius = parseInt(brushSizeInput.value, 10) || 0;
    brushSizeValue.textContent = brushRadius > 0 ? brushRadius : 'Single';
    if (!brushActive()) setHoverShape(null);
    drawHoverOutline();
  });
  var readonlyBanner = document.getElementById('readonly-banner');
  var readonlyText = document.getElementById('readonly-text');
  function flashReadOnly() {
    readonlyBanner.classList.add('flash');
    setTimeout(function() { readonlyBanner.classList.remove('flash'); }, 700);
  }
  function setReadOnly(flag, name) {
    mapReadOnly = !!flag;
    readonlyBanner.hidden = !mapReadOnly;
    if (mapReadOnly) readonlyText.textContent = 'You are viewing “' + (name || 'a shared map') + '”, a map owned by someone else. You can look around but not edit it.';
    mapNameInput.readOnly = mapReadOnly;
    if (mapReadOnly) {
      editingDistrictId = null;
      setActiveTool('cursor');
    }
  }
  function setActiveTool(tool) {
    if (mapReadOnly && tool !== 'cursor') { flashReadOnly(); return; }
    activeTool = tool;
    Object.keys(toolButtons).forEach(function(t) { toolButtons[t].classList.toggle('active', t === tool); });
    brushSizeRow.hidden = tool !== 'paint' && tool !== 'eraser';
    if (!brushActive()) brushCursor = null;
    if (tool === 'cursor') setHoverShape(null); else drawHoverOutline();
  }
  Object.keys(toolButtons).forEach(function(t) {
    toolButtons[t].addEventListener('click', function() { setActiveTool(t); });
  });

  var saveDraftTimer = null;
  function saveDraft() {
    if (saveDraftTimer !== null) clearTimeout(saveDraftTimer);
    saveDraftTimer = setTimeout(saveDraftNow, 400);
  }
  function flushDraft() {
    if (saveDraftTimer === null) return;
    clearTimeout(saveDraftTimer);
    saveDraftNow();
  }
  window.addEventListener('pagehide', flushDraft);
  document.addEventListener('visibilitychange', function() { if (document.hidden) flushDraft(); });
  function saveDraftNow() {
    saveDraftTimer = null;
    if (currentMapId === null) return;
    var assignments = {};
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i];
      if (s.districtId !== null) assignments[s.county + '|' + s.precinct] = s.districtId;
    }
    try {
      localStorage.setItem(draftKey(currentMapId), JSON.stringify({
        state: currentState ? currentState.key : 'CA',
        count: districtCount,
        mode: districtColorMode,
        assignments: assignments,
        names: districtNames,
        locked: districtLocked,
        name: mapNameInput.value,
        dirty: hasUnsavedChanges,
      }));
    } catch (err) {}
  }
  mapNameInput.addEventListener('input', saveDraft);

  var districtPlaceholder = document.getElementById('district-placeholder');
  var districtDetail = document.getElementById('district-detail');
  var diName = document.getElementById('di-name');
  var diNameInput = document.getElementById('di-name-input');
  var diRenameBtn = document.getElementById('di-rename-btn');
  var diDemName = document.getElementById('di-dem-name');
  var diRepName = document.getElementById('di-rep-name');
  var diDem = document.getElementById('di-dem');
  var diDemPct = document.getElementById('di-dem-pct');
  var diRep = document.getElementById('di-rep');
  var diRepPct = document.getElementById('di-rep-pct');
  var diOtherRow = document.getElementById('di-other-row');
  var diOther = document.getElementById('di-other');
  var diOtherPct = document.getElementById('di-other-pct');
  var diMargin = document.getElementById('di-margin');

  function updateDistrictInfo() {
    var infoId = infoDistrictId();
    shownInfoDistrictId = infoId;
    updateDemoBubbles();
    diNameInput.hidden = true;
    diName.hidden = false;
    if (infoId === null || !activeRace) {
      districtPlaceholder.hidden = false;
      districtDetail.hidden = true;
      return;
    }
    var d = districtStats[infoId] || zeroStats();
    districtPlaceholder.hidden = true;
    districtDetail.hidden = false;
    diRenameBtn.hidden = infoId !== activeDistrictId;
    diName.textContent = districtLabel(infoId);
    diDemName.textContent = activeRace.demName;
    diRepName.textContent = activeRace.repName;
    diOtherRow.hidden = !activeRace.hasOther;
    diDem.textContent = d.dem.toLocaleString();
    diRep.textContent = d.rep.toLocaleString();
    diOther.textContent = d.other.toLocaleString();
    var totalAll = d.dem + d.rep + d.other;
    if (totalAll > 0) {
      diDemPct.textContent = '(' + (d.dem / totalAll * 100).toFixed(1) + '%)';
      diRepPct.textContent = '(' + (d.rep / totalAll * 100).toFixed(1) + '%)';
      diOtherPct.textContent = '(' + (d.other / totalAll * 100).toFixed(1) + '%)';
    } else {
      diDemPct.textContent = '';
      diRepPct.textContent = '';
      diOtherPct.textContent = '';
    }
    if (d.margin === null) {
      diMargin.textContent = 'no data';
    } else {
      var who = leaderName(d, activeRace);
      diMargin.textContent = who + ' +' + Math.abs(d.margin * 100).toFixed(1) + ' pts';
    }
    var dtv = turnoutOf(d);
    document.getElementById('di-turnout').textContent = dtv === null ? 'no data' : (dtv * 100).toFixed(1) + '%';
    updateShiftRows('di', d);
    fillPopRow('di', d, currentState.geo === 'blockgroup');
    fitName(diDemName);
    fitName(diRepName);
  }

  var diRenameCancelled = false;

  function commitRenameActiveDistrict() {
    if (diRenameCancelled) { diRenameCancelled = false; return; }
    if (activeDistrictId === null) { diNameInput.hidden = true; diName.hidden = false; return; }
    var k = activeDistrictId;
    var v = diNameInput.value.trim();
    if (v && v !== 'District ' + k) districtNames[k] = v; else delete districtNames[k];
    hasUnsavedChanges = true;
    saveDraft();
    updateDistrictInfo();
    renderDistrictList();
  }

  diRenameBtn.addEventListener('click', function() {
    if (activeDistrictId === null) return;
    if (mapReadOnly) { flashReadOnly(); return; }
    diNameInput.value = districtLabel(activeDistrictId);
    diName.hidden = true;
    diNameInput.hidden = false;
    diNameInput.focus();
    diNameInput.select();
  });
  diNameInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') commitRenameActiveDistrict();
    else if (e.key === 'Escape') {
      diRenameCancelled = true;
      diNameInput.hidden = true;
      diName.hidden = false;
    }
  });
  diNameInput.addEventListener('blur', commitRenameActiveDistrict);

  function districtColor(k) {
    var hue = (k * 137.508) % 360;
    return 'hsl(' + hue.toFixed(1) + ', 68%, 55%)';
  }

  function recolorShape(s) {
    if (s.districtId === null || isDimmed(s) || showsUnit(s)) {
      s.fill = layerFill(s);
      return;
    }
    var d = districtStats[s.districtId];
    if (districtColorMode === 'by-lean' && d) {
      s.fill = districtLayerFill(d);
    } else {
      s.fill = districtColor(s.districtId);
    }
  }

  var districtIdealEl = document.getElementById('district-ideal');
  var idealPopulation = 0;
  var idealPops = {};
  var mapTotals = { pop20: 0 };
  function formatDeviation(pop) {
    var dev = Math.round(pop - idealPopulation);
    return (dev < 0 ? '−' : '+') + Math.abs(dev).toLocaleString();
  }
  function formatDeviationPct(pop) {
    var pct = (pop - idealPopulation) / idealPopulation * 100;
    var absPct = Math.abs(pct);
    return (pct < 0 ? '−' : '+') + absPct.toFixed(absPct < 10 ? 2 : 1) + '%';
  }
  function updateIdealPopulation() {
    var totals = mapTotalsCache;
    if (!totals) {
      totals = { pop: 0, pop20: 0, pop10: 0, pop00: 0 };
      ETH_GROUPS.forEach(function(L) { totals[L.key] = 0; });
      EDU_KEYS.forEach(function(k) { totals[k] = 0; });
      AGE_KEYS.forEach(function(k) { totals[k] = 0; });
      ORIGIN_KEYS.forEach(function(k) { totals[k] = 0; });
      LANG_KEYS.forEach(function(k) { totals[k] = 0; });
      INC_KEYS.forEach(function(k) { totals[k] = 0; });
      POP_MORE_KEYS.forEach(function(k) { totals[k] = 0; });
      var totalKeys = Object.keys(totals);
      for (var i = 0; i < shapes.length; i++) {
        for (var t = 0; t < totalKeys.length; t++) totals[totalKeys[t]] += shapes[i][totalKeys[t]];
      }
      setIncomeMedian(totals);
      if (shapes.length) mapTotalsCache = totals;
    }
    mapTotals = totals;
    var total = totals.pop;
    Object.keys(totals).forEach(function(k) { idealPops[k] = districtCount > 0 ? totals[k] / districtCount : 0; });
    idealPopulation = idealPops.pop;
    if (districtCount > 0 && total > 0) {
      districtIdealEl.textContent = Math.round(idealPopulation).toLocaleString() + ' people per district';
      districtIdealEl.hidden = false;
    } else {
      districtIdealEl.hidden = true;
    }
  }

  function zeroStats() {
    var z = { dem: 0, rep: 0, other: 0, pop: 0, pop20: 0, pop10: 0, pop00: 0, inc_med: 0, margin: null, count: 0 };
    ETH_GROUPS.forEach(function(L) { z[L.key] = 0; });
    EDU_KEYS.forEach(function(k) { z[k] = 0; });
    AGE_KEYS.forEach(function(k) { z[k] = 0; });
    ORIGIN_KEYS.forEach(function(k) { z[k] = 0; });
    LANG_KEYS.forEach(function(k) { z[k] = 0; });
    INC_KEYS.forEach(function(k) { z[k] = 0; });
    POP_MORE_KEYS.forEach(function(k) { z[k] = 0; });
    SHIFT_KEYS.forEach(function(k) { z[k] = 0; });
    return z;
  }

  function recomputeDistricts() {
    updateIdealPopulation();
    districtStats = {};
    for (var k = 1; k <= districtCount; k++) districtStats[k] = zeroStats();
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i];
      if (s.districtId === null) continue;
      var d = districtStats[s.districtId];
      if (!d) { markDistrictDirty(s.districtId); s.districtId = null; continue; }
      d.dem += s.dem;
      d.rep += s.rep;
      d.other += s.other;
      d.pop += s.pop;
      d.pop20 += s.pop20;
      d.pop10 += s.pop10;
      d.pop00 += s.pop00;
      for (var q = 0; q < ETH_GROUPS.length; q++) d[ETH_GROUPS[q].key] += s[ETH_GROUPS[q].key];
      for (var eq = 0; eq < EDU_KEYS.length; eq++) d[EDU_KEYS[eq]] += s[EDU_KEYS[eq]];
      for (var aq = 0; aq < AGE_KEYS.length; aq++) d[AGE_KEYS[aq]] += s[AGE_KEYS[aq]];
      for (var oq = 0; oq < ORIGIN_KEYS.length; oq++) d[ORIGIN_KEYS[oq]] += s[ORIGIN_KEYS[oq]];
      for (var lq = 0; lq < LANG_KEYS.length; lq++) d[LANG_KEYS[lq]] += s[LANG_KEYS[lq]];
      for (var iq = 0; iq < INC_KEYS.length; iq++) d[INC_KEYS[iq]] += s[INC_KEYS[iq]];
      for (var vq = 0; vq < POP_MORE_KEYS.length; vq++) d[POP_MORE_KEYS[vq]] += s[POP_MORE_KEYS[vq]];
      for (var shq = 0; shq < SHIFT_KEYS.length; shq++) d[SHIFT_KEYS[shq]] += s[SHIFT_KEYS[shq]];
      d.count++;
    }
    for (var k = 1; k <= districtCount; k++) {
      var d = districtStats[k];
      setMargin(d);
      setIncomeMedian(d);
    }
    computeDistrictPopScale();
    syncLayerUI();
    if (detailShape) showDetail(detailShape);
    for (var i = 0; i < shapes.length; i++) recolorShape(shapes[i]);
    computeDistrictBorders();
    draw();
    renderDistrictList();
    updateDistrictInfo();
    saveDraft();
  }

  function renderDistrictList() {
    districtList.innerHTML = '';
    var unselectedPop = 0, unselectedCount = 0;
    for (var ui = 0; ui < shapes.length; ui++) {
      if (shapes[ui].districtId === null) { unselectedPop += shapes[ui].pop || 0; unselectedCount++; }
    }
    var unselRow = document.createElement('div');
    unselRow.className = 'district-box unselected-row';
    unselRow.style.cursor = 'default';
    var unselSwatch = document.createElement('span');
    unselSwatch.className = 'district-swatch';
    unselSwatch.style.background = 'transparent';
    unselSwatch.style.border = '1px dashed rgba(255, 255, 255, 0.5)';
    var unselName = document.createElement('span');
    unselName.className = 'district-name';
    unselName.textContent = 'Unselected';
    var unselBadge = document.createElement('span');
    unselBadge.className = 'district-count-badge';
    unselBadge.textContent = unselectedPop.toLocaleString();
    unselBadge.title = 'Population not in any district (' + unselectedCount.toLocaleString() + ' unassigned)';
    unselRow.appendChild(unselSwatch);
    unselRow.appendChild(unselName);
    unselRow.appendChild(unselBadge);
    districtList.appendChild(unselRow);
    for (var k = 1; k <= districtCount; k++) {
      (function(k) {
        var stats = districtStats[k] || { count: 0, pop: 0, margin: null };
        var btn = document.createElement('button');
        btn.className = 'district-box' + (k === activeDistrictId ? ' active' : '');
        btn.type = 'button';
        var swatch = document.createElement('span');
        swatch.className = 'district-swatch';
        swatch.style.background = districtColorMode === 'by-lean' ? districtLayerFill(stats) : districtColor(k);
        swatch.addEventListener('click', function(e) { e.stopPropagation(); });
        swatch.addEventListener('dblclick', function(e) {
          e.stopPropagation();
          if (mapReadOnly) { flashReadOnly(); return; }
          editingDistrictId = k;
          renderDistrictList();
        });
        btn.appendChild(swatch);

        if (editingDistrictId === k) {
          var nameInput = document.createElement('input');
          nameInput.type = 'text';
          nameInput.className = 'district-name-input';
          nameInput.maxLength = 40;
          nameInput.value = districtLabel(k);
          nameInput.addEventListener('click', function(e) { e.stopPropagation(); });
          var renameCancelled = false;
          var commitRename = function() {
            if (renameCancelled) { renameCancelled = false; return; }
            var v = nameInput.value.trim();
            if (v && v !== 'District ' + k) districtNames[k] = v; else delete districtNames[k];
            editingDistrictId = null;
            hasUnsavedChanges = true;
            saveDraft();
            renderDistrictList();
          };
          nameInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') commitRename();
            else if (e.key === 'Escape') { renameCancelled = true; editingDistrictId = null; renderDistrictList(); }
          });
          nameInput.addEventListener('blur', commitRename);
          btn.appendChild(nameInput);
        } else {
          var nameEl = document.createElement('span');
          nameEl.className = 'district-name';
          nameEl.textContent = districtLabel(k);
          btn.appendChild(nameEl);
        }

        var badge = document.createElement('span');
        badge.className = 'district-count-badge';
        if (idealPopulation > 0) {
          badge.textContent = formatDeviation(stats.pop || 0);
          badge.title = 'Population deviation from the ' + Math.round(idealPopulation).toLocaleString() + ' ideal';
          var pctBadge = document.createElement('span');
          pctBadge.className = 'district-pct-badge';
          pctBadge.textContent = formatDeviationPct(stats.pop || 0);
          pctBadge.title = badge.title;
          btn.appendChild(badge);
          btn.appendChild(pctBadge);
        } else {
          badge.textContent = (stats.pop || 0).toLocaleString();
          badge.title = 'Population';
          btn.appendChild(badge);
        }

        var lockBtn = document.createElement('button');
        lockBtn.type = 'button';
        lockBtn.className = 'district-lock-btn' + (districtLocked[k] ? ' locked' : '');
        lockBtn.title = districtLocked[k] ? 'Unlock district' : 'Lock district';
        lockBtn.innerHTML = '<svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="9" width="10" height="8" rx="1.5"></rect><path d="M7 9 V6 a3 3 0 0 1 6 0 V9"></path></svg>';
        lockBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (mapReadOnly) { flashReadOnly(); return; }
          districtLocked[k] = !districtLocked[k];
          hasUnsavedChanges = true;
          saveDraft();
          renderDistrictList();
        });
        btn.appendChild(lockBtn);

        btn.addEventListener('click', function() {
          if (editingDistrictId === k) return;
          activeDistrictId = (activeDistrictId === k) ? null : k;
          if (activeDistrictId !== null) setActiveTool('paint');
          if (highlightDistrict || showUnitsInDistrict) refreshHighlight();
          renderDistrictList();
          updateDistrictInfo();
        });
        districtList.appendChild(btn);
        if (editingDistrictId === k) { nameInput.focus(); nameInput.select(); }
      })(k);
    }
    fitDistrictSidebar();
  }

  function setDistrictCount(n) {
    n = Math.max(0, Math.min(1000, n | 0));
    if (mapReadOnly) { districtCountInput.value = districtCount; flashReadOnly(); return; }
    if (n === districtCount) return;
    if (n < districtCount) {
      for (var i = 0; i < shapes.length; i++) {
        if (shapes[i].districtId !== null && shapes[i].districtId > n) {
          markDistrictDirty(shapes[i].districtId);
          shapes[i].districtId = null;
        }
      }
      if (activeDistrictId !== null && activeDistrictId > n) activeDistrictId = null;
    }
    districtCount = n;
    districtCountInput.value = n;
    hasUnsavedChanges = true;
    recomputeDistricts();
  }

  function setDistrictColorMode(mode) {
    districtColorMode = mode;
    districtModeByDistrictBtn.classList.toggle('active', mode === 'by-district');
    districtModeByLeanBtn.classList.toggle('active', mode === 'by-lean');
    if (!mapReadOnly) hasUnsavedChanges = true;
    recomputeDistricts();
  }

  districtCountInput.addEventListener('change', function() {
    setDistrictCount(parseInt(districtCountInput.value, 10) || 0);
  });
  document.getElementById('district-count-minus').addEventListener('click', function() {
    setDistrictCount(districtCount - 1);
  });
  document.getElementById('district-count-plus').addEventListener('click', function() {
    setDistrictCount(districtCount + 1);
  });
  districtModeByDistrictBtn.addEventListener('click', function() { setDistrictColorMode('by-district'); });
  districtModeByLeanBtn.addEventListener('click', function() { setDistrictColorMode('by-lean'); });

  function readSavedMaps() {
    try {
      var raw = localStorage.getItem(DISTRICTS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (err) {
      return {};
    }
  }

  function writeSavedMaps(all) {
    localStorage.setItem(DISTRICTS_STORAGE_KEY, JSON.stringify(all));
  }

  function flashNameInputError() {
    mapNameInput.focus();
    mapNameInput.classList.add('input-error');
    setTimeout(function() { mapNameInput.classList.remove('input-error'); }, 1200);
  }

  function flashSaveButton() {
    var original = saveMapBtn.textContent;
    saveMapBtn.textContent = 'Saved';
    setTimeout(function() { saveMapBtn.textContent = original; }, 1500);
  }

  // Saving a map you are only viewing makes your own copy of it, with its own id.
  function saveCopyOfSharedMap() {
    if (CLOUD_API && !cloudUser) { openAccountModal('login', 'Log in or sign up to save your own copy of this map.'); return false; }
    var baseName = mapNameInput.value.trim() || 'Shared map';
    var all = readSavedMaps();
    var name = baseName + ' (copy)';
    for (var n = 2; all[name]; n++) name = baseName + ' (copy ' + n + ')';
    currentSid = null;
    currentMapId = allocateMapId();
    location.hash = 'draft=' + currentMapId;
    setReadOnly(false);
    mapNameInput.value = name;
    hasUnsavedChanges = true;
    return saveCurrentMap();
  }

  function saveCurrentMap() {
    if (mapReadOnly) return saveCopyOfSharedMap();
    if (CLOUD_API && !cloudUser) { openAccountModal('login', 'Log in or sign up to save your map.'); return false; }
    var name = mapNameInput.value.trim();
    if (!name) { flashNameInputError(); return false; }
    var assignments = {};
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i];
      if (s.districtId !== null) assignments[s.county + '|' + s.precinct] = s.districtId;
    }
    if (currentMapId === null) {
      currentMapId = allocateMapId();
      location.hash = currentSid ? 'map=' + currentSid : 'draft=' + currentMapId;
    }
    var all = readSavedMaps();
    if (currentSid) {
      // Renamed since the last save: drop the old entry for this same map so it isn't listed twice.
      Object.keys(all).forEach(function(n) { if (all[n].sid === currentSid && n !== name) delete all[n]; });
    }
    all[name] = {
      id: currentMapId,
      sid: currentSid || undefined,
      updated: Date.now(),
      state: currentState ? currentState.key : 'CA',
      count: districtCount,
      mode: districtColorMode,
      assignments: assignments,
      names: districtNames,
      locked: districtLocked,
    };
    try {
      writeSavedMaps(all);
      cloudPush(name);
      renderHomeSavedList();
      hasUnsavedChanges = false;
      saveDraft();
      flashSaveButton();
      return true;
    } catch (err) {
      return false;
    }
  }

  saveMapBtn.addEventListener('click', saveCurrentMap);

  function partyClassFor(race) {
    return race.winner === 'dem' ? 'party-dem' : (race.winner === 'rep' ? 'party-rep' : 'party-none');
  }

  function resetGeography() {
    districtSidebarW = DISTRICT_SIDEBAR_MIN_W;
    shapes.length = 0;
    adjCache = null;
    setHoverShape(null);
    shapesIndex = null;
    geoProj = null;
    tileCache = {};
    tileQueue = [];
    basemapDrawn = [];
    shapesByCounty = {};
    mapTotalsCache = null;
    districtGeomCache = {};
    markAllBordersDirty();
    geometryReady = null;
    countyBorderPath = null;
    overlayLines = null;
    overlayPath = null;
    overlayNameEl.textContent = '';
    overlayClearBtn.style.display = 'none';
    overlayUploadBtn.textContent = 'Upload';
    countyRecordPaths = [];
    countyOutlineCache = {};
    raceDataCache = {};
    raceReadyKeys = {};
    raceTurnoutsPromise = null;
    countyAggCache = {};
    racesBootstrapped = false;
    loadedStateKey = null;
    activeRace = null;
    districtBorderSegments = [];
    districtFillPaths = {};
    districtFillLod = [districtFillPaths, {}, {}];
    districtBorderLod = [districtBorderSegments, [], []];
    districtLabelPoints = {};
    districtStats = {};
    layerMode = 'election';
    allRaces = [];
    selectedRaceKey = null;
    detailShape = null;
    shiftMode = false;
    shiftReady = false;
    shiftFromKey = null;
    shiftToKey = null;
    shiftToken++;
    shiftPanel.hidden = true;
    shiftBox.classList.remove('active');
    shiftFromSel.innerHTML = '';
    shiftToSel.innerHTML = '';
    syncLayerUI();
    document.getElementById('race-list').innerHTML = '';
  }

  function openMap(stateKey) {
    var nextState = STATES[stateKey] || STATES.CA;
    if (loadedStateKey !== null && loadedStateKey !== nextState.key) resetGeography();
    currentState = nextState;
    applyGeoLabels();
    document.getElementById('home-screen').hidden = true;
    document.getElementById('app-view').hidden = false;
    if (racesBootstrapped) return;
    racesBootstrapped = true;
    loadedStateKey = currentState.key;

    fetch(versioned(currentState.dataDir + 'races.json'))
      .then(function(r) { return r.json(); })
      .then(function(index) {
        var allIndexRaces = index.races;
        var races = allIndexRaces.filter(function(r) { return r.group !== 'more'; });
        var moreRaces = allIndexRaces.filter(function(r) { return r.group === 'more'; });
        allRaces = allIndexRaces;
        var raceList = document.getElementById('race-list');
        var raceButtons = {};
        raceButtonEls = raceButtons;
        var lastYear = null;
        var moreLists = {};
        function flushMore(year) {
          if (year === null || moreLists[year] || !moreRaces.some(function(r) { return r.year === year; })) return;
          var moreBtn = document.createElement('button');
          moreBtn.type = 'button';
          moreBtn.className = 'edu-more-btn';
          var list = document.createElement('div');
          list.hidden = true;
          var syncMore = function() { moreBtn.textContent = (list.hidden ? '▸ ' : '▾ ') + 'More elections'; };
          moreBtn.addEventListener('click', function() { list.hidden = !list.hidden; syncMore(); });
          syncMore();
          raceList.appendChild(moreBtn);
          raceList.appendChild(list);
          moreLists[year] = list;
        }
        var moreGrids = {};
        function moreGrid(race) {
          var statewide = race.moreGroup === 'statewide';
          var name = statewide ? 'More Statewide Races' : 'U.S. House', key = race.year + '|' + name;
          if (moreGrids[key]) return moreGrids[key];
          var subBtn = document.createElement('button');
          subBtn.type = 'button';
          subBtn.className = 'race-box';
          var grid = document.createElement('div');
          if (!statewide) grid.className = 'race-grid';
          grid.hidden = true;
          var syncSub = function() { subBtn.textContent = (grid.hidden ? '▸ ' : '▾ ') + name; };
          subBtn.addEventListener('click', function() { grid.hidden = !grid.hidden; syncSub(); });
          syncSub();
          moreLists[race.year].appendChild(subBtn);
          moreLists[race.year].appendChild(grid);
          moreGrids[key] = grid;
          return grid;
        }
        moreRaces.forEach(function(r) { r.__more = true; });
        races.concat(moreRaces).forEach(function(race, idx) {
          if (idx === races.length) flushMore(lastYear);
          if (!race.__more && race.year !== lastYear) {
            flushMore(lastYear);
            var yearLabel = document.createElement('div');
            yearLabel.className = 'race-year-label';
            yearLabel.textContent = race.year;
            raceList.appendChild(yearLabel);
            lastYear = race.year;
          }
          var btn = document.createElement('button');
          btn.className = 'race-box ' + partyClassFor(race);
          var sp = sameParty(race);
          btn.style.setProperty('--dem', sp ? (sp === 'D' ? DEFAULT_DEM_HEX : DEFAULT_REP_HEX) : (race.demColor || DEFAULT_DEM_HEX));
          btn.style.setProperty('--rep', sp ? (sp === 'D' ? DEFAULT_DEM_HEX : DEFAULT_REP_HEX) : (race.repColor || DEFAULT_REP_HEX));
          btn.type = 'button';
          var raceLabel = document.createElement('span');
          raceLabel.className = 'race-label';
          var isChip = race.__more && race.moreGroup !== 'statewide';
          raceLabel.textContent = isChip && parseInt(race.label, 10) ? parseInt(race.label, 10) : race.label;
          if (isChip) btn.classList.add('race-chip');
          btn.title = race.label;
          btn.appendChild(raceLabel);
          if (race.marginText) {
            var marginSpan = document.createElement('span');
            marginSpan.className = 'race-margin';
            marginSpan.textContent = race.marginText;
            btn.appendChild(marginSpan);
            raceMarginSpans[race.key] = marginSpan;
          }
          btn.addEventListener('click', function() {
            var wasShift = shiftMode;
            if (wasShift) setShiftMode(false);
            if (!wasShift && race.key === selectedRaceKey && layerMode === 'election') return;
            Object.keys(raceButtons).forEach(function(k) { raceButtons[k].classList.remove('active'); });
            btn.classList.add('active');
            updateRaceButtons();
            var changed = race.key !== selectedRaceKey;
            selectedRaceKey = race.key;
            if (layerMode !== 'election') setLayerMode('election');
            else if (changed) loadRace(race);
          });
          raceButtons[race.key] = btn;
          (race.__more ? moreGrid(race) : raceList).appendChild(btn);
        });

        if (races.length) {
          populateShiftSelects(races);
          raceButtons[races[0].key].classList.add('active');
          selectedRaceKey = races[0].key;
          loadRace(races[0]);
          // Other races load only when opened (see ensureRaceTurnouts for the one exception). Prefetching all of
          // them made thousands of requests per visit and got visitors blocked by the host's flood protection.
          if (electionView === 'turnout') ensureRaceTurnouts();
        }
      })
      .catch(function(err) {
        loading.textContent = 'Could not load the list of elections: ' + err.message;
      });
  }

  // opts.readOnly: someone else's map opened from a shared link. Its site-wide id is payload.sid.
  function applySavedPayload(name, payload, opts) {
    districtSidebarW = DISTRICT_SIDEBAR_MIN_W;
    opts = opts || {};
    var stateKey = payload.state || 'CA';
    currentSid = payload.sid || null;
    if (opts.readOnly) {
      currentMapId = null;   // no local draft for a map that isn't yours
    } else {
      currentMapId = (typeof payload.id === 'number') ? payload.id : allocateMapId();
    }
    location.hash = currentSid ? 'map=' + currentSid : 'draft=' + currentMapId;
    openMap(stateKey);
    loadGeometry().then(function() {
      // An empty {} can arrive from the server as [], which would silently drop later edits when saved.
      var asObj = function(x) { return x && typeof x === 'object' && !Array.isArray(x) ? x : {}; };
      var assignments = asObj(payload.assignments);
      markAllBordersDirty();
      for (var i = 0; i < shapes.length; i++) {
        var s = shapes[i];
        var key = s.county + '|' + s.precinct;
        s.districtId = Object.prototype.hasOwnProperty.call(assignments, key) ? assignments[key] : null;
      }
      activeDistrictId = null;
      editingDistrictId = null;
      districtCount = Math.max(0, Math.min(1000, payload.count | 0));
      districtCountInput.value = districtCount;
      districtColorMode = payload.mode === 'by-lean' ? 'by-lean' : 'by-district';
      districtModeByDistrictBtn.classList.toggle('active', districtColorMode === 'by-district');
      districtModeByLeanBtn.classList.toggle('active', districtColorMode === 'by-lean');
      districtNames = asObj(payload.names);
      districtLocked = asObj(payload.locked);
      mapNameInput.value = name;
      hasUnsavedChanges = false;
      setReadOnly(!!opts.readOnly, name);
      recomputeDistricts();
    });
  }

  // Open the map behind a shared link (#map=<id>). The server says whether the viewer owns it.
  function loadSharedMap(id) {
    cloudFetch('/map?id=' + id).then(function(m) {
      var payload = m.payload;
      payload.sid = m.id;
      payload.updated = m.updated;
      applySavedPayload(m.name, payload, { readOnly: !m.mine });
    }).catch(function(err) {
      location.hash = '';
      alert(err.status === 404 ? 'That map could not be found. It may have been deleted.' : 'Could not open that map: ' + err.message);
    });
  }

  var homeStateSelect = document.getElementById('home-state-select');
  var homeGeoSelect = document.getElementById('home-geo-select');
  var seenBases = {};
  Object.keys(STATES).forEach(function(key) {
    var st = STATES[key];
    if (seenBases[st.base]) return;
    seenBases[st.base] = true;
    var opt = document.createElement('option');
    opt.value = st.base;
    opt.textContent = st.label;
    homeStateSelect.appendChild(opt);
  });

  function stateKeyFor(base, geo) {
    var keys = Object.keys(STATES);
    for (var i = 0; i < keys.length; i++) {
      if (STATES[keys[i]].base === base && STATES[keys[i]].geo === geo) return keys[i];
    }
    return null;
  }
  function refreshGeoOptions() {
    var base = homeStateSelect.value;
    var prev = homeGeoSelect.value;
    homeGeoSelect.innerHTML = '';
    Object.keys(STATES).filter(function(key) { return STATES[key].base === base; })
      .sort(function(a, b) { return (STATES[a].geo === 'blockgroup' ? 0 : 1) - (STATES[b].geo === 'blockgroup' ? 0 : 1); })
      .forEach(function(key) {
      var st = STATES[key];
      var opt = document.createElement('option');
      opt.value = st.geo;
      opt.textContent = GEO_LABELS[st.geo];
      homeGeoSelect.appendChild(opt);
    });
    if (prev && stateKeyFor(base, prev)) homeGeoSelect.value = prev;
    else if (stateKeyFor(base, 'blockgroup')) homeGeoSelect.value = 'blockgroup';
  }
  refreshGeoOptions();

  var homeCountInput = document.getElementById('home-district-count');
  var homeIdealEl = document.getElementById('home-ideal');
  function updateHomeIdeal() {
    var st = STATES[stateKeyFor(homeStateSelect.value, homeGeoSelect.value)];
    var n = parseInt(homeCountInput.value, 10) || 0;
    if (st && st.population > 0 && n > 0) {
      homeIdealEl.textContent = Math.round(st.population / n).toLocaleString() + ' people per district';
      homeIdealEl.hidden = false;
    } else {
      homeIdealEl.hidden = true;
    }
  }
  homeStateSelect.addEventListener('change', function() {
    refreshGeoOptions();
    var st = STATES[stateKeyFor(homeStateSelect.value, homeGeoSelect.value)];
    if (st && typeof st.districts === 'number') homeCountInput.value = st.districts;
    updateHomeIdeal();
  });
  homeGeoSelect.addEventListener('change', updateHomeIdeal);
  homeCountInput.addEventListener('input', updateHomeIdeal);
  document.getElementById('home-count-minus').addEventListener('click', function() {
    homeCountInput.value = Math.max(0, (parseInt(homeCountInput.value, 10) || 0) - 1);
    updateHomeIdeal();
  });
  document.getElementById('home-count-plus').addEventListener('click', function() {
    homeCountInput.value = Math.min(1000, (parseInt(homeCountInput.value, 10) || 0) + 1);
    updateHomeIdeal();
  });
  updateHomeIdeal();

  document.getElementById('home-create-btn').addEventListener('click', function() {
    if (CLOUD_API && !cloudUser) { openAccountModal('login', 'Log in or sign up to create a map. Maps you save get a link you can share.'); return; }
    var stateKey = stateKeyFor(homeStateSelect.value, homeGeoSelect.value) || homeStateSelect.value;
    var n = Math.max(0, Math.min(1000, parseInt(homeCountInput.value, 10) || 0));
    currentMapId = allocateMapId();
    currentSid = null;
    location.hash = 'draft=' + currentMapId;
    openMap(stateKey);
    setReadOnly(false);
    activeDistrictId = null;
    editingDistrictId = null;
    markAllBordersDirty();
    for (var i = 0; i < shapes.length; i++) shapes[i].districtId = null;
    districtNames = {};
    districtLocked = {};
    mapNameInput.value = '';
    districtColorMode = 'by-district';
    districtModeByDistrictBtn.classList.add('active');
    districtModeByLeanBtn.classList.remove('active');
    districtCount = n;
    districtCountInput.value = n;
    hasUnsavedChanges = true;
    recomputeDistricts();
  });

  function renderHomeSavedList() {
    var tbody = document.getElementById('home-maps-tbody');
    tbody.innerHTML = '';
    var all = readSavedMaps();
    var names = Object.keys(all).sort();
    names.forEach(function(name) {
      var payload = all[name];
      var stateKey = payload.state || 'CA';
      var stateLabel = (STATES[stateKey] && STATES[stateKey].label) || stateKey;
      var tr = document.createElement('tr');

      var nameTd = document.createElement('td');
      nameTd.className = 'home-map-name';
      nameTd.textContent = name;
      tr.appendChild(nameTd);

      var stateTd = document.createElement('td');
      stateTd.textContent = stateLabel + (STATES[stateKey] ? ' \u00b7 ' + GEO_LABELS[STATES[stateKey].geo] : '');
      tr.appendChild(stateTd);

      var countTd = document.createElement('td');
      countTd.textContent = payload.count || 0;
      tr.appendChild(countTd);

      var actionTd = document.createElement('td');
      var shareBtn = document.createElement('button');
      shareBtn.className = 'home-map-share';
      shareBtn.type = 'button';
      shareBtn.textContent = FILE_SHARING ? 'Export' : 'Share';
      shareBtn.title = FILE_SHARING ? 'Save this map as a file you can send to someone' : 'Copy a link to this map';
      shareBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        if (FILE_SHARING) exportMapFile(name, payload);
        else shareMap(payload.sid, shareBtn);
      });
      actionTd.appendChild(shareBtn);
      var delBtn = document.createElement('button');
      delBtn.className = 'home-map-delete';
      delBtn.type = 'button';
      delBtn.textContent = 'Delete';
      delBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        if (!confirm('Delete “' + name + '”?\n\nThis permanently removes the map' + (payload.sid ? ', and its share link will stop working' : '') + '. This cannot be undone.')) return;
        var all2 = readSavedMaps();
        var sid = all2[name] && all2[name].sid;
        delete all2[name];
        writeSavedMaps(all2);
        cloudDelete(sid);
        renderHomeSavedList();
      });
      actionTd.appendChild(delBtn);
      tr.appendChild(actionTd);

      tr.addEventListener('click', function() { applySavedPayload(name, payload); });
      tbody.appendChild(tr);
    });
  }

  function goHome() {
    closePanel();
    clearCurrentDraft();
    document.getElementById('app-view').hidden = true;
    document.getElementById('home-screen').hidden = false;
    renderHomeSavedList();
  }

  var unsavedModal = document.getElementById('unsaved-modal');

  window.addEventListener('beforeunload', function(e) {
    if (hasUnsavedChanges) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  document.getElementById('nav-home').addEventListener('click', function() {
    if (hasUnsavedChanges) {
      unsavedModal.hidden = false;
      return;
    }
    goHome();
  });

  document.getElementById('unsaved-save-btn').addEventListener('click', function() {
    if (!mapNameInput.value.trim()) {
      unsavedModal.hidden = true;
      flashNameInputError();
      return;
    }
    var ok = saveCurrentMap();
    unsavedModal.hidden = true;
    if (ok) goHome();
  });
  document.getElementById('unsaved-discard-btn').addEventListener('click', function() {
    hasUnsavedChanges = false;
    unsavedModal.hidden = true;
    goHome();
  });
  document.getElementById('unsaved-cancel-btn').addEventListener('click', function() {
    unsavedModal.hidden = true;
  });

  function restoreFromHash() {
    var shared = /map=(\d+)/.exec(location.hash);
    if (shared && CLOUD_API) { loadSharedMap(parseInt(shared[1], 10)); return; }
    // #draft=N is a map in progress in this browser. (Without the server, e.g. a local copy, #map=N means the same.)
    var m = /draft=(\d+)/.exec(location.hash) || (CLOUD_API ? null : shared);
    if (!m) return;
    var id = parseInt(m[1], 10);
    var raw;
    try { raw = localStorage.getItem(draftKey(id)); } catch (err) { raw = null; }
    if (!raw) return;
    var draft;
    try { draft = JSON.parse(raw); } catch (err) { return; }
    currentMapId = id;
    var stateKey = draft.state || 'CA';
    openMap(stateKey);
    loadGeometry().then(function() {
      var assignments = draft.assignments || {};
      markAllBordersDirty();
      for (var i = 0; i < shapes.length; i++) {
        var s = shapes[i];
        var key = s.county + '|' + s.precinct;
        s.districtId = Object.prototype.hasOwnProperty.call(assignments, key) ? assignments[key] : null;
      }
      activeDistrictId = null;
      editingDistrictId = null;
      districtCount = Math.max(0, Math.min(1000, draft.count | 0));
      districtCountInput.value = districtCount;
      districtColorMode = draft.mode === 'by-lean' ? 'by-lean' : 'by-district';
      districtModeByDistrictBtn.classList.toggle('active', districtColorMode === 'by-district');
      districtModeByLeanBtn.classList.toggle('active', districtColorMode === 'by-lean');
      districtNames = draft.names || {};
      districtLocked = draft.locked || {};
      mapNameInput.value = draft.name || '';
      hasUnsavedChanges = !!draft.dirty;
      recomputeDistricts();
    });
  }

  var statsPage = document.getElementById('stats-page');
  var statsRaceSelect = document.getElementById('stats-race');
  var statsRaceKey = null;
  var leanToken = 0;
  var leanRows = null;
  var leanRowsRaceKey = null;
  var leanShown = [];
  var leanChart = document.getElementById('lean-chart');
  var leanReadoutDefault = 'Hover a sliver to see its district.';

  function openStats() {
    closePanel();
    statsPage.hidden = false;
    statsRaceSelect.innerHTML = '';
    // The "More elections" tabs (separate House races, extra statewide races) are left out of the lean chart.
    var leanRaces = allRaces.filter(function(r) { return r.group !== 'more'; });
    leanRaces.forEach(function(r) {
      var o = document.createElement('option');
      o.value = r.key;
      o.textContent = r.year + ' ' + r.label;
      statsRaceSelect.appendChild(o);
    });
    var keyOk = function(k) { return leanRaces.some(function(r) { return r.key === k; }); };
    if (!statsRaceKey || !keyOk(statsRaceKey)) {
      var def = cardRace();
      statsRaceKey = def && keyOk(def.key) ? def.key : (leanRaces[0] ? leanRaces[0].key : null);
    }
    if (statsRaceKey) statsRaceSelect.value = statsRaceKey;
    renderDistrictLean(true);
  }
  function closeStats() { statsPage.hidden = true; }

  function districtLeanFor(race) {
    return loadGeometry().then(function() { return fetchRaceRecords(race); }).then(function(records) {
      var acc = {};
      for (var k = 1; k <= districtCount; k++) acc[k] = { k: k, dem: 0, rep: 0, other: 0, margin: null };
      for (var i = 0; i < records.length; i++) {
        var r = records[i], s = shapesIndex[r.county + '|' + r.precinct];
        if (!s || s.districtId === null) continue;
        var a = acc[s.districtId];
        if (!a) continue;
        a.dem += r.dem;
        a.rep += r.rep;
        a.other += r.other;
      }
      var rows = [];
      for (var d = 1; d <= districtCount; d++) {
        var row = acc[d], two = row.dem + row.rep;
        row.margin = two > 0 ? (row.dem - row.rep) / two : null;
        rows.push(row);
      }
      return rows;
    });
  }

  function renderDistrictLean(recompute) {
    var empty = document.getElementById('lean-empty'), readout = document.getElementById('lean-readout');
    var race = raceByKey(statsRaceKey);
    if (!race || districtCount < 1) {
      leanChart.innerHTML = '';
      document.getElementById('lean-flip').hidden = true;
      document.getElementById('lean-axis').hidden = true;
      document.getElementById('lean-summary').textContent = '';
      empty.hidden = false;
      empty.textContent = !race ? 'No elections are loaded yet.' : 'Create some districts first, then their lean will show here.';
      return;
    }
    empty.hidden = true;
    if (!recompute && leanRows && leanRowsRaceKey === race.key) { paintLean(race, leanRows); return; }
    var token = ++leanToken;
    leanChart.innerHTML = '';
    document.getElementById('lean-flip').hidden = true;
    readout.textContent = 'Loading…';
    districtLeanFor(race).then(function(rows) {
      if (token !== leanToken) return;
      leanRows = rows;
      leanRowsRaceKey = race.key;
      paintLean(race, rows);
    }).catch(function(err) {
      if (token === leanToken) readout.textContent = 'Could not load this election: ' + err.message;
    });
  }

  function paintLean(race, rows) {
    var sorted = rows.slice();
    sorted.sort(function(a, b) {
      if (a.margin === null && b.margin === null) return a.k - b.k;
      if (a.margin === null) return 1;
      if (b.margin === null) return -1;
      return (a.margin - b.margin) || (a.k - b.k);
    });
    leanShown = sorted;
    leanChart.innerHTML = '';
    leanChart.style.gap = sorted.length <= 100 ? '1px' : '0';
    var frag = document.createDocumentFragment(), nDem = 0, nRep = 0, nEven = 0, nNone = 0;
    // Use this election's own two colors (e.g. Democrat vs. Democrat), not the colors of the race open on the map.
    var demHex = race.demColor || DEFAULT_DEM_HEX, repHex = race.repColor || DEFAULT_REP_HEX;
    var demRgb = hexToRgb(demHex), repRgb = hexToRgb(repHex);
    sorted.forEach(function(r, i) {
      var el = document.createElement('div');
      el.className = 'lean-sliver';
      el.setAttribute('data-i', i);
      el.style.background = r.margin === null ? NODATA_FILL :
        lerpColor(Math.min(Math.abs(r.margin) / DISTRICT_LEAN_SCALE, 1), r.margin > 0 ? demRgb : repRgb);
      frag.appendChild(el);
      if (r.margin === null) nNone++; else if (r.margin > 0) nDem++; else if (r.margin < 0) nRep++; else nEven++;
    });
    leanChart.appendChild(frag);
    document.getElementById('lean-axis').hidden = false;
    var flip = document.getElementById('lean-flip');
    if (nRep > 0 && nDem > 0) {
      flip.style.left = ((nRep + nEven / 2) / sorted.length * 100) + '%';
      document.getElementById('lean-flip-label').textContent = 'EVEN';
      flip.hidden = false;
    } else {
      flip.hidden = true;
    }
    var axisRep = document.getElementById('lean-axis-rep'), axisDem = document.getElementById('lean-axis-dem');
    axisRep.textContent = '← ' + race.repShort;
    axisRep.className = '';
    axisRep.style.color = repHex;
    axisRep.style.fontWeight = '600';
    axisDem.textContent = race.demShort + ' →';
    axisDem.className = '';
    axisDem.style.color = demHex;
    axisDem.style.fontWeight = '600';
    document.getElementById('lean-readout').textContent = leanReadoutDefault;
    document.getElementById('lean-summary').textContent = nDem + ' lean ' + race.demShort + ' · ' + nRep + ' lean ' +
      race.repShort + (nEven ? ' · ' + nEven + ' even' : '') + (nNone ? ' · ' + nNone + ' with no votes' : '') +
      ' · ' + sorted.length + ' districts';
  }

  leanChart.addEventListener('mouseover', function(e) {
    var el = e.target.closest ? e.target.closest('.lean-sliver') : null;
    var race = raceByKey(statsRaceKey);
    if (!el || !race) return;
    var r = leanShown[parseInt(el.getAttribute('data-i'), 10)];
    if (!r) return;
    var lean = r.margin === null ? 'no votes' : (r.margin >= 0 ? race.demShort : race.repShort) + ' +' + Math.abs(r.margin * 100).toFixed(1) + ' pts';
    document.getElementById('lean-readout').textContent = districtLabel(r.k) + ': ' + lean + '  (' +
      race.demShort + ' ' + r.dem.toLocaleString() + ' · ' + race.repShort + ' ' + r.rep.toLocaleString() + ')';
  });
  leanChart.addEventListener('mouseleave', function() {
    document.getElementById('lean-readout').textContent = leanReadoutDefault;
  });

  document.getElementById('nav-stats').addEventListener('click', openStats);
  document.getElementById('stats-back').addEventListener('click', closeStats);
  statsRaceSelect.addEventListener('change', function() {
    statsRaceKey = statsRaceSelect.value;
    renderDistrictLean(true);
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !statsPage.hidden) closeStats();
  });

  /* ---- Accounts and cloud saves (ElectionCord / WordPress). Only active on electioncord.com. ---- */
  var CLOUD_API = FILE_SHARING ? null : /(^|\.)electioncord\.com$/.test(location.hostname) ? location.origin + '/wp-json/civitas/v1' : null;
  var SYNCED_KEY = 'civitas-synced-names';
  var cloudUser = null;
  var cloudNonce = null;
  var cloudQueue = Promise.resolve();
  var accountMode = 'login';
  var accountBar = document.getElementById('account-bar');
  var accountModal = document.getElementById('account-modal');
  var accountForm = document.getElementById('account-form');
  var accountTitle = document.getElementById('account-title');
  var accountEmail = document.getElementById('account-email');
  var accountPassword = document.getElementById('account-password');
  var accountMsg = document.getElementById('account-msg');
  var accountSubmit = document.getElementById('account-submit');
  var accountSwitch = document.getElementById('account-switch');
  var accountForgot = document.getElementById('account-forgot');
  var accountResend = document.getElementById('account-resend');

  function readSynced() {
    try { return JSON.parse(localStorage.getItem(SYNCED_KEY)) || []; } catch (err) { return []; }
  }
  function writeSynced(list) {
    try { localStorage.setItem(SYNCED_KEY, JSON.stringify(list)); } catch (err) {}
  }

  function cloudFetch(path, opts) {
    opts = opts || {};
    if (!CLOUD_API) return Promise.reject(new Error('Accounts only work on electioncord.com, not in this local copy.'));
    var headers = { 'Accept': 'application/json' };
    if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
    if (cloudNonce) headers['X-Civitas-Nonce'] = cloudNonce;
    return fetch(CLOUD_API + path, {
      method: opts.method || 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined
    }).then(function(r) {
      return r.json().catch(function() { return {}; }).then(function(j) {
        if (!r.ok) {
          var e = new Error(j.message || 'Something went wrong. Please try again.');
          e.code = j.code;
          e.status = r.status;
          throw e;
        }
        return j;
      });
    });
  }

  // Like cloudFetch, but refreshes the session nonce once if it has expired.
  function cloudAuthed(path, opts) {
    return cloudFetch(path, opts).catch(function(e) {
      if (e.code !== 'bad_nonce') throw e;
      return cloudFetch('/me').then(function(me) {
        if (!me.loggedIn) { cloudUser = null; renderAccountBar(); throw e; }
        cloudNonce = me.nonce;
        return cloudFetch(path, opts);
      });
    });
  }

  // Every saved map has a site-wide id (`sid`) handed out by the server; the share link is #map=<sid>.
  function cloudPush(name) {
    if (!cloudUser) return;
    var payload = readSavedMaps()[name];
    if (!payload) return;
    cloudQueue = cloudQueue.then(function() {
      return cloudAuthed('/maps/save', { method: 'POST', body: { id: payload.sid || undefined, name: name, payload: payload } });
    }).then(function(res) {
      var all = readSavedMaps();
      if (all[name]) {
        all[name].updated = res.updated;
        all[name].sid = res.id;
        writeSavedMaps(all);
        if (all[name].id === currentMapId && currentMapId !== null) {
          currentSid = res.id;
          location.hash = 'map=' + res.id;
        }
      }
    }).catch(function(e) {
      if (window.console) console.warn('Cloud save failed:', e.message);
      alert('Saved on this device, but not to your account: ' + e.message);
    });
  }

  function cloudDelete(sid) {
    if (!cloudUser || !sid) return;
    cloudQueue = cloudQueue.then(function() {
      return cloudAuthed('/maps/delete', { method: 'POST', body: { id: sid } });
    }).catch(function(e) {
      if (window.console) console.warn('Cloud delete failed:', e.message);
    });
  }

  // Merge the account's maps into this browser: the newer copy wins, maps made here are uploaded, and maps
  // that were deleted from the account on another device are removed here.
  function cloudPull() {
    return cloudAuthed('/maps').then(function(res) {
      var local = readSavedMaps();
      var onServer = {};
      var bySid = {};
      var toPush = [];
      Object.keys(local).forEach(function(n) { if (local[n].sid) bySid[local[n].sid] = n; });
      res.maps.forEach(function(m) {
        onServer[m.id] = true;
        var ln = bySid[m.id];
        if (ln === undefined && local[m.name] && !local[m.name].sid) {
          toPush.push(m.name);   // a map made here under the same name: upload it over the account's copy
          return;
        }
        var mine = ln !== undefined ? local[ln] : null;
        if (!mine || m.updated > (mine.updated || 0)) {
          var p = m.payload;
          p.updated = m.updated;
          p.sid = m.id;
          p.id = mine && typeof mine.id === 'number' ? mine.id : allocateMapId();
          if (ln !== undefined && ln !== m.name) delete local[ln];
          local[m.name] = p;
        } else if (mine.updated > m.updated) {
          toPush.push(ln);
        }
      });
      Object.keys(local).forEach(function(name) {
        var sid = local[name].sid;
        if (!sid) toPush.push(name);
        else if (!onServer[sid]) delete local[name];   // deleted from the account on another device
      });
      writeSavedMaps(local);
      renderHomeSavedList();
      toPush.forEach(function(n) { if (local[n]) cloudPush(n); });
    }).catch(function(e) {
      if (window.console) console.warn('Cloud sync failed:', e.message);
    });
  }

  function clearLocalMaps() {
    try {
      localStorage.removeItem(DISTRICTS_STORAGE_KEY);
      localStorage.removeItem(SYNCED_KEY);
      Object.keys(localStorage).forEach(function(k) {
        if (k.indexOf('civitas-draft-') === 0) localStorage.removeItem(k);
      });
    } catch (err) {}
    renderHomeSavedList();
  }

  function renderAccountBar() {
    accountBar.innerHTML = '';
    if (FILE_SHARING) { accountBar.hidden = true; return; }
    accountBar.hidden = false;
    if (cloudUser) {
      var who = document.createElement('span');
      who.className = 'account-email';
      who.textContent = cloudUser;
      var out = document.createElement('button');
      out.type = 'button';
      out.textContent = 'Log out';
      out.addEventListener('click', accountLogout);
      var del = document.createElement('button');
      del.type = 'button';
      del.textContent = 'Delete account';
      del.addEventListener('click', function() { openAccountModal('delete'); });
      accountBar.appendChild(who);
      accountBar.appendChild(out);
      accountBar.appendChild(del);
    } else {
      var inBtn = document.createElement('button');
      inBtn.type = 'button';
      inBtn.className = 'account-login-btn';
      inBtn.textContent = 'Log in / Sign up';
      inBtn.addEventListener('click', function() { openAccountModal('login'); });
      accountBar.appendChild(inBtn);
    }
  }

  function setAccountMsg(text, isError) {
    accountMsg.textContent = text || '';
    accountMsg.classList.toggle('error', !!isError);
  }

  function openAccountModal(mode, message) {
    accountMode = mode;
    var isDelete = mode === 'delete';
    var isRegister = mode === 'register';
    accountTitle.textContent = isDelete ? 'Delete account' : (isRegister ? 'Create account' : 'Log in');
    accountSubmit.textContent = isDelete ? 'Delete my account' : (isRegister ? 'Sign up' : 'Log in');
    accountEmail.hidden = isDelete;
    accountPassword.placeholder = isDelete ? 'Confirm your password' : (isRegister ? 'Password (10+ characters)' : 'Password');
    accountPassword.autocomplete = isRegister ? 'new-password' : 'current-password';
    accountSwitch.hidden = isDelete;
    accountSwitch.textContent = isRegister ? 'I already have an account' : 'Create an account';
    accountForgot.hidden = isDelete || isRegister;
    accountResend.hidden = true;
    accountPassword.value = '';
    setAccountMsg(isDelete ? 'This permanently deletes your account and every map saved in it.' : (message || ''), false);
    accountModal.hidden = false;
    (isDelete ? accountPassword : accountEmail).focus();
  }

  function closeAccountModal() {
    accountModal.hidden = true;
    accountPassword.value = '';
  }

  function startSession(res, justLoggedIn) {
    cloudUser = res.email;
    cloudNonce = res.nonce;
    renderAccountBar();
    // Logged in while viewing a shared map? It may be the user's own; reopen it to find out. (A session that
    // was already active at page load needs no reopen: the server saw the login cookie when it sent the map.)
    if (justLoggedIn && mapReadOnly && currentSid) loadSharedMap(currentSid);
    return cloudPull();
  }

  function accountLogout() {
    if (!confirm('Log out? Your maps stay safe in your account, and this device\'s copies will be removed.')) return;
    cloudQueue.then(function() { return cloudFetch('/logout', { method: 'POST', body: {} }); }).catch(function() {}).then(function() {
      cloudUser = null;
      cloudNonce = null;
      clearLocalMaps();
      renderAccountBar();
    });
  }

  accountForm.addEventListener('submit', function(e) {
    e.preventDefault();
    var email = accountEmail.value.trim();
    var password = accountPassword.value;
    if (accountMode !== 'delete' && !email) { setAccountMsg('Enter your e-mail address.', true); return; }
    if (!password) { setAccountMsg('Enter your password.', true); return; }
    accountSubmit.disabled = true;
    setAccountMsg('Working…', false);
    var req;
    if (accountMode === 'register') {
      req = cloudFetch('/register', { method: 'POST', body: { email: email, password: password, website: document.getElementById('account-website').value } })
        .then(function() { openAccountModal('login', 'Almost done! We sent a confirmation link to ' + email + '. Open it, then log in here.'); });
    } else if (accountMode === 'delete') {
      req = cloudAuthed('/account/delete', { method: 'POST', body: { password: password } }).then(function() {
        cloudUser = null;
        cloudNonce = null;
        clearLocalMaps();
        renderAccountBar();
        closeAccountModal();
      });
    } else {
      req = cloudFetch('/login', { method: 'POST', body: { email: email, password: password } }).then(function(res) {
        closeAccountModal();
        return startSession(res, true);
      });
    }
    req.catch(function(err) {
      setAccountMsg(err.message, true);
      if (err.code === 'unverified') accountResend.hidden = false;
    }).then(function() { accountSubmit.disabled = false; });
  });

  accountSwitch.addEventListener('click', function() { openAccountModal(accountMode === 'register' ? 'login' : 'register'); });
  accountForgot.addEventListener('click', function() {
    var email = accountEmail.value.trim();
    if (!email) { setAccountMsg('Type your e-mail address above first.', true); return; }
    cloudFetch('/forgot', { method: 'POST', body: { email: email } })
      .then(function() { setAccountMsg('If that address has an account, a reset link is on its way.', false); })
      .catch(function(err) { setAccountMsg(err.message, true); });
  });
  accountResend.addEventListener('click', function() {
    var email = accountEmail.value.trim();
    if (!email) return;
    cloudFetch('/resend', { method: 'POST', body: { email: email } })
      .then(function() { setAccountMsg('If that account is waiting for confirmation, a new link is on its way.', false); })
      .catch(function(err) { setAccountMsg(err.message, true); });
  });
  // Copy the shareable link (#map=<id>) of a saved map to the clipboard. `btn` shows the result briefly.
  function shareMap(sid, btn) {
    function say(text) {
      var original = btn.textContent;
      btn.textContent = text;
      setTimeout(function() { btn.textContent = original; }, 1800);
    }
    if (!CLOUD_API) { alert('Share links only work on electioncord.com, not in this local copy.'); return; }
    if (!sid) { alert('Save this map to your account first. Once it is saved, Share copies a link to it.'); return; }
    var link = location.origin + location.pathname + '#map=' + sid;
    function fallback() { window.prompt('Copy this link to share your map:', link); }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(link).then(function() { say('Link copied'); }, fallback);
    } else {
      fallback();
    }
  }
  // Desktop app: maps are shared as files. Export writes one; "Open map file" on the main menu reads one.
  // The export is a standard GeoJSON file (opens in any GIS tool). The Civitas map itself rides along inside it
  // under civitas.mapFile so "Open map file" can restore it. District shapes are included only when this map
  // is the one open on screen (liveShapes); exporting from the main menu has no geometry loaded.
  function exportMapFile(name, payload, liveShapes) {
    var copy = JSON.parse(JSON.stringify(payload));
    delete copy.sid;     // ids and timestamps belong to this computer / the website, not to the file
    delete copy.id;
    delete copy.updated;
    var features = liveShapes && geoProj && shapes.length ? buildDistrictFeatures() : [];
    saveGeoJSONFile(name, {
      type: 'FeatureCollection',
      name: name,
      civitas: { map: name, state: currentState ? currentState.key : null, districts: features.length, exported: new Date().toISOString(), mapFile: { format: 'civitas-map', version: 1, name: name, payload: copy } },
      features: features
    });
  }

  function importMapFile(file) {
    var reader = new FileReader();
    reader.onload = function() {
      var doc;
      try { doc = JSON.parse(reader.result); } catch (err) { doc = null; }
      if (doc && doc.type === 'FeatureCollection' && doc.civitas && doc.civitas.mapFile) doc = doc.civitas.mapFile;   // new GeoJSON export
      if (!doc || doc.format !== 'civitas-map' || !doc.payload || typeof doc.payload !== 'object') {
        alert('That file is not a Civitas map file.');
        return;
      }
      var p = doc.payload;
      var asObj = function(x) { return x && typeof x === 'object' && !Array.isArray(x) ? x : {}; };
      p.assignments = asObj(p.assignments);
      p.names = asObj(p.names);
      p.locked = asObj(p.locked);
      var all = readSavedMaps();
      var base = String(doc.name || 'Imported map').slice(0, 40);
      var name = base;
      for (var n = 2; all[name]; n++) name = base + ' (' + n + ')';
      p.id = allocateMapId();
      p.updated = Date.now();
      all[name] = p;
      try { writeSavedMaps(all); } catch (err) { alert('Could not save the imported map: ' + err.message); return; }
      renderHomeSavedList();
      applySavedPayload(name, p);
    };
    reader.readAsText(file);
  }

  if (FILE_SHARING) {
    var navShareBtn = document.getElementById('nav-share-map');
    navShareBtn.textContent = 'Export';
    navShareBtn.title = 'Save this map as a file you can send to someone';
    var importBtn = document.getElementById('home-import-btn');
    var importFile = document.getElementById('home-import-file');
    importBtn.hidden = false;
    importBtn.addEventListener('click', function() { importFile.click(); });
    importFile.addEventListener('change', function() {
      if (importFile.files && importFile.files[0]) importMapFile(importFile.files[0]);
      importFile.value = '';
    });
  }

  document.getElementById('nav-share-map').addEventListener('click', function() {
    if (FILE_SHARING) {
      if (!mapNameInput.value.trim()) { flashNameInputError(); return; }
      if (!saveCurrentMap()) return;
      exportMapFile(mapNameInput.value.trim(), readSavedMaps()[mapNameInput.value.trim()], true);
      return;
    }
    shareMap(currentSid, this);
  });

  // District shapes for the GeoJSON export: one dissolved (merged) shape per district in standard lon/lat
  // coordinates, with its name, population and the open election's vote totals. Works for any map you can see.
  function buildDistrictFeatures() {
    computeDistrictBorders();
    var extras = {};
    for (var i = 0; i < shapes.length; i++) {
      var sh = shapes[i];
      if (sh.districtId !== null && sh.drawSelf) (extras[sh.districtId] = extras[sh.districtId] || []).push(sh);
    }
    function toLonLat(ring) {
      var out = [];
      for (var p = 0; p < ring.length; p++) {
        var ll = geoProj.inv(ring[p][0], ring[p][1]);
        out.push([Math.round(ll[0] * 1e5) / 1e5, Math.round(ll[1] * 1e5) / 1e5]);
      }
      var a = out[0], b = out[out.length - 1];
      if (a[0] !== b[0] || a[1] !== b[1]) out.push([a[0], a[1]]);
      return out;
    }
    // GeoJSON wants outer rings counter-clockwise and holes clockwise (RFC 7946).
    function orient(ring, ccw) {
      var area = 0;
      for (var q = 0; q < ring.length - 1; q++) area += ring[q][0] * ring[q + 1][1] - ring[q + 1][0] * ring[q][1];
      return (area > 0) === ccw ? ring : ring.slice().reverse();
    }
    var ids = {};
    Object.keys(districtGeomCache).forEach(function(k) { ids[k] = true; });
    Object.keys(extras).forEach(function(k) { ids[k] = true; });
    var features = [];
    Object.keys(ids).map(Number).sort(function(a, b) { return a - b; }).forEach(function(k) {
      var polys = [];
      var g = districtGeomCache[k];
      if (g) {
        g.rings.forEach(function(r) {
          var ring = toLonLat(r.lods[0]);
          if (r.outer) polys.push([orient(ring, true)]);
          else if (polys.length) polys[polys.length - 1].push(orient(ring, false));
        });
      }
      (extras[k] || []).forEach(function(shape) {
        shape.rings.forEach(function(r) { polys.push([orient(toLonLat(r), true)]); });
      });
      if (!polys.length) return;
      var st = districtStats[k] || zeroStats();
      var props = { district: k, name: districtLabel(k), units: st.count || 0, population: Math.round(st.pop || 0) };
      if (activeRace) {
        props.election = activeRace.year + ' ' + activeRace.label;
        props.dem_votes = Math.round(st.dem || 0);
        props.rep_votes = Math.round(st.rep || 0);
        props.other_votes = Math.round(st.other || 0);
        props.margin = st.margin === null || st.margin === undefined ? null : Math.round(st.margin * 10000) / 10000;
      }
      features.push({ type: 'Feature', properties: props, geometry: { type: 'MultiPolygon', coordinates: polys } });
    });
    return features;
  }
  function saveGeoJSONFile(name, doc) {
    var blob = new Blob([JSON.stringify(doc)], { type: 'application/geo+json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = (name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'civitas-map') + '.geojson';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function() { URL.revokeObjectURL(url); }, 2000);
  }
  document.getElementById('readonly-copy').addEventListener('click', saveCopyOfSharedMap);
  document.getElementById('account-close').addEventListener('click', closeAccountModal);
  accountModal.addEventListener('mousedown', function(e) { if (e.target === accountModal) closeAccountModal(); });
  document.addEventListener('keydown', function(e) { if (e.key === 'Escape' && !accountModal.hidden) closeAccountModal(); });

  renderAccountBar();
  if (CLOUD_API) {
    cloudFetch('/me').then(function(me) {
      if (me.loggedIn) startSession(me);
      if (location.hash === '#verified') {
        openAccountModal('login', 'E-mail confirmed. You can log in now.');
        location.hash = '';
      } else if (location.hash === '#verify-failed') {
        openAccountModal('login', 'That confirmation link is invalid or expired. Log in to request a new one.');
        location.hash = '';
      }
    }).catch(function() {});
  }

  renderHomeSavedList();
  restoreFromHash();
})();
</script>
"""
    html = html.replace("__BUILD_ID__", str(int(time.time())))
    html = html.replace("__POP_CA_BG__", str(POP_TOTALS.get(STATE_KEY_BG, 0))).replace("__POP_CA__", str(POP_TOTALS.get(STATE_KEY, 0)))
    with open(HTML_OUT_PATH, "w", encoding="utf-8") as f:
        f.write(html)
    print("wrote", HTML_OUT_PATH, "bytes(KB):", len(html.encode("utf-8")) / 1e3)


STAMP_PATH = os.path.join(CIVITAS_DIR, "data", ".build_stamp.json")
# Bump this when write_race_sets changes in a way that alters existing vote files (cosmetic additions to
# races.json entries do not need a bump), so every year's results are rebuilt.
OUTPUT_FORMAT_VERSION = 1


def _hash_inputs(funcs, setting_keys, files):
    h = hashlib.sha256()
    for fn in funcs:
        h.update(inspect.getsource(fn).encode("utf-8"))
    settings = {k: globals()[k] for k in setting_keys}
    h.update(json.dumps(settings, sort_keys=True, default=str).encode("utf-8"))
    for f in files:
        st = os.stat(f) if os.path.exists(f) else None
        h.update(f"{f}|{st.st_size if st else None}|{st.st_mtime_ns if st else None}".encode("utf-8"))
    return h.hexdigest()


def base_fingerprint():
    """Hash of everything behind the map geometry, demographics and the block-group overlay: the shape and
    demographic code, their settings, and the Census/TIGER/ACS input files. It deliberately leaves out the
    election-result inputs and code, so changing only results does not rebuild the geometry."""
    files = [BG_ZIP_PATH, COUNTY_GEOJSON_PATH, COUNTY_CSV_PATH, os.path.join(DEMO_DIR, VAP22_CSV),
             os.path.join(DEMO_DIR, ETH_CSV), os.path.join(DEMO_DIR, EDU_CSV), os.path.join(DEMO_DIR, AGE_CSV),
             os.path.join(DEMO_DIR, ORIGIN_CSV), os.path.join(DEMO_DIR, LANG_CSV), os.path.join(DEMO_DIR, INC_CSV),
             os.path.join(DEMO_DIR, VAP20_CSV), os.path.join(DEMO_DIR, VAP_ACS_CSV)] + \
            [os.path.join(DEMO_DIR, c["csv"]) for c in CVAP_SOURCES.values()]
    for cfg in POP_SOURCES.values():
        files.append(os.path.join(DEMO_DIR, cfg["csv"]))
        if "block_csv" in cfg:
            files.append(os.path.join(DEMO_DIR, cfg["block_csv"]))
    return _hash_inputs(
        (slugify, overlay_areas, transfer_weights, build_dasymetric_points, locate_points, overlay_transfer, load_block_groups, records_shape_hash, save_overlay_cache,
         load_bg_population, load_bg_ethnicity, load_bg_education, load_bg_age, load_tract_origin,
         load_bg_language, load_bg_income, load_bg_vap_2020, load_bg_vap_acs, load_bg_cvap,
         allocate_old_bg_population, interpolate_to_block_groups, ring_to_path, geom_to_path, snap_to_grid,
         simplify_as_coverage, albers_raw, build_geometry, build_county_borders, write_data),
        ("STATE_KEY", "STATE_KEY_BG", "BUILD_BLOCK_GROUPS", "BG_ZIP_PATH", "EQUAL_AREA_CRS", "POP_STATE_FIPS",
         "POP_SOURCES", "POP_FIELDS", "ETH_VARS", "ETH_CSV", "EDU_CSV", "EDU_FIELDS", "EDU_GROUPS", "AGE_CSV",
         "AGE_FIELDS", "AGE_GROUPS", "AGE_MIDPOINTS", "ORIGIN_CSV", "ORIGIN_VARS", "LANG_CSV", "LANG_FIELDS",
         "LANG_GROUPS", "INC_CSV", "INC_FIELDS", "INC_GROUPS", "INC_TOP_GROUPS", "INC_MED_VAR", "VAP20_CSV",
         "VAP20_VAR", "VAP_ACS_CSV", "VAP22_CSV", "VAP22_URL", "KEEP_WATER_BGS", "CVAP_SOURCES",
         "OLD_BLOCK_SHAPES", "COUNTY_GEOJSON_PATH", "COUNTY_CSV_PATH", "COUNTY_TOLERANCE", "GRID_UNIT",
         "COVERAGE_TOLERANCE", "STATE_PROJECTION", "COUNTY_FILTER", "TARGET_W", "TOLERANCE", "ZIP_PATH"),
        files)


def result_years():
    """Race groups, in display order: each election year is rebuilt as one unit."""
    years = []
    for meta in RACE_META.values():
        if meta["year"] not in years:
            years.append(meta["year"])
    return years


def race_keys_for(years):
    return [k for k, m in RACE_META.items() if m["year"] in years]


def group_fingerprint(year):
    """Hash of one year's results: its inputs, the code that turns them into votes, and its race settings."""
    keys = race_keys_for([year])
    sets = swdb_set_names(keys)
    if sets:
        funcs = (load_swdb_sources, attach_sources_to_precincts, _concat_cols, _infer_headerless_xwalk, _shapes_from_blocks, overlay_areas, transfer_weights, build_dasymetric_points, locate_points, overlay_transfer)
        files = [BG_ZIP_PATH]
        for name in sets:
            files += [SWDB_SETS[name]["sr_zip"], SWDB_SETS[name]["mprec_zip"], SWDB_SETS[name]["xwalk"]]
            if SWDB_SETS[name].get("sr_blk"):
                files += [SWDB_SETS[name]["sr_blk"], os.path.join(DEMO_DIR, OLD_BLOCK_SHAPES["2010"][0])]
    else:
        funcs = (extract_records,)
        files = [ZIP_PATH]
    h = hashlib.sha256()
    h.update(_hash_inputs(funcs, ("EQUAL_AREA_CRS", "STATE_KEY", "STATE_KEY_BG", "BUILD_BLOCK_GROUPS", "OUTPUT_FORMAT_VERSION"), files).encode("utf-8"))
    # Only this year's own input settings, so adding another year's files never invalidates it.
    h.update(json.dumps({n: SWDB_SETS[n] for n in sets}, sort_keys=True, default=str).encode("utf-8"))
    h.update(json.dumps({k: [RACES[k], RACE_META[k]] for k in keys}, sort_keys=True, default=str).encode("utf-8"))
    return h.hexdigest()


def data_outputs_exist():
    keys = [STATE_KEY] + ([STATE_KEY_BG] if BUILD_BLOCK_GROUPS else [])
    return all(
        os.path.exists(os.path.join(CIVITAS_DIR, "data", k, "races.json"))
        and os.path.exists(os.path.join(CIVITAS_DIR, "data", k, "geometry", "manifest.json"))
        for k in keys
    )


def build_data(records=None):
    srcs = load_all_sources()
    records = records if records is not None else extract_records()
    attach_sources_to_precincts(records, srcs)
    bg_records = interpolate_to_block_groups(records, srcs) if BUILD_BLOCK_GROUPS else None
    POP_TOTALS[STATE_KEY] = int(round(sum(r.get("pop", 0) for r in records)))
    if bg_records is not None:
        POP_TOTALS[STATE_KEY_BG] = int(round(sum(r.get("pop", 0) for r in bg_records)))
    geo_records, W, H = build_geometry(records)
    write_data(records, geo_records, W, H, STATE_KEY)
    if BUILD_BLOCK_GROUPS:
        bg_geo_records, bgW, bgH = build_geometry(bg_records)
        write_data(bg_records, bg_geo_records, bgW, bgH, STATE_KEY_BG)


def rebuild_result_sets(stale_years):
    """Rewrite only the vote files of the given election years (plus races.json), reusing the geometry,
    demographics and cached precinct->block-group overlay from the last full build.

    Returns (done, records); done is False if a full build is needed (the map shapes changed, or there is no
    usable cache), and `records` is whatever was already extracted so the full build need not redo it."""
    keys = race_keys_for(stale_years)
    use_old = [k for k in keys if "swdb" in RACES[k]]
    cache = load_overlay_cache() if BUILD_BLOCK_GROUPS else {}
    if cache is None:
        print("no overlay cache from a previous full build; doing a full build")
        return False, None
    t_stage = [time.time()]

    def stage(name):
        now = time.time()
        print(f"[timing] {name}: {now - t_stage[0]:.0f}s")
        t_stage[0] = now

    records = extract_records()
    stage("read the 2024 precinct file")
    if BUILD_BLOCK_GROUPS and (str(cache["base_fp"]) != base_fingerprint()
                               or str(cache["geom_hash"]) != records_shape_hash(records)):
        print("the precinct shapes or registration changed (or the cache is out of date); doing a full build")
        return False, records
    stage("check the cache")

    srcs = ov_by_set = None
    if use_old:
        srcs = load_all_sources(use_old)
        stage("load the older elections' precinct maps and results")
        attach_sources_to_precincts(records, srcs)
        stage("allocate older results onto the 2024 precincts")
    bg_units = None
    if BUILD_BLOCK_GROUPS:
        pid, bgi, area, nbg = cache["pid"], cache["bgi"], cache["a"], int(cache["nbg"])
        w = transfer_weights(pid, area, cache["f"], len(records))
        ov_by_set = {}
        if use_old:
            _, bg_m = load_block_groups()
            b_geoms = list(bg_m.geometry.values)
            for set_name, src_set in srcs.items():
                ov_set = overlay_transfer(src_set["geoms"], b_geoms, f"{set_name} precincts -> block groups")
                ov_by_set[set_name] = (ov_set, transfer_weights(ov_set["pid"], ov_set["a"], ov_set["f"], len(src_set["geoms"])))
            stage("overlay older precincts onto block groups")
        race_bg = {}
        for rkey in keys:
            race_bg[rkey] = {}
            for f in ("dem", "rep", "other"):
                if rkey in use_old:
                    set_name = RACES[rkey]["swdb"]["set"]
                    ov_set, w_set = ov_by_set[set_name]
                    src, p_idx, t_idx, ww = srcs[set_name]["races"][rkey][f], ov_set["pid"], ov_set["tid"], w_set
                else:
                    src, p_idx, t_idx, ww = np.array([r["races"][rkey][f] for r in records]), pid, bgi, w
                dst = np.bincount(t_idx, weights=src[p_idx] * ww, minlength=nbg)
                race_bg[rkey][f] = np.rint(dst)
                print(f"  {rkey}.{f}: source {src.sum():,.0f} -> block groups {dst.sum():,.0f}")
        bg_units = [
            {"precinct": str(g), "county": str(c),
             "races": {rk: {f: float(race_bg[rk][f][i]) for f in ("dem", "rep", "other")} for rk in keys}}
            for i, g, c in zip(cache["keep_idx"], cache["geoid"], cache["county"])
        ]
        stage("allocate to block groups")

    ok = write_races_index(STATE_KEY, write_race_sets(records, STATE_KEY, keys))
    stage("write the precinct vote files")
    if bg_units is not None:
        ok = write_races_index(STATE_KEY_BG, write_race_sets(bg_units, STATE_KEY_BG, keys)) and ok
        stage("write the block group vote files")
    return ok, records


def _load_stamps():
    try:
        with open(STAMP_PATH, encoding="utf-8") as f:
            stamps = json.load(f)
        if isinstance(stamps.get("states"), dict):
            return stamps
    except (OSError, ValueError):
        pass
    return {"states": {}}


def _save_stamps(stamps):
    try:
        os.makedirs(os.path.dirname(STAMP_PATH), exist_ok=True)
        with open(STAMP_PATH, "w", encoding="utf-8") as f:
            json.dump(stamps, f)
    except (OSError, TypeError) as err:
        print(f"could not write build stamp ({err!r}); the next run will rebuild the data")


def main():
    t0 = time.time()
    force = "--force" in sys.argv or FORCE_REBUILD
    stamps = _load_stamps()
    st = stamps["states"].get(STATE_KEY)
    years = result_years()
    done = False
    records = None
    if not force and st and data_outputs_exist():
        try:
            fps = {y: group_fingerprint(y) for y in years}
            base_ok = st.get("base") == base_fingerprint()
        except (OSError, TypeError) as err:
            print(f"fingerprint unavailable ({err!r}); rebuilding data")
            base_ok = False
        if base_ok:
            POP_TOTALS.update(st.get("pop_totals", {}))
            stale = [y for y in years if st.get("groups", {}).get(y) != fps[y]]
            if not stale:
                print(f"{STATE_KEY}: data inputs and build code unchanged: skipping the data build, rewriting the "
                      "page only (set FORCE_REBUILD = True or pass --force to rebuild the data anyway)")
                done = True
            else:
                print(f"{STATE_KEY}: only the {', '.join(stale)} results changed; rebuilding just those "
                      "(geometry and demographics are reused)")
                done, records = rebuild_result_sets(stale)
                if done:
                    st["groups"].update({y: fps[y] for y in stale})
                    _save_stamps(stamps)
    if not done:
        build_data(records)
        try:
            stamps["states"][STATE_KEY] = {
                "base": base_fingerprint(),
                "groups": {y: group_fingerprint(y) for y in years},
                "pop_totals": POP_TOTALS,
            }
            _save_stamps(stamps)
        except (OSError, TypeError) as err:
            print(f"could not write build stamp ({err!r}); the next run will rebuild the data")
    write_html()
    print("done in %.1fs" % (time.time() - t0))


if __name__ == "__main__":
    main()
