// ElectionCord Civitas desktop app (Electron).
//
// The map page is the same ElectionCordCivitas.html used on the website. It is served to the window through a
// private "civitas://app/" address that reads straight from the program's own files, so there is no web server,
// no network port, and nothing for anyone else on the network to reach. Saved maps live in the app's own
// storage and stay on this computer.

const { app, BrowserWindow, Menu, protocol, net, shell, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');

// Packaged: the page and data are copied next to the program (see "extraResources" in package.json).
// Running from source (npm start): read them from the Civitas folder one level up.
const WEB_ROOT = app.isPackaged ? path.join(process.resourcesPath, 'web') : path.resolve(__dirname, '..');
const INDEX = fs.existsSync(path.join(WEB_ROOT, 'index.html')) ? 'index.html' : 'ElectionCordCivitas.html';

// The page loads one script from a CDN (polygon-clipping, which merges precincts into district outlines).
// Swap it for the copy installed with the app so everything works without that download.
const CDN_POLYGON_CLIPPING = 'https://cdn.jsdelivr.net/npm/polygon-clipping@0.15.7/dist/polygon-clipping.umd.js';
const LOCAL_POLYGON_CLIPPING = path.join(__dirname, 'node_modules', 'polygon-clipping', 'dist', 'polygon-clipping.umd.js');

protocol.registerSchemesAsPrivileged([
  { scheme: 'civitas', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } },
]);

function notFound() {
  return new Response('Not found', { status: 404, headers: { 'content-type': 'text/plain' } });
}

function registerProtocol() {
  protocol.handle('civitas', async (request) => {
    let rel;
    try {
      rel = decodeURIComponent(new URL(request.url).pathname);
    } catch (err) {
      return notFound();
    }
    if (rel === '/' || rel === '') rel = '/' + INDEX;

    if (rel === '/vendor/polygon-clipping.umd.js') {
      try {
        return new Response(fs.readFileSync(LOCAL_POLYGON_CLIPPING), { headers: { 'content-type': 'text/javascript' } });
      } catch (err) {
        return notFound();
      }
    }

    // Only ever serve files inside the web folder.
    const file = path.normalize(path.join(WEB_ROOT, rel));
    if (file !== WEB_ROOT && !file.startsWith(WEB_ROOT + path.sep)) {
      return new Response('Forbidden', { status: 403, headers: { 'content-type': 'text/plain' } });
    }
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return notFound();

    if (path.basename(file) === INDEX) {
      const html = fs.readFileSync(file, 'utf8').split(CDN_POLYGON_CLIPPING).join('vendor/polygon-clipping.umd.js');
      return new Response(html, { headers: { 'content-type': 'text/html; charset=utf-8' } });
    }
    return net.fetch(pathToFileURL(file).toString());
  });
}

let mainWindow = null;

// Everything that goes wrong is also written to a log file (Windows: %APPDATA%\ElectionCord Civitas\civitas.log)
// so a failure can be diagnosed instead of the program just doing nothing.
function logLine(text) {
  try {
    fs.appendFileSync(path.join(app.getPath('userData'), 'civitas.log'), new Date().toISOString() + '  ' + text + '\n');
  } catch (err) { /* logging must never crash the app */ }
}

process.on('uncaughtException', (err) => {
  logLine('uncaughtException: ' + (err && err.stack || err));
  try { dialog.showErrorBox('ElectionCord Civitas', 'Something went wrong:\n\n' + (err && err.message || err) + '\n\nDetails are in civitas.log in ' + app.getPath('userData')); } catch (e) {}
});

function createWindow() {
  logLine('starting: packaged=' + app.isPackaged + ' webRoot=' + WEB_ROOT + ' index=' + INDEX + ' indexExists=' + fs.existsSync(path.join(WEB_ROOT, INDEX)));
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#ffffff',
    title: "ElectionCord's Civitas",
    icon: path.join(WEB_ROOT, 'favicon.jpg'),   // the icon at the window's top left (and on the taskbar while it runs)
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  mainWindow.on('closed', () => { mainWindow = null; });

  // Show a clear message if the page cannot be loaded, instead of a blank or missing window.
  mainWindow.webContents.on('did-fail-load', (event, code, description, url, isMainFrame) => {
    logLine('did-fail-load ' + code + ' ' + description + ' ' + url);
    if (isMainFrame && code !== -3) {
      dialog.showErrorBox('ElectionCord Civitas', 'The map page could not be loaded (' + description + ').\n\nLooked for it in:\n' + WEB_ROOT);
    }
  });
  mainWindow.webContents.on('render-process-gone', (event, details) => {
    logLine('render-process-gone ' + details.reason);
  });
  mainWindow.webContents.on('console-message', (event, level, message) => {
    if (level >= 3) logLine('page error: ' + message);
  });

  // Links to the web (map credits, etc.) open in the normal browser, never inside the app.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('civitas://')) {
      event.preventDefault();
      if (/^https?:/i.test(url)) shell.openExternal(url);
    }
  });

  // The page asks "leave with unsaved changes?" when it is closed. A browser shows that prompt itself; here we
  // have to, or the window simply refuses to close.
  mainWindow.webContents.on('will-prevent-unload', (event) => {
    const choice = dialog.showMessageBoxSync(mainWindow, {
      type: 'question',
      buttons: ['Close without saving', 'Keep editing'],
      defaultId: 1,
      cancelId: 1,
      title: 'Unsaved changes',
      message: 'This map has changes you have not saved.',
    });
    if (choice === 0) event.preventDefault();   // ignore the page's objection and close
  });

  mainWindow.loadURL('civitas://app/');
}

function buildMenu() {
  const template = [
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'togglefullscreen' },
        { type: 'separator' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { role: 'resetZoom' },
        ...(app.isPackaged ? [] : [{ type: 'separator' }, { role: 'toggleDevTools' }]),
      ],
    },
    {
      label: 'Help',
      submenu: [
        { label: 'ElectionCord website', click: () => shell.openExternal('https://electioncord.com') },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// One copy at a time: opening the program again just brings the existing window forward.
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    } else {
      createWindow();
    }
  });
  app.whenReady().then(() => {
    registerProtocol();
    buildMenu();
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => { app.quit(); });
}
